package org.xtext.example.mydsl.ui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.xtext.ui.editor.syntaxcoloring.DefaultHighlightingConfiguration;
import org.eclipse.xtext.ui.editor.syntaxcoloring.IHighlightingConfigurationAcceptor;
import org.eclipse.xtext.ui.editor.utils.TextStyle;

public class CLHighlightingConfiguration extends DefaultHighlightingConfiguration {
public static final String Prefix_ID = "@prefix";
public static final String Source_ID = "@source";
public static final String Arrow_ID = "arrow";
public static final String Comment_ID = "comment";
public static final String UniVar_ID = "univar";
public static final String ExiVar_ID = "exivar";

@Override
public void configure
(IHighlightingConfigurationAcceptor acceptor){ // semantic highlighting
acceptor
.acceptDefaultHighlighting(Prefix_ID, "@prefix", //$NON-NLS-1$
				attributeIdTextStyle());
				acceptor.acceptDefaultHighlighting(Source_ID, "@source", //$NON-NLS-1$
				quotedStringTextStyle());
				acceptor.acceptDefaultHighlighting(Arrow_ID, "arrow", //$NON-NLS-1$
				arrowTextStyle());
				acceptor.acceptDefaultHighlighting(Comment_ID, "comment", //$NON-NLS-1$
				portIdTextStyle());
				acceptor.acceptDefaultHighlighting(UniVar_ID, "univar", //$NON-NLS-1$
				varIdTextStyle());
				acceptor.acceptDefaultHighlighting(ExiVar_ID, "var", //$NON-NLS-1$
				var2IdTextStyle());
	}

public TextStyle attributeIdTextStyle() {
		TextStyle textStyle = defaultTextStyle().copy();
		textStyle.setColor(new RGB(0, 76, 153)); // dark blue
		textStyle.setStyle(SWT.BOLD);
		return textStyle;
	}

public TextStyle quotedStringTextStyle() {
		TextStyle textStyle = defaultTextStyle().copy();
		textStyle.setColor(new RGB(255, 0, 0)); // red
		textStyle.setStyle(SWT.BOLD);
		return textStyle;
	}

public TextStyle arrowTextStyle() {
		TextStyle textStyle = defaultTextStyle().copy();
		textStyle.setColor(new RGB(153, 76, 0)); // brown
		textStyle.setStyle(SWT.BOLD);
		return textStyle;
	}

public TextStyle portIdTextStyle() {
		TextStyle textStyle = defaultTextStyle().copy();
		textStyle.setColor(new RGB(0, 153, 76)); // light green
		return textStyle;
	}

public TextStyle varIdTextStyle() {
		TextStyle textStyle = defaultTextStyle().copy();
		textStyle.setColor(new RGB(102, 0, 204)); // purple
		textStyle.setStyle(SWT.BOLD);
		return textStyle;
	}

public TextStyle var2IdTextStyle() {
		TextStyle textStyle = defaultTextStyle().copy();
		textStyle.setColor(new RGB(0, 153, 153)); // dark cyan
		textStyle.setStyle(SWT.BOLD);
		return textStyle;
	}
}
