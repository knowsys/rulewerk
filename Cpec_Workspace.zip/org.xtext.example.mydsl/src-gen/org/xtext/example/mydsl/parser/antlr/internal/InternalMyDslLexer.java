package org.xtext.example.mydsl.parser.antlr.internal;

// Hack: Use our own Lexer superclass by means of import. 
// Currently there is no other way to specify the superclass for the lexer.
import org.eclipse.xtext.parser.antlr.Lexer;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslLexer extends Lexer {
    public static final int RULE_LPAREN=20;
    public static final int RULE_PRFX=30;
    public static final int RULE_ARROW=22;
    public static final int RULE_A2Z=42;
    public static final int RULE_A2ZNX=44;
    public static final int RULE_PNAME_LN=4;
    public static final int RULE_COMMA=18;
    public static final int RULE_DATATYPE=11;
    public static final int RULE_COLON=29;
    public static final int RULE_DECIMAL=13;
    public static final int RULE_DIRECTIVENAME=45;
    public static final int RULE_TILDE=19;
    public static final int RULE_SPARQL=27;
    public static final int RULE_PN_PREFIX=37;
    public static final int RULE_ECHAR=36;
    public static final int RULE_EXIVAR=16;
    public static final int RULE_SRC=28;
    public static final int RULE_EMARK=40;
    public static final int RULE_PN_CHARS_BASE=48;
    public static final int RULE_STRING_LITERAL1=6;
    public static final int RULE_STRING_LITERAL2=7;
    public static final int RULE_IRI=5;
    public static final int RULE_VARORPREDNAME=17;
    public static final int RULE_QMARK=39;
    public static final int RULE_A2ZN=43;
    public static final int RULE_STRING_LITERAL_LONG1=8;
    public static final int RULE_STRING_LITERAL_LONG2=9;
    public static final int RULE_SKIP=35;
    public static final int RULE_DIGITS=33;
    public static final int RULE_AT=41;
    public static final int RULE_PN_LOCAL=38;
    public static final int RULE_DOUBLE=14;
    public static final int RULE_UNIVAR=15;
    public static final int RULE_PNAME_NS=31;
    public static final int RULE_DOT=23;
    public static final int EOF=-1;
    public static final int RULE_LANGTAG=10;
    public static final int RULE_RBRACK=47;
    public static final int RULE_PN_CHARS=50;
    public static final int RULE_LOADRDF=26;
    public static final int RULE_BS=32;
    public static final int RULE_RPAREN=21;
    public static final int RULE_EXPONENT=34;
    public static final int RULE_PN_CHARS_U=49;
    public static final int RULE_E=24;
    public static final int RULE_LOADCSV=25;
    public static final int RULE_INTEGER=12;
    public static final int RULE_LBRACK=46;

    // delegates
    // delegators

    public InternalMyDslLexer() {;} 
    public InternalMyDslLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public InternalMyDslLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }

    // $ANTLR start "RULE_E"
    public final void mRULE_E() throws RecognitionException {
        try {
            int _type = RULE_E;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2044:8: ( EOF )
            // InternalMyDsl.g:2044:10: EOF
            {
            match(EOF); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_E"

    // $ANTLR start "RULE_PRFX"
    public final void mRULE_PRFX() throws RecognitionException {
        try {
            int _type = RULE_PRFX;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2046:11: ( '@prefix ' )
            // InternalMyDsl.g:2046:13: '@prefix '
            {
            match("@prefix "); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_PRFX"

    // $ANTLR start "RULE_BS"
    public final void mRULE_BS() throws RecognitionException {
        try {
            int _type = RULE_BS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2048:9: ( '@base ' )
            // InternalMyDsl.g:2048:11: '@base '
            {
            match("@base "); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_BS"

    // $ANTLR start "RULE_SRC"
    public final void mRULE_SRC() throws RecognitionException {
        try {
            int _type = RULE_SRC;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2050:10: ( '@source' )
            // InternalMyDsl.g:2050:12: '@source'
            {
            match("@source"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_SRC"

    // $ANTLR start "RULE_LOADCSV"
    public final void mRULE_LOADCSV() throws RecognitionException {
        try {
            int _type = RULE_LOADCSV;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2052:14: ( 'load-csv' )
            // InternalMyDsl.g:2052:16: 'load-csv'
            {
            match("load-csv"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_LOADCSV"

    // $ANTLR start "RULE_LOADRDF"
    public final void mRULE_LOADRDF() throws RecognitionException {
        try {
            int _type = RULE_LOADRDF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2054:14: ( 'load-rdf' )
            // InternalMyDsl.g:2054:16: 'load-rdf'
            {
            match("load-rdf"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_LOADRDF"

    // $ANTLR start "RULE_SPARQL"
    public final void mRULE_SPARQL() throws RecognitionException {
        try {
            int _type = RULE_SPARQL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2056:13: ( 'sparql' )
            // InternalMyDsl.g:2056:15: 'sparql'
            {
            match("sparql"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_SPARQL"

    // $ANTLR start "RULE_INTEGER"
    public final void mRULE_INTEGER() throws RecognitionException {
        try {
            int _type = RULE_INTEGER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2058:14: ( ( '-' | '+' )? RULE_DIGITS )
            // InternalMyDsl.g:2058:16: ( '-' | '+' )? RULE_DIGITS
            {
            // InternalMyDsl.g:2058:16: ( '-' | '+' )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0=='+'||LA1_0=='-') ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyDsl.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            mRULE_DIGITS(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_INTEGER"

    // $ANTLR start "RULE_DECIMAL"
    public final void mRULE_DECIMAL() throws RecognitionException {
        try {
            int _type = RULE_DECIMAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2060:14: ( ( '-' | '+' )? ( ( RULE_DIGITS )+ '.' ( RULE_DIGITS )* | '.' ( RULE_DIGITS )+ ) )
            // InternalMyDsl.g:2060:16: ( '-' | '+' )? ( ( RULE_DIGITS )+ '.' ( RULE_DIGITS )* | '.' ( RULE_DIGITS )+ )
            {
            // InternalMyDsl.g:2060:16: ( '-' | '+' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0=='+'||LA2_0=='-') ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            // InternalMyDsl.g:2060:27: ( ( RULE_DIGITS )+ '.' ( RULE_DIGITS )* | '.' ( RULE_DIGITS )+ )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( ((LA6_0>='0' && LA6_0<='9')) ) {
                alt6=1;
            }
            else if ( (LA6_0=='.') ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:2060:28: ( RULE_DIGITS )+ '.' ( RULE_DIGITS )*
                    {
                    // InternalMyDsl.g:2060:28: ( RULE_DIGITS )+
                    int cnt3=0;
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( ((LA3_0>='0' && LA3_0<='9')) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // InternalMyDsl.g:2060:28: RULE_DIGITS
                    	    {
                    	    mRULE_DIGITS(); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt3 >= 1 ) break loop3;
                                EarlyExitException eee =
                                    new EarlyExitException(3, input);
                                throw eee;
                        }
                        cnt3++;
                    } while (true);

                    match('.'); 
                    // InternalMyDsl.g:2060:45: ( RULE_DIGITS )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( ((LA4_0>='0' && LA4_0<='9')) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalMyDsl.g:2060:45: RULE_DIGITS
                    	    {
                    	    mRULE_DIGITS(); 

                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:2060:58: '.' ( RULE_DIGITS )+
                    {
                    match('.'); 
                    // InternalMyDsl.g:2060:62: ( RULE_DIGITS )+
                    int cnt5=0;
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( ((LA5_0>='0' && LA5_0<='9')) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // InternalMyDsl.g:2060:62: RULE_DIGITS
                    	    {
                    	    mRULE_DIGITS(); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt5 >= 1 ) break loop5;
                                EarlyExitException eee =
                                    new EarlyExitException(5, input);
                                throw eee;
                        }
                        cnt5++;
                    } while (true);


                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_DECIMAL"

    // $ANTLR start "RULE_DOUBLE"
    public final void mRULE_DOUBLE() throws RecognitionException {
        try {
            int _type = RULE_DOUBLE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2062:13: ( ( '+' | '-' )? ( ( '0' .. '9' )+ '.' ( '0' .. '9' )* RULE_EXPONENT | '.' ( '0' .. '9' )+ RULE_EXPONENT | ( '0' .. '9' )+ RULE_EXPONENT ) )
            // InternalMyDsl.g:2062:15: ( '+' | '-' )? ( ( '0' .. '9' )+ '.' ( '0' .. '9' )* RULE_EXPONENT | '.' ( '0' .. '9' )+ RULE_EXPONENT | ( '0' .. '9' )+ RULE_EXPONENT )
            {
            // InternalMyDsl.g:2062:15: ( '+' | '-' )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0=='+'||LA7_0=='-') ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyDsl.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            // InternalMyDsl.g:2062:26: ( ( '0' .. '9' )+ '.' ( '0' .. '9' )* RULE_EXPONENT | '.' ( '0' .. '9' )+ RULE_EXPONENT | ( '0' .. '9' )+ RULE_EXPONENT )
            int alt12=3;
            alt12 = dfa12.predict(input);
            switch (alt12) {
                case 1 :
                    // InternalMyDsl.g:2062:27: ( '0' .. '9' )+ '.' ( '0' .. '9' )* RULE_EXPONENT
                    {
                    // InternalMyDsl.g:2062:27: ( '0' .. '9' )+
                    int cnt8=0;
                    loop8:
                    do {
                        int alt8=2;
                        int LA8_0 = input.LA(1);

                        if ( ((LA8_0>='0' && LA8_0<='9')) ) {
                            alt8=1;
                        }


                        switch (alt8) {
                    	case 1 :
                    	    // InternalMyDsl.g:2062:28: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt8 >= 1 ) break loop8;
                                EarlyExitException eee =
                                    new EarlyExitException(8, input);
                                throw eee;
                        }
                        cnt8++;
                    } while (true);

                    match('.'); 
                    // InternalMyDsl.g:2062:43: ( '0' .. '9' )*
                    loop9:
                    do {
                        int alt9=2;
                        int LA9_0 = input.LA(1);

                        if ( ((LA9_0>='0' && LA9_0<='9')) ) {
                            alt9=1;
                        }


                        switch (alt9) {
                    	case 1 :
                    	    // InternalMyDsl.g:2062:44: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    break loop9;
                        }
                    } while (true);

                    mRULE_EXPONENT(); 

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:2062:69: '.' ( '0' .. '9' )+ RULE_EXPONENT
                    {
                    match('.'); 
                    // InternalMyDsl.g:2062:73: ( '0' .. '9' )+
                    int cnt10=0;
                    loop10:
                    do {
                        int alt10=2;
                        int LA10_0 = input.LA(1);

                        if ( ((LA10_0>='0' && LA10_0<='9')) ) {
                            alt10=1;
                        }


                        switch (alt10) {
                    	case 1 :
                    	    // InternalMyDsl.g:2062:74: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt10 >= 1 ) break loop10;
                                EarlyExitException eee =
                                    new EarlyExitException(10, input);
                                throw eee;
                        }
                        cnt10++;
                    } while (true);

                    mRULE_EXPONENT(); 

                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:2062:99: ( '0' .. '9' )+ RULE_EXPONENT
                    {
                    // InternalMyDsl.g:2062:99: ( '0' .. '9' )+
                    int cnt11=0;
                    loop11:
                    do {
                        int alt11=2;
                        int LA11_0 = input.LA(1);

                        if ( ((LA11_0>='0' && LA11_0<='9')) ) {
                            alt11=1;
                        }


                        switch (alt11) {
                    	case 1 :
                    	    // InternalMyDsl.g:2062:100: '0' .. '9'
                    	    {
                    	    matchRange('0','9'); 

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt11 >= 1 ) break loop11;
                                EarlyExitException eee =
                                    new EarlyExitException(11, input);
                                throw eee;
                        }
                        cnt11++;
                    } while (true);

                    mRULE_EXPONENT(); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_DOUBLE"

    // $ANTLR start "RULE_DIGITS"
    public final void mRULE_DIGITS() throws RecognitionException {
        try {
            // InternalMyDsl.g:2064:22: ( ( '0' .. '9' )+ )
            // InternalMyDsl.g:2064:24: ( '0' .. '9' )+
            {
            // InternalMyDsl.g:2064:24: ( '0' .. '9' )+
            int cnt13=0;
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( ((LA13_0>='0' && LA13_0<='9')) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalMyDsl.g:2064:25: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt13 >= 1 ) break loop13;
                        EarlyExitException eee =
                            new EarlyExitException(13, input);
                        throw eee;
                }
                cnt13++;
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_DIGITS"

    // $ANTLR start "RULE_EXPONENT"
    public final void mRULE_EXPONENT() throws RecognitionException {
        try {
            // InternalMyDsl.g:2066:24: ( ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+ )
            // InternalMyDsl.g:2066:26: ( 'e' | 'E' ) ( '+' | '-' )? ( '0' .. '9' )+
            {
            if ( input.LA(1)=='E'||input.LA(1)=='e' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // InternalMyDsl.g:2066:36: ( '+' | '-' )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0=='+'||LA14_0=='-') ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyDsl.g:
                    {
                    if ( input.LA(1)=='+'||input.LA(1)=='-' ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        recover(mse);
                        throw mse;}


                    }
                    break;

            }

            // InternalMyDsl.g:2066:47: ( '0' .. '9' )+
            int cnt15=0;
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>='0' && LA15_0<='9')) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalMyDsl.g:2066:48: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt15 >= 1 ) break loop15;
                        EarlyExitException eee =
                            new EarlyExitException(15, input);
                        throw eee;
                }
                cnt15++;
            } while (true);


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_EXPONENT"

    // $ANTLR start "RULE_SKIP"
    public final void mRULE_SKIP() throws RecognitionException {
        try {
            int _type = RULE_SKIP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2068:11: ( ( ' ' | '\\t' | '\\n' | '\\r' | '\\f' | '%' (~ ( '\\n' ) )* '\\n' ) )
            // InternalMyDsl.g:2068:13: ( ' ' | '\\t' | '\\n' | '\\r' | '\\f' | '%' (~ ( '\\n' ) )* '\\n' )
            {
            // InternalMyDsl.g:2068:13: ( ' ' | '\\t' | '\\n' | '\\r' | '\\f' | '%' (~ ( '\\n' ) )* '\\n' )
            int alt17=6;
            switch ( input.LA(1) ) {
            case ' ':
                {
                alt17=1;
                }
                break;
            case '\t':
                {
                alt17=2;
                }
                break;
            case '\n':
                {
                alt17=3;
                }
                break;
            case '\r':
                {
                alt17=4;
                }
                break;
            case '\f':
                {
                alt17=5;
                }
                break;
            case '%':
                {
                alt17=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalMyDsl.g:2068:14: ' '
                    {
                    match(' '); 

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:2068:18: '\\t'
                    {
                    match('\t'); 

                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:2068:23: '\\n'
                    {
                    match('\n'); 

                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:2068:28: '\\r'
                    {
                    match('\r'); 

                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:2068:33: '\\f'
                    {
                    match('\f'); 

                    }
                    break;
                case 6 :
                    // InternalMyDsl.g:2068:38: '%' (~ ( '\\n' ) )* '\\n'
                    {
                    match('%'); 
                    // InternalMyDsl.g:2068:42: (~ ( '\\n' ) )*
                    loop16:
                    do {
                        int alt16=2;
                        int LA16_0 = input.LA(1);

                        if ( ((LA16_0>='\u0000' && LA16_0<='\t')||(LA16_0>='\u000B' && LA16_0<='\uFFFF')) ) {
                            alt16=1;
                        }


                        switch (alt16) {
                    	case 1 :
                    	    // InternalMyDsl.g:2068:42: ~ ( '\\n' )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\uFFFF') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;}


                    	    }
                    	    break;

                    	default :
                    	    break loop16;
                        }
                    } while (true);

                    match('\n'); 

                    }
                    break;

            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_SKIP"

    // $ANTLR start "RULE_STRING_LITERAL1"
    public final void mRULE_STRING_LITERAL1() throws RecognitionException {
        try {
            int _type = RULE_STRING_LITERAL1;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2070:22: ( '\\'' (~ ( ( '\\'' | '\\\\' | '\\n' | '\\r' ) ) | RULE_ECHAR )* '\\'' )
            // InternalMyDsl.g:2070:24: '\\'' (~ ( ( '\\'' | '\\\\' | '\\n' | '\\r' ) ) | RULE_ECHAR )* '\\''
            {
            match('\''); 
            // InternalMyDsl.g:2070:29: (~ ( ( '\\'' | '\\\\' | '\\n' | '\\r' ) ) | RULE_ECHAR )*
            loop18:
            do {
                int alt18=3;
                int LA18_0 = input.LA(1);

                if ( ((LA18_0>='\u0000' && LA18_0<='\t')||(LA18_0>='\u000B' && LA18_0<='\f')||(LA18_0>='\u000E' && LA18_0<='&')||(LA18_0>='(' && LA18_0<='[')||(LA18_0>=']' && LA18_0<='\uFFFF')) ) {
                    alt18=1;
                }
                else if ( (LA18_0=='\\') ) {
                    alt18=2;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalMyDsl.g:2070:30: ~ ( ( '\\'' | '\\\\' | '\\n' | '\\r' ) )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;
            	case 2 :
            	    // InternalMyDsl.g:2070:55: RULE_ECHAR
            	    {
            	    mRULE_ECHAR(); 

            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

            match('\''); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_STRING_LITERAL1"

    // $ANTLR start "RULE_STRING_LITERAL2"
    public final void mRULE_STRING_LITERAL2() throws RecognitionException {
        try {
            int _type = RULE_STRING_LITERAL2;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2072:22: ( '\"' (~ ( ( '\"' | '\\\\' | '\\n' | '\\r' ) ) | RULE_ECHAR )* '\"' )
            // InternalMyDsl.g:2072:24: '\"' (~ ( ( '\"' | '\\\\' | '\\n' | '\\r' ) ) | RULE_ECHAR )* '\"'
            {
            match('\"'); 
            // InternalMyDsl.g:2072:28: (~ ( ( '\"' | '\\\\' | '\\n' | '\\r' ) ) | RULE_ECHAR )*
            loop19:
            do {
                int alt19=3;
                int LA19_0 = input.LA(1);

                if ( ((LA19_0>='\u0000' && LA19_0<='\t')||(LA19_0>='\u000B' && LA19_0<='\f')||(LA19_0>='\u000E' && LA19_0<='!')||(LA19_0>='#' && LA19_0<='[')||(LA19_0>=']' && LA19_0<='\uFFFF')) ) {
                    alt19=1;
                }
                else if ( (LA19_0=='\\') ) {
                    alt19=2;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalMyDsl.g:2072:29: ~ ( ( '\"' | '\\\\' | '\\n' | '\\r' ) )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;
            	case 2 :
            	    // InternalMyDsl.g:2072:53: RULE_ECHAR
            	    {
            	    mRULE_ECHAR(); 

            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            match('\"'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_STRING_LITERAL2"

    // $ANTLR start "RULE_STRING_LITERAL_LONG1"
    public final void mRULE_STRING_LITERAL_LONG1() throws RecognitionException {
        try {
            int _type = RULE_STRING_LITERAL_LONG1;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2074:27: ( '\\'\\'\\'' (~ ( ( '\\'' | '\\\\' ) ) | RULE_ECHAR | '\\'' ~ ( '\\'' ) | '\\'\\'' ~ ( '\\'' ) )* '\\'\\'\\'' )
            // InternalMyDsl.g:2074:29: '\\'\\'\\'' (~ ( ( '\\'' | '\\\\' ) ) | RULE_ECHAR | '\\'' ~ ( '\\'' ) | '\\'\\'' ~ ( '\\'' ) )* '\\'\\'\\''
            {
            match("'''"); 

            // InternalMyDsl.g:2074:38: (~ ( ( '\\'' | '\\\\' ) ) | RULE_ECHAR | '\\'' ~ ( '\\'' ) | '\\'\\'' ~ ( '\\'' ) )*
            loop20:
            do {
                int alt20=5;
                int LA20_0 = input.LA(1);

                if ( (LA20_0=='\'') ) {
                    int LA20_1 = input.LA(2);

                    if ( (LA20_1=='\'') ) {
                        int LA20_4 = input.LA(3);

                        if ( ((LA20_4>='\u0000' && LA20_4<='&')||(LA20_4>='(' && LA20_4<='\uFFFF')) ) {
                            alt20=4;
                        }


                    }
                    else if ( ((LA20_1>='\u0000' && LA20_1<='&')||(LA20_1>='(' && LA20_1<='\uFFFF')) ) {
                        alt20=3;
                    }


                }
                else if ( ((LA20_0>='\u0000' && LA20_0<='&')||(LA20_0>='(' && LA20_0<='[')||(LA20_0>=']' && LA20_0<='\uFFFF')) ) {
                    alt20=1;
                }
                else if ( (LA20_0=='\\') ) {
                    alt20=2;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalMyDsl.g:2074:39: ~ ( ( '\\'' | '\\\\' ) )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;
            	case 2 :
            	    // InternalMyDsl.g:2074:54: RULE_ECHAR
            	    {
            	    mRULE_ECHAR(); 

            	    }
            	    break;
            	case 3 :
            	    // InternalMyDsl.g:2074:65: '\\'' ~ ( '\\'' )
            	    {
            	    match('\''); 
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;
            	case 4 :
            	    // InternalMyDsl.g:2074:78: '\\'\\'' ~ ( '\\'' )
            	    {
            	    match("''"); 

            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            match("'''"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_STRING_LITERAL_LONG1"

    // $ANTLR start "RULE_STRING_LITERAL_LONG2"
    public final void mRULE_STRING_LITERAL_LONG2() throws RecognitionException {
        try {
            int _type = RULE_STRING_LITERAL_LONG2;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2076:27: ( '\"\"\"' (~ ( ( '\"' | '\\\\' ) ) | RULE_ECHAR | '\"' ~ ( '\"' ) | '\"\"' ~ ( '\"' ) )* '\"\"\"' )
            // InternalMyDsl.g:2076:29: '\"\"\"' (~ ( ( '\"' | '\\\\' ) ) | RULE_ECHAR | '\"' ~ ( '\"' ) | '\"\"' ~ ( '\"' ) )* '\"\"\"'
            {
            match("\"\"\""); 

            // InternalMyDsl.g:2076:35: (~ ( ( '\"' | '\\\\' ) ) | RULE_ECHAR | '\"' ~ ( '\"' ) | '\"\"' ~ ( '\"' ) )*
            loop21:
            do {
                int alt21=5;
                int LA21_0 = input.LA(1);

                if ( (LA21_0=='\"') ) {
                    int LA21_1 = input.LA(2);

                    if ( (LA21_1=='\"') ) {
                        int LA21_4 = input.LA(3);

                        if ( ((LA21_4>='\u0000' && LA21_4<='!')||(LA21_4>='#' && LA21_4<='\uFFFF')) ) {
                            alt21=4;
                        }


                    }
                    else if ( ((LA21_1>='\u0000' && LA21_1<='!')||(LA21_1>='#' && LA21_1<='\uFFFF')) ) {
                        alt21=3;
                    }


                }
                else if ( ((LA21_0>='\u0000' && LA21_0<='!')||(LA21_0>='#' && LA21_0<='[')||(LA21_0>=']' && LA21_0<='\uFFFF')) ) {
                    alt21=1;
                }
                else if ( (LA21_0=='\\') ) {
                    alt21=2;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalMyDsl.g:2076:36: ~ ( ( '\"' | '\\\\' ) )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;
            	case 2 :
            	    // InternalMyDsl.g:2076:50: RULE_ECHAR
            	    {
            	    mRULE_ECHAR(); 

            	    }
            	    break;
            	case 3 :
            	    // InternalMyDsl.g:2076:61: '\"' ~ ( '\"' )
            	    {
            	    match('\"'); 
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;
            	case 4 :
            	    // InternalMyDsl.g:2076:72: '\"\"' ~ ( '\"' )
            	    {
            	    match("\"\""); 

            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

            match("\"\"\""); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_STRING_LITERAL_LONG2"

    // $ANTLR start "RULE_ECHAR"
    public final void mRULE_ECHAR() throws RecognitionException {
        try {
            // InternalMyDsl.g:2078:21: ( '\\\\' ( 't' | 'b' | 'n' | 'r' | 'f' | '\\\\' | '\"' | '\\'' ) )
            // InternalMyDsl.g:2078:23: '\\\\' ( 't' | 'b' | 'n' | 'r' | 'f' | '\\\\' | '\"' | '\\'' )
            {
            match('\\'); 
            if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='b'||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_ECHAR"

    // $ANTLR start "RULE_IRI"
    public final void mRULE_IRI() throws RecognitionException {
        try {
            int _type = RULE_IRI;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2080:10: ( '<' (~ ( ( '>' | '<' | '\"' | '{' | '}' | '^' | '\\\\' | '|' | '`' | '\\u0000' .. ' ' ) ) )* '>' )
            // InternalMyDsl.g:2080:12: '<' (~ ( ( '>' | '<' | '\"' | '{' | '}' | '^' | '\\\\' | '|' | '`' | '\\u0000' .. ' ' ) ) )* '>'
            {
            match('<'); 
            // InternalMyDsl.g:2080:16: (~ ( ( '>' | '<' | '\"' | '{' | '}' | '^' | '\\\\' | '|' | '`' | '\\u0000' .. ' ' ) ) )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0=='!'||(LA22_0>='#' && LA22_0<=';')||LA22_0=='='||(LA22_0>='?' && LA22_0<='[')||LA22_0==']'||LA22_0=='_'||(LA22_0>='a' && LA22_0<='z')||(LA22_0>='~' && LA22_0<='\uFFFF')) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalMyDsl.g:2080:16: ~ ( ( '>' | '<' | '\"' | '{' | '}' | '^' | '\\\\' | '|' | '`' | '\\u0000' .. ' ' ) )
            	    {
            	    if ( input.LA(1)=='!'||(input.LA(1)>='#' && input.LA(1)<=';')||input.LA(1)=='='||(input.LA(1)>='?' && input.LA(1)<='[')||input.LA(1)==']'||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='~' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

            match('>'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_IRI"

    // $ANTLR start "RULE_PNAME_LN"
    public final void mRULE_PNAME_LN() throws RecognitionException {
        try {
            int _type = RULE_PNAME_LN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2082:15: ( ( RULE_PN_PREFIX )? ':' RULE_PN_LOCAL )
            // InternalMyDsl.g:2082:17: ( RULE_PN_PREFIX )? ':' RULE_PN_LOCAL
            {
            // InternalMyDsl.g:2082:17: ( RULE_PN_PREFIX )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( ((LA23_0>='A' && LA23_0<='Z')||(LA23_0>='a' && LA23_0<='z')||(LA23_0>='\u00C0' && LA23_0<='\u00D6')||(LA23_0>='\u00D8' && LA23_0<='\u00F6')||(LA23_0>='\u00F8' && LA23_0<='\u02FF')||(LA23_0>='\u0370' && LA23_0<='\u037D')||(LA23_0>='\u037F' && LA23_0<='\u1FFF')||(LA23_0>='\u200C' && LA23_0<='\u200D')||(LA23_0>='\u2070' && LA23_0<='\u218F')||(LA23_0>='\u2C00' && LA23_0<='\u2FEF')||(LA23_0>='\u3001' && LA23_0<='\uD7FF')||(LA23_0>='\uF900' && LA23_0<='\uFFFD')) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalMyDsl.g:2082:17: RULE_PN_PREFIX
                    {
                    mRULE_PN_PREFIX(); 

                    }
                    break;

            }

            match(':'); 
            mRULE_PN_LOCAL(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_PNAME_LN"

    // $ANTLR start "RULE_PNAME_NS"
    public final void mRULE_PNAME_NS() throws RecognitionException {
        try {
            int _type = RULE_PNAME_NS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2084:15: ( RULE_PN_PREFIX ':' )
            // InternalMyDsl.g:2084:17: RULE_PN_PREFIX ':'
            {
            mRULE_PN_PREFIX(); 
            match(':'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_PNAME_NS"

    // $ANTLR start "RULE_UNIVAR"
    public final void mRULE_UNIVAR() throws RecognitionException {
        try {
            int _type = RULE_UNIVAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2086:13: ( RULE_QMARK RULE_VARORPREDNAME )
            // InternalMyDsl.g:2086:15: RULE_QMARK RULE_VARORPREDNAME
            {
            mRULE_QMARK(); 
            mRULE_VARORPREDNAME(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_UNIVAR"

    // $ANTLR start "RULE_EXIVAR"
    public final void mRULE_EXIVAR() throws RecognitionException {
        try {
            int _type = RULE_EXIVAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2088:13: ( RULE_EMARK RULE_VARORPREDNAME )
            // InternalMyDsl.g:2088:15: RULE_EMARK RULE_VARORPREDNAME
            {
            mRULE_EMARK(); 
            mRULE_VARORPREDNAME(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_EXIVAR"

    // $ANTLR start "RULE_LANGTAG"
    public final void mRULE_LANGTAG() throws RecognitionException {
        try {
            int _type = RULE_LANGTAG;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2090:14: ( RULE_AT ( RULE_A2Z )+ ( '-' ( RULE_A2ZN )+ )* )
            // InternalMyDsl.g:2090:16: RULE_AT ( RULE_A2Z )+ ( '-' ( RULE_A2ZN )+ )*
            {
            mRULE_AT(); 
            // InternalMyDsl.g:2090:24: ( RULE_A2Z )+
            int cnt24=0;
            loop24:
            do {
                int alt24=2;
                int LA24_0 = input.LA(1);

                if ( ((LA24_0>='A' && LA24_0<='Z')||(LA24_0>='a' && LA24_0<='z')) ) {
                    alt24=1;
                }


                switch (alt24) {
            	case 1 :
            	    // InternalMyDsl.g:2090:24: RULE_A2Z
            	    {
            	    mRULE_A2Z(); 

            	    }
            	    break;

            	default :
            	    if ( cnt24 >= 1 ) break loop24;
                        EarlyExitException eee =
                            new EarlyExitException(24, input);
                        throw eee;
                }
                cnt24++;
            } while (true);

            // InternalMyDsl.g:2090:34: ( '-' ( RULE_A2ZN )+ )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0=='-') ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalMyDsl.g:2090:35: '-' ( RULE_A2ZN )+
            	    {
            	    match('-'); 
            	    // InternalMyDsl.g:2090:39: ( RULE_A2ZN )+
            	    int cnt25=0;
            	    loop25:
            	    do {
            	        int alt25=2;
            	        int LA25_0 = input.LA(1);

            	        if ( ((LA25_0>='0' && LA25_0<='9')||(LA25_0>='A' && LA25_0<='Z')||(LA25_0>='a' && LA25_0<='z')) ) {
            	            alt25=1;
            	        }


            	        switch (alt25) {
            	    	case 1 :
            	    	    // InternalMyDsl.g:2090:39: RULE_A2ZN
            	    	    {
            	    	    mRULE_A2ZN(); 

            	    	    }
            	    	    break;

            	    	default :
            	    	    if ( cnt25 >= 1 ) break loop25;
            	                EarlyExitException eee =
            	                    new EarlyExitException(25, input);
            	                throw eee;
            	        }
            	        cnt25++;
            	    } while (true);


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_LANGTAG"

    // $ANTLR start "RULE_VARORPREDNAME"
    public final void mRULE_VARORPREDNAME() throws RecognitionException {
        try {
            int _type = RULE_VARORPREDNAME;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2092:20: ( RULE_A2Z ( RULE_A2ZN )* )
            // InternalMyDsl.g:2092:22: RULE_A2Z ( RULE_A2ZN )*
            {
            mRULE_A2Z(); 
            // InternalMyDsl.g:2092:31: ( RULE_A2ZN )*
            loop27:
            do {
                int alt27=2;
                int LA27_0 = input.LA(1);

                if ( ((LA27_0>='0' && LA27_0<='9')||(LA27_0>='A' && LA27_0<='Z')||(LA27_0>='a' && LA27_0<='z')) ) {
                    alt27=1;
                }


                switch (alt27) {
            	case 1 :
            	    // InternalMyDsl.g:2092:31: RULE_A2ZN
            	    {
            	    mRULE_A2ZN(); 

            	    }
            	    break;

            	default :
            	    break loop27;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_VARORPREDNAME"

    // $ANTLR start "RULE_A2Z"
    public final void mRULE_A2Z() throws RecognitionException {
        try {
            // InternalMyDsl.g:2094:19: ( ( 'a' .. 'z' | 'A' .. 'Z' ) )
            // InternalMyDsl.g:2094:21: ( 'a' .. 'z' | 'A' .. 'Z' )
            {
            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_A2Z"

    // $ANTLR start "RULE_A2ZN"
    public final void mRULE_A2ZN() throws RecognitionException {
        try {
            // InternalMyDsl.g:2096:20: ( ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' ) )
            // InternalMyDsl.g:2096:22: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' )
            {
            if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_A2ZN"

    // $ANTLR start "RULE_DIRECTIVENAME"
    public final void mRULE_DIRECTIVENAME() throws RecognitionException {
        try {
            int _type = RULE_DIRECTIVENAME;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2098:20: ( RULE_A2Z ( RULE_A2ZNX )* )
            // InternalMyDsl.g:2098:22: RULE_A2Z ( RULE_A2ZNX )*
            {
            mRULE_A2Z(); 
            // InternalMyDsl.g:2098:31: ( RULE_A2ZNX )*
            loop28:
            do {
                int alt28=2;
                int LA28_0 = input.LA(1);

                if ( (LA28_0=='-'||(LA28_0>='0' && LA28_0<='9')||(LA28_0>='A' && LA28_0<='Z')||LA28_0=='_'||(LA28_0>='a' && LA28_0<='z')) ) {
                    alt28=1;
                }


                switch (alt28) {
            	case 1 :
            	    // InternalMyDsl.g:2098:31: RULE_A2ZNX
            	    {
            	    mRULE_A2ZNX(); 

            	    }
            	    break;

            	default :
            	    break loop28;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_DIRECTIVENAME"

    // $ANTLR start "RULE_A2ZNX"
    public final void mRULE_A2ZNX() throws RecognitionException {
        try {
            // InternalMyDsl.g:2100:21: ( ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '-' | '_' ) )
            // InternalMyDsl.g:2100:23: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '-' | '_' )
            {
            if ( input.LA(1)=='-'||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_A2ZNX"

    // $ANTLR start "RULE_LPAREN"
    public final void mRULE_LPAREN() throws RecognitionException {
        try {
            int _type = RULE_LPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2102:13: ( '(' )
            // InternalMyDsl.g:2102:15: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_LPAREN"

    // $ANTLR start "RULE_RPAREN"
    public final void mRULE_RPAREN() throws RecognitionException {
        try {
            int _type = RULE_RPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2104:13: ( ')' )
            // InternalMyDsl.g:2104:15: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_RPAREN"

    // $ANTLR start "RULE_LBRACK"
    public final void mRULE_LBRACK() throws RecognitionException {
        try {
            int _type = RULE_LBRACK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2106:13: ( '[' )
            // InternalMyDsl.g:2106:15: '['
            {
            match('['); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_LBRACK"

    // $ANTLR start "RULE_RBRACK"
    public final void mRULE_RBRACK() throws RecognitionException {
        try {
            int _type = RULE_RBRACK;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2108:13: ( ']' )
            // InternalMyDsl.g:2108:15: ']'
            {
            match(']'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_RBRACK"

    // $ANTLR start "RULE_COMMA"
    public final void mRULE_COMMA() throws RecognitionException {
        try {
            int _type = RULE_COMMA;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2110:12: ( ',' )
            // InternalMyDsl.g:2110:14: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_COMMA"

    // $ANTLR start "RULE_DOT"
    public final void mRULE_DOT() throws RecognitionException {
        try {
            int _type = RULE_DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2112:10: ( '.' )
            // InternalMyDsl.g:2112:12: '.'
            {
            match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_DOT"

    // $ANTLR start "RULE_ARROW"
    public final void mRULE_ARROW() throws RecognitionException {
        try {
            int _type = RULE_ARROW;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2114:12: ( ':-' )
            // InternalMyDsl.g:2114:14: ':-'
            {
            match(":-"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_ARROW"

    // $ANTLR start "RULE_QMARK"
    public final void mRULE_QMARK() throws RecognitionException {
        try {
            // InternalMyDsl.g:2116:21: ( '?' )
            // InternalMyDsl.g:2116:23: '?'
            {
            match('?'); 

            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_QMARK"

    // $ANTLR start "RULE_EMARK"
    public final void mRULE_EMARK() throws RecognitionException {
        try {
            // InternalMyDsl.g:2118:21: ( '!' )
            // InternalMyDsl.g:2118:23: '!'
            {
            match('!'); 

            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_EMARK"

    // $ANTLR start "RULE_TILDE"
    public final void mRULE_TILDE() throws RecognitionException {
        try {
            int _type = RULE_TILDE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2120:12: ( '~' )
            // InternalMyDsl.g:2120:14: '~'
            {
            match('~'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_TILDE"

    // $ANTLR start "RULE_COLON"
    public final void mRULE_COLON() throws RecognitionException {
        try {
            int _type = RULE_COLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2122:12: ( ':' )
            // InternalMyDsl.g:2122:14: ':'
            {
            match(':'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_COLON"

    // $ANTLR start "RULE_DATATYPE"
    public final void mRULE_DATATYPE() throws RecognitionException {
        try {
            int _type = RULE_DATATYPE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalMyDsl.g:2124:15: ( '^^' )
            // InternalMyDsl.g:2124:17: '^^'
            {
            match("^^"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RULE_DATATYPE"

    // $ANTLR start "RULE_AT"
    public final void mRULE_AT() throws RecognitionException {
        try {
            // InternalMyDsl.g:2126:18: ( '@' )
            // InternalMyDsl.g:2126:20: '@'
            {
            match('@'); 

            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_AT"

    // $ANTLR start "RULE_PN_CHARS_BASE"
    public final void mRULE_PN_CHARS_BASE() throws RecognitionException {
        try {
            // InternalMyDsl.g:2128:29: ( ( 'A' .. 'Z' | 'a' .. 'z' | '\\u00C0' .. '\\u00D6' | '\\u00D8' .. '\\u00F6' | '\\u00F8' .. '\\u02FF' | '\\u0370' .. '\\u037D' | '\\u037F' .. '\\u1FFF' | '\\u200C' .. '\\u200D' | '\\u2070' .. '\\u218F' | '\\u2C00' .. '\\u2FEF' | '\\u3001' .. '\\uD7FF' | '\\uF900' .. '\\uFFFD' ) )
            // InternalMyDsl.g:2128:31: ( 'A' .. 'Z' | 'a' .. 'z' | '\\u00C0' .. '\\u00D6' | '\\u00D8' .. '\\u00F6' | '\\u00F8' .. '\\u02FF' | '\\u0370' .. '\\u037D' | '\\u037F' .. '\\u1FFF' | '\\u200C' .. '\\u200D' | '\\u2070' .. '\\u218F' | '\\u2C00' .. '\\u2FEF' | '\\u3001' .. '\\uD7FF' | '\\uF900' .. '\\uFFFD' )
            {
            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u02FF')||(input.LA(1)>='\u0370' && input.LA(1)<='\u037D')||(input.LA(1)>='\u037F' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u200C' && input.LA(1)<='\u200D')||(input.LA(1)>='\u2070' && input.LA(1)<='\u218F')||(input.LA(1)>='\u2C00' && input.LA(1)<='\u2FEF')||(input.LA(1)>='\u3001' && input.LA(1)<='\uD7FF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFFFD') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_PN_CHARS_BASE"

    // $ANTLR start "RULE_PN_CHARS_U"
    public final void mRULE_PN_CHARS_U() throws RecognitionException {
        try {
            // InternalMyDsl.g:2130:26: ( ( RULE_PN_CHARS_BASE | '_' ) )
            // InternalMyDsl.g:2130:28: ( RULE_PN_CHARS_BASE | '_' )
            {
            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u02FF')||(input.LA(1)>='\u0370' && input.LA(1)<='\u037D')||(input.LA(1)>='\u037F' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u200C' && input.LA(1)<='\u200D')||(input.LA(1)>='\u2070' && input.LA(1)<='\u218F')||(input.LA(1)>='\u2C00' && input.LA(1)<='\u2FEF')||(input.LA(1)>='\u3001' && input.LA(1)<='\uD7FF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFFFD') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_PN_CHARS_U"

    // $ANTLR start "RULE_PN_CHARS"
    public final void mRULE_PN_CHARS() throws RecognitionException {
        try {
            // InternalMyDsl.g:2132:24: ( ( RULE_PN_CHARS_U | '-' | '0' .. '9' | '\\u00B7' | '\\u0300' .. '\\u036F' | '\\u203F' .. '\\u2040' ) )
            // InternalMyDsl.g:2132:26: ( RULE_PN_CHARS_U | '-' | '0' .. '9' | '\\u00B7' | '\\u0300' .. '\\u036F' | '\\u203F' .. '\\u2040' )
            {
            if ( input.LA(1)=='-'||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||input.LA(1)=='\u00B7'||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u037D')||(input.LA(1)>='\u037F' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u200C' && input.LA(1)<='\u200D')||(input.LA(1)>='\u203F' && input.LA(1)<='\u2040')||(input.LA(1)>='\u2070' && input.LA(1)<='\u218F')||(input.LA(1)>='\u2C00' && input.LA(1)<='\u2FEF')||(input.LA(1)>='\u3001' && input.LA(1)<='\uD7FF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFFFD') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_PN_CHARS"

    // $ANTLR start "RULE_PN_PREFIX"
    public final void mRULE_PN_PREFIX() throws RecognitionException {
        try {
            // InternalMyDsl.g:2134:25: ( RULE_PN_CHARS_BASE ( ( RULE_PN_CHARS | '.' )* RULE_PN_CHARS )? )
            // InternalMyDsl.g:2134:27: RULE_PN_CHARS_BASE ( ( RULE_PN_CHARS | '.' )* RULE_PN_CHARS )?
            {
            mRULE_PN_CHARS_BASE(); 
            // InternalMyDsl.g:2134:46: ( ( RULE_PN_CHARS | '.' )* RULE_PN_CHARS )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( ((LA30_0>='-' && LA30_0<='.')||(LA30_0>='0' && LA30_0<='9')||(LA30_0>='A' && LA30_0<='Z')||LA30_0=='_'||(LA30_0>='a' && LA30_0<='z')||LA30_0=='\u00B7'||(LA30_0>='\u00C0' && LA30_0<='\u00D6')||(LA30_0>='\u00D8' && LA30_0<='\u00F6')||(LA30_0>='\u00F8' && LA30_0<='\u037D')||(LA30_0>='\u037F' && LA30_0<='\u1FFF')||(LA30_0>='\u200C' && LA30_0<='\u200D')||(LA30_0>='\u203F' && LA30_0<='\u2040')||(LA30_0>='\u2070' && LA30_0<='\u218F')||(LA30_0>='\u2C00' && LA30_0<='\u2FEF')||(LA30_0>='\u3001' && LA30_0<='\uD7FF')||(LA30_0>='\uF900' && LA30_0<='\uFFFD')) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalMyDsl.g:2134:47: ( RULE_PN_CHARS | '.' )* RULE_PN_CHARS
                    {
                    // InternalMyDsl.g:2134:47: ( RULE_PN_CHARS | '.' )*
                    loop29:
                    do {
                        int alt29=2;
                        int LA29_0 = input.LA(1);

                        if ( (LA29_0=='-'||(LA29_0>='0' && LA29_0<='9')||(LA29_0>='A' && LA29_0<='Z')||LA29_0=='_'||(LA29_0>='a' && LA29_0<='z')||LA29_0=='\u00B7'||(LA29_0>='\u00C0' && LA29_0<='\u00D6')||(LA29_0>='\u00D8' && LA29_0<='\u00F6')||(LA29_0>='\u00F8' && LA29_0<='\u037D')||(LA29_0>='\u037F' && LA29_0<='\u1FFF')||(LA29_0>='\u200C' && LA29_0<='\u200D')||(LA29_0>='\u203F' && LA29_0<='\u2040')||(LA29_0>='\u2070' && LA29_0<='\u218F')||(LA29_0>='\u2C00' && LA29_0<='\u2FEF')||(LA29_0>='\u3001' && LA29_0<='\uD7FF')||(LA29_0>='\uF900' && LA29_0<='\uFFFD')) ) {
                            int LA29_1 = input.LA(2);

                            if ( ((LA29_1>='-' && LA29_1<='.')||(LA29_1>='0' && LA29_1<='9')||(LA29_1>='A' && LA29_1<='Z')||LA29_1=='_'||(LA29_1>='a' && LA29_1<='z')||LA29_1=='\u00B7'||(LA29_1>='\u00C0' && LA29_1<='\u00D6')||(LA29_1>='\u00D8' && LA29_1<='\u00F6')||(LA29_1>='\u00F8' && LA29_1<='\u037D')||(LA29_1>='\u037F' && LA29_1<='\u1FFF')||(LA29_1>='\u200C' && LA29_1<='\u200D')||(LA29_1>='\u203F' && LA29_1<='\u2040')||(LA29_1>='\u2070' && LA29_1<='\u218F')||(LA29_1>='\u2C00' && LA29_1<='\u2FEF')||(LA29_1>='\u3001' && LA29_1<='\uD7FF')||(LA29_1>='\uF900' && LA29_1<='\uFFFD')) ) {
                                alt29=1;
                            }


                        }
                        else if ( (LA29_0=='.') ) {
                            alt29=1;
                        }


                        switch (alt29) {
                    	case 1 :
                    	    // InternalMyDsl.g:
                    	    {
                    	    if ( (input.LA(1)>='-' && input.LA(1)<='.')||(input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||input.LA(1)=='\u00B7'||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u037D')||(input.LA(1)>='\u037F' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u200C' && input.LA(1)<='\u200D')||(input.LA(1)>='\u203F' && input.LA(1)<='\u2040')||(input.LA(1)>='\u2070' && input.LA(1)<='\u218F')||(input.LA(1)>='\u2C00' && input.LA(1)<='\u2FEF')||(input.LA(1)>='\u3001' && input.LA(1)<='\uD7FF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFFFD') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;}


                    	    }
                    	    break;

                    	default :
                    	    break loop29;
                        }
                    } while (true);

                    mRULE_PN_CHARS(); 

                    }
                    break;

            }


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_PN_PREFIX"

    // $ANTLR start "RULE_PN_LOCAL"
    public final void mRULE_PN_LOCAL() throws RecognitionException {
        try {
            // InternalMyDsl.g:2136:24: ( ( RULE_PN_CHARS_U | ':' | '0' .. '9' ) ( ( RULE_PN_CHARS | '.' | ':' )* RULE_PN_CHARS )? )
            // InternalMyDsl.g:2136:26: ( RULE_PN_CHARS_U | ':' | '0' .. '9' ) ( ( RULE_PN_CHARS | '.' | ':' )* RULE_PN_CHARS )?
            {
            if ( (input.LA(1)>='0' && input.LA(1)<=':')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u02FF')||(input.LA(1)>='\u0370' && input.LA(1)<='\u037D')||(input.LA(1)>='\u037F' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u200C' && input.LA(1)<='\u200D')||(input.LA(1)>='\u2070' && input.LA(1)<='\u218F')||(input.LA(1)>='\u2C00' && input.LA(1)<='\u2FEF')||(input.LA(1)>='\u3001' && input.LA(1)<='\uD7FF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFFFD') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

            // InternalMyDsl.g:2136:57: ( ( RULE_PN_CHARS | '.' | ':' )* RULE_PN_CHARS )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( ((LA32_0>='-' && LA32_0<='.')||(LA32_0>='0' && LA32_0<=':')||(LA32_0>='A' && LA32_0<='Z')||LA32_0=='_'||(LA32_0>='a' && LA32_0<='z')||LA32_0=='\u00B7'||(LA32_0>='\u00C0' && LA32_0<='\u00D6')||(LA32_0>='\u00D8' && LA32_0<='\u00F6')||(LA32_0>='\u00F8' && LA32_0<='\u037D')||(LA32_0>='\u037F' && LA32_0<='\u1FFF')||(LA32_0>='\u200C' && LA32_0<='\u200D')||(LA32_0>='\u203F' && LA32_0<='\u2040')||(LA32_0>='\u2070' && LA32_0<='\u218F')||(LA32_0>='\u2C00' && LA32_0<='\u2FEF')||(LA32_0>='\u3001' && LA32_0<='\uD7FF')||(LA32_0>='\uF900' && LA32_0<='\uFFFD')) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalMyDsl.g:2136:58: ( RULE_PN_CHARS | '.' | ':' )* RULE_PN_CHARS
                    {
                    // InternalMyDsl.g:2136:58: ( RULE_PN_CHARS | '.' | ':' )*
                    loop31:
                    do {
                        int alt31=2;
                        int LA31_0 = input.LA(1);

                        if ( (LA31_0=='-'||(LA31_0>='0' && LA31_0<='9')||(LA31_0>='A' && LA31_0<='Z')||LA31_0=='_'||(LA31_0>='a' && LA31_0<='z')||LA31_0=='\u00B7'||(LA31_0>='\u00C0' && LA31_0<='\u00D6')||(LA31_0>='\u00D8' && LA31_0<='\u00F6')||(LA31_0>='\u00F8' && LA31_0<='\u037D')||(LA31_0>='\u037F' && LA31_0<='\u1FFF')||(LA31_0>='\u200C' && LA31_0<='\u200D')||(LA31_0>='\u203F' && LA31_0<='\u2040')||(LA31_0>='\u2070' && LA31_0<='\u218F')||(LA31_0>='\u2C00' && LA31_0<='\u2FEF')||(LA31_0>='\u3001' && LA31_0<='\uD7FF')||(LA31_0>='\uF900' && LA31_0<='\uFFFD')) ) {
                            int LA31_1 = input.LA(2);

                            if ( ((LA31_1>='-' && LA31_1<='.')||(LA31_1>='0' && LA31_1<=':')||(LA31_1>='A' && LA31_1<='Z')||LA31_1=='_'||(LA31_1>='a' && LA31_1<='z')||LA31_1=='\u00B7'||(LA31_1>='\u00C0' && LA31_1<='\u00D6')||(LA31_1>='\u00D8' && LA31_1<='\u00F6')||(LA31_1>='\u00F8' && LA31_1<='\u037D')||(LA31_1>='\u037F' && LA31_1<='\u1FFF')||(LA31_1>='\u200C' && LA31_1<='\u200D')||(LA31_1>='\u203F' && LA31_1<='\u2040')||(LA31_1>='\u2070' && LA31_1<='\u218F')||(LA31_1>='\u2C00' && LA31_1<='\u2FEF')||(LA31_1>='\u3001' && LA31_1<='\uD7FF')||(LA31_1>='\uF900' && LA31_1<='\uFFFD')) ) {
                                alt31=1;
                            }


                        }
                        else if ( (LA31_0=='.'||LA31_0==':') ) {
                            alt31=1;
                        }


                        switch (alt31) {
                    	case 1 :
                    	    // InternalMyDsl.g:
                    	    {
                    	    if ( (input.LA(1)>='-' && input.LA(1)<='.')||(input.LA(1)>='0' && input.LA(1)<=':')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z')||input.LA(1)=='\u00B7'||(input.LA(1)>='\u00C0' && input.LA(1)<='\u00D6')||(input.LA(1)>='\u00D8' && input.LA(1)<='\u00F6')||(input.LA(1)>='\u00F8' && input.LA(1)<='\u037D')||(input.LA(1)>='\u037F' && input.LA(1)<='\u1FFF')||(input.LA(1)>='\u200C' && input.LA(1)<='\u200D')||(input.LA(1)>='\u203F' && input.LA(1)<='\u2040')||(input.LA(1)>='\u2070' && input.LA(1)<='\u218F')||(input.LA(1)>='\u2C00' && input.LA(1)<='\u2FEF')||(input.LA(1)>='\u3001' && input.LA(1)<='\uD7FF')||(input.LA(1)>='\uF900' && input.LA(1)<='\uFFFD') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse = new MismatchedSetException(null,input);
                    	        recover(mse);
                    	        throw mse;}


                    	    }
                    	    break;

                    	default :
                    	    break loop31;
                        }
                    } while (true);

                    mRULE_PN_CHARS(); 

                    }
                    break;

            }


            }

        }
        finally {
        }
    }
    // $ANTLR end "RULE_PN_LOCAL"

    public void mTokens() throws RecognitionException {
        // InternalMyDsl.g:1:8: ( RULE_E | RULE_PRFX | RULE_BS | RULE_SRC | RULE_LOADCSV | RULE_LOADRDF | RULE_SPARQL | RULE_INTEGER | RULE_DECIMAL | RULE_DOUBLE | RULE_SKIP | RULE_STRING_LITERAL1 | RULE_STRING_LITERAL2 | RULE_STRING_LITERAL_LONG1 | RULE_STRING_LITERAL_LONG2 | RULE_IRI | RULE_PNAME_LN | RULE_PNAME_NS | RULE_UNIVAR | RULE_EXIVAR | RULE_LANGTAG | RULE_VARORPREDNAME | RULE_DIRECTIVENAME | RULE_LPAREN | RULE_RPAREN | RULE_LBRACK | RULE_RBRACK | RULE_COMMA | RULE_DOT | RULE_ARROW | RULE_TILDE | RULE_COLON | RULE_DATATYPE )
        int alt33=33;
        alt33 = dfa33.predict(input);
        switch (alt33) {
            case 1 :
                // InternalMyDsl.g:1:10: RULE_E
                {
                mRULE_E(); 

                }
                break;
            case 2 :
                // InternalMyDsl.g:1:17: RULE_PRFX
                {
                mRULE_PRFX(); 

                }
                break;
            case 3 :
                // InternalMyDsl.g:1:27: RULE_BS
                {
                mRULE_BS(); 

                }
                break;
            case 4 :
                // InternalMyDsl.g:1:35: RULE_SRC
                {
                mRULE_SRC(); 

                }
                break;
            case 5 :
                // InternalMyDsl.g:1:44: RULE_LOADCSV
                {
                mRULE_LOADCSV(); 

                }
                break;
            case 6 :
                // InternalMyDsl.g:1:57: RULE_LOADRDF
                {
                mRULE_LOADRDF(); 

                }
                break;
            case 7 :
                // InternalMyDsl.g:1:70: RULE_SPARQL
                {
                mRULE_SPARQL(); 

                }
                break;
            case 8 :
                // InternalMyDsl.g:1:82: RULE_INTEGER
                {
                mRULE_INTEGER(); 

                }
                break;
            case 9 :
                // InternalMyDsl.g:1:95: RULE_DECIMAL
                {
                mRULE_DECIMAL(); 

                }
                break;
            case 10 :
                // InternalMyDsl.g:1:108: RULE_DOUBLE
                {
                mRULE_DOUBLE(); 

                }
                break;
            case 11 :
                // InternalMyDsl.g:1:120: RULE_SKIP
                {
                mRULE_SKIP(); 

                }
                break;
            case 12 :
                // InternalMyDsl.g:1:130: RULE_STRING_LITERAL1
                {
                mRULE_STRING_LITERAL1(); 

                }
                break;
            case 13 :
                // InternalMyDsl.g:1:151: RULE_STRING_LITERAL2
                {
                mRULE_STRING_LITERAL2(); 

                }
                break;
            case 14 :
                // InternalMyDsl.g:1:172: RULE_STRING_LITERAL_LONG1
                {
                mRULE_STRING_LITERAL_LONG1(); 

                }
                break;
            case 15 :
                // InternalMyDsl.g:1:198: RULE_STRING_LITERAL_LONG2
                {
                mRULE_STRING_LITERAL_LONG2(); 

                }
                break;
            case 16 :
                // InternalMyDsl.g:1:224: RULE_IRI
                {
                mRULE_IRI(); 

                }
                break;
            case 17 :
                // InternalMyDsl.g:1:233: RULE_PNAME_LN
                {
                mRULE_PNAME_LN(); 

                }
                break;
            case 18 :
                // InternalMyDsl.g:1:247: RULE_PNAME_NS
                {
                mRULE_PNAME_NS(); 

                }
                break;
            case 19 :
                // InternalMyDsl.g:1:261: RULE_UNIVAR
                {
                mRULE_UNIVAR(); 

                }
                break;
            case 20 :
                // InternalMyDsl.g:1:273: RULE_EXIVAR
                {
                mRULE_EXIVAR(); 

                }
                break;
            case 21 :
                // InternalMyDsl.g:1:285: RULE_LANGTAG
                {
                mRULE_LANGTAG(); 

                }
                break;
            case 22 :
                // InternalMyDsl.g:1:298: RULE_VARORPREDNAME
                {
                mRULE_VARORPREDNAME(); 

                }
                break;
            case 23 :
                // InternalMyDsl.g:1:317: RULE_DIRECTIVENAME
                {
                mRULE_DIRECTIVENAME(); 

                }
                break;
            case 24 :
                // InternalMyDsl.g:1:336: RULE_LPAREN
                {
                mRULE_LPAREN(); 

                }
                break;
            case 25 :
                // InternalMyDsl.g:1:348: RULE_RPAREN
                {
                mRULE_RPAREN(); 

                }
                break;
            case 26 :
                // InternalMyDsl.g:1:360: RULE_LBRACK
                {
                mRULE_LBRACK(); 

                }
                break;
            case 27 :
                // InternalMyDsl.g:1:372: RULE_RBRACK
                {
                mRULE_RBRACK(); 

                }
                break;
            case 28 :
                // InternalMyDsl.g:1:384: RULE_COMMA
                {
                mRULE_COMMA(); 

                }
                break;
            case 29 :
                // InternalMyDsl.g:1:395: RULE_DOT
                {
                mRULE_DOT(); 

                }
                break;
            case 30 :
                // InternalMyDsl.g:1:404: RULE_ARROW
                {
                mRULE_ARROW(); 

                }
                break;
            case 31 :
                // InternalMyDsl.g:1:415: RULE_TILDE
                {
                mRULE_TILDE(); 

                }
                break;
            case 32 :
                // InternalMyDsl.g:1:426: RULE_COLON
                {
                mRULE_COLON(); 

                }
                break;
            case 33 :
                // InternalMyDsl.g:1:437: RULE_DATATYPE
                {
                mRULE_DATATYPE(); 

                }
                break;

        }

    }


    protected DFA12 dfa12 = new DFA12(this);
    protected DFA33 dfa33 = new DFA33(this);
    static final String DFA12_eotS =
        "\5\uffff";
    static final String DFA12_eofS =
        "\5\uffff";
    static final String DFA12_minS =
        "\2\56\3\uffff";
    static final String DFA12_maxS =
        "\1\71\1\145\3\uffff";
    static final String DFA12_acceptS =
        "\2\uffff\1\2\1\3\1\1";
    static final String DFA12_specialS =
        "\5\uffff}>";
    static final String[] DFA12_transitionS = {
            "\1\2\1\uffff\12\1",
            "\1\4\1\uffff\12\1\13\uffff\1\3\37\uffff\1\3",
            "",
            "",
            ""
    };

    static final short[] DFA12_eot = DFA.unpackEncodedString(DFA12_eotS);
    static final short[] DFA12_eof = DFA.unpackEncodedString(DFA12_eofS);
    static final char[] DFA12_min = DFA.unpackEncodedStringToUnsignedChars(DFA12_minS);
    static final char[] DFA12_max = DFA.unpackEncodedStringToUnsignedChars(DFA12_maxS);
    static final short[] DFA12_accept = DFA.unpackEncodedString(DFA12_acceptS);
    static final short[] DFA12_special = DFA.unpackEncodedString(DFA12_specialS);
    static final short[][] DFA12_transition;

    static {
        int numStates = DFA12_transitionS.length;
        DFA12_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA12_transition[i] = DFA.unpackEncodedString(DFA12_transitionS[i]);
        }
    }

    class DFA12 extends DFA {

        public DFA12(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 12;
            this.eot = DFA12_eot;
            this.eof = DFA12_eof;
            this.min = DFA12_min;
            this.max = DFA12_max;
            this.accept = DFA12_accept;
            this.special = DFA12_special;
            this.transition = DFA12_transition;
        }
        public String getDescription() {
            return "2062:26: ( ( '0' .. '9' )+ '.' ( '0' .. '9' )* RULE_EXPONENT | '.' ( '0' .. '9' )+ RULE_EXPONENT | ( '0' .. '9' )+ RULE_EXPONENT )";
        }
    }
    static final String DFA33_eotS =
        "\1\1\2\uffff\2\35\1\uffff\1\45\1\50\4\uffff\1\35\1\57\12\uffff\3\33\1\uffff\1\35\1\uffff\1\35\1\uffff\1\65\1\66\1\uffff\1\35\2\uffff\1\71\2\uffff\1\71\1\53\1\uffff\1\55\4\uffff\3\33\1\35\2\uffff\1\35\1\71\3\uffff\3\33\2\35\3\33\1\66\1\35\1\33\1\uffff\1\33\2\66\1\120\1\33\1\122\2\66\3\uffff\1\125\1\126\2\uffff";
    static final String DFA33_eofS =
        "\127\uffff";
    static final String DFA33_minS =
        "\1\11\1\uffff\1\101\2\55\2\56\1\60\1\uffff\2\0\1\uffff\2\55\2\uffff\1\55\7\uffff\1\162\1\141\1\157\1\uffff\1\55\1\uffff\2\55\1\60\3\55\1\60\1\uffff\1\60\2\uffff\1\60\1\47\1\uffff\1\42\4\uffff\1\145\1\163\1\165\1\55\2\uffff\1\55\1\60\3\uffff\1\146\1\145\1\162\2\55\1\151\1\40\1\143\2\55\1\170\1\uffff\1\145\3\55\1\40\3\55\3\uffff\2\55\2\uffff";
    static final String DFA33_maxS =
        "\1\ufffd\1\uffff\1\172\2\ufffd\1\71\1\145\1\71\1\uffff\2\uffff\1\uffff\2\ufffd\2\uffff\1\ufffd\7\uffff\1\162\1\141\1\157\1\uffff\1\ufffd\1\uffff\6\ufffd\1\71\1\uffff\1\145\2\uffff\1\145\1\47\1\uffff\1\42\4\uffff\1\145\1\163\1\165\1\ufffd\2\uffff\1\ufffd\1\145\3\uffff\1\146\1\145\1\162\2\ufffd\1\151\1\40\1\143\2\ufffd\1\170\1\uffff\1\145\3\ufffd\1\40\1\172\2\ufffd\3\uffff\2\ufffd\2\uffff";
    static final String DFA33_acceptS =
        "\1\uffff\1\1\6\uffff\1\13\2\uffff\1\20\2\uffff\1\23\1\24\1\uffff\1\30\1\31\1\32\1\33\1\34\1\37\1\41\3\uffff\1\25\1\uffff\1\26\7\uffff\1\10\1\uffff\1\12\1\35\2\uffff\1\14\1\uffff\1\15\1\36\1\40\1\21\4\uffff\1\22\1\27\2\uffff\1\11\1\16\1\17\13\uffff\1\3\10\uffff\1\7\1\2\1\4\2\uffff\1\5\1\6";
    static final String DFA33_specialS =
        "\11\uffff\1\0\1\1\114\uffff}>";
    static final String[] DFA33_transitionS = {
            "\2\10\1\uffff\2\10\22\uffff\1\10\1\17\1\12\2\uffff\1\10\1\uffff\1\11\1\21\1\22\1\uffff\1\5\1\25\1\5\1\7\1\uffff\12\6\1\15\1\uffff\1\13\2\uffff\1\16\1\2\32\14\1\23\1\uffff\1\24\1\27\2\uffff\13\14\1\3\6\14\1\4\7\14\3\uffff\1\26\101\uffff\27\20\1\uffff\37\20\1\uffff\u0208\20\160\uffff\16\20\1\uffff\u1c81\20\14\uffff\2\20\142\uffff\u0120\20\u0a70\uffff\u03f0\20\21\uffff\ua7ff\20\u2100\uffff\u06fe\20",
            "",
            "\32\33\6\uffff\1\33\1\31\15\33\1\30\2\33\1\32\7\33",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\16\36\1\34\13\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\17\36\1\43\12\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\44\1\uffff\12\6",
            "\1\46\1\uffff\12\6\13\uffff\1\47\37\uffff\1\47",
            "\12\51",
            "",
            "\12\53\1\uffff\2\53\1\uffff\31\53\1\52\uffd8\53",
            "\12\55\1\uffff\2\55\1\uffff\24\55\1\54\uffdd\55",
            "",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\32\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\56\2\uffff\13\60\6\uffff\32\60\4\uffff\1\60\1\uffff\32\60\105\uffff\27\60\1\uffff\37\60\1\uffff\u0208\60\160\uffff\16\60\1\uffff\u1c81\60\14\uffff\2\60\142\uffff\u0120\60\u0a70\uffff\u03f0\60\21\uffff\ua7ff\60\u2100\uffff\u06fe\60",
            "",
            "",
            "\1\42\1\37\1\uffff\12\42\1\40\6\uffff\32\42\4\uffff\1\42\1\uffff\32\42\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\61",
            "\1\62",
            "\1\63",
            "",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\1\64\31\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\32\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\42\1\37\1\uffff\12\42\7\uffff\32\42\4\uffff\1\42\1\uffff\32\42\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\13\60\6\uffff\32\60\4\uffff\1\60\1\uffff\32\60\105\uffff\27\60\1\uffff\37\60\1\uffff\u0208\60\160\uffff\16\60\1\uffff\u1c81\60\14\uffff\2\60\142\uffff\u0120\60\u0a70\uffff\u03f0\60\21\uffff\ua7ff\60\u2100\uffff\u06fe\60",
            "\1\41\1\37\1\uffff\12\41\1\40\6\uffff\32\41\4\uffff\1\41\1\uffff\32\41\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\42\1\37\1\uffff\12\42\1\40\6\uffff\32\42\4\uffff\1\42\1\uffff\32\42\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\1\67\31\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\12\51",
            "",
            "\12\70\13\uffff\1\47\37\uffff\1\47",
            "",
            "",
            "\12\51\13\uffff\1\47\37\uffff\1\47",
            "\1\72",
            "",
            "\1\73",
            "",
            "",
            "",
            "",
            "\1\74",
            "\1\75",
            "\1\76",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\3\36\1\77\26\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "",
            "",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\21\36\1\100\10\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\12\70\13\uffff\1\47\37\uffff\1\47",
            "",
            "",
            "",
            "\1\101",
            "\1\102",
            "\1\103",
            "\1\104\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\32\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\20\36\1\105\11\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\106",
            "\1\107",
            "\1\110",
            "\1\41\1\37\1\uffff\12\41\1\40\6\uffff\32\41\4\uffff\1\41\1\uffff\2\41\1\111\16\41\1\112\10\41\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\13\36\1\113\16\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\114",
            "",
            "\1\115",
            "\1\41\1\37\1\uffff\12\41\1\40\6\uffff\32\41\4\uffff\1\41\1\uffff\22\41\1\116\7\41\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\41\1\37\1\uffff\12\41\1\40\6\uffff\32\41\4\uffff\1\41\1\uffff\3\41\1\117\26\41\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\41\1\37\1\uffff\12\36\1\40\6\uffff\32\36\4\uffff\1\41\1\uffff\32\36\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\121",
            "\1\33\23\uffff\32\33\6\uffff\32\33",
            "\1\41\1\37\1\uffff\12\41\1\40\6\uffff\32\41\4\uffff\1\41\1\uffff\25\41\1\123\4\41\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\41\1\37\1\uffff\12\41\1\40\6\uffff\32\41\4\uffff\1\41\1\uffff\5\41\1\124\24\41\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "",
            "",
            "",
            "\1\41\1\37\1\uffff\12\41\1\40\6\uffff\32\41\4\uffff\1\41\1\uffff\32\41\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "\1\41\1\37\1\uffff\12\41\1\40\6\uffff\32\41\4\uffff\1\41\1\uffff\32\41\74\uffff\1\42\10\uffff\27\42\1\uffff\37\42\1\uffff\u0286\42\1\uffff\u1c81\42\14\uffff\2\42\61\uffff\2\42\57\uffff\u0120\42\u0a70\uffff\u03f0\42\21\uffff\ua7ff\42\u2100\uffff\u06fe\42",
            "",
            ""
    };

    static final short[] DFA33_eot = DFA.unpackEncodedString(DFA33_eotS);
    static final short[] DFA33_eof = DFA.unpackEncodedString(DFA33_eofS);
    static final char[] DFA33_min = DFA.unpackEncodedStringToUnsignedChars(DFA33_minS);
    static final char[] DFA33_max = DFA.unpackEncodedStringToUnsignedChars(DFA33_maxS);
    static final short[] DFA33_accept = DFA.unpackEncodedString(DFA33_acceptS);
    static final short[] DFA33_special = DFA.unpackEncodedString(DFA33_specialS);
    static final short[][] DFA33_transition;

    static {
        int numStates = DFA33_transitionS.length;
        DFA33_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA33_transition[i] = DFA.unpackEncodedString(DFA33_transitionS[i]);
        }
    }

    class DFA33 extends DFA {

        public DFA33(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 33;
            this.eot = DFA33_eot;
            this.eof = DFA33_eof;
            this.min = DFA33_min;
            this.max = DFA33_max;
            this.accept = DFA33_accept;
            this.special = DFA33_special;
            this.transition = DFA33_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( RULE_E | RULE_PRFX | RULE_BS | RULE_SRC | RULE_LOADCSV | RULE_LOADRDF | RULE_SPARQL | RULE_INTEGER | RULE_DECIMAL | RULE_DOUBLE | RULE_SKIP | RULE_STRING_LITERAL1 | RULE_STRING_LITERAL2 | RULE_STRING_LITERAL_LONG1 | RULE_STRING_LITERAL_LONG2 | RULE_IRI | RULE_PNAME_LN | RULE_PNAME_NS | RULE_UNIVAR | RULE_EXIVAR | RULE_LANGTAG | RULE_VARORPREDNAME | RULE_DIRECTIVENAME | RULE_LPAREN | RULE_RPAREN | RULE_LBRACK | RULE_RBRACK | RULE_COMMA | RULE_DOT | RULE_ARROW | RULE_TILDE | RULE_COLON | RULE_DATATYPE );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            IntStream input = _input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA33_9 = input.LA(1);

                        s = -1;
                        if ( (LA33_9=='\'') ) {s = 42;}

                        else if ( ((LA33_9>='\u0000' && LA33_9<='\t')||(LA33_9>='\u000B' && LA33_9<='\f')||(LA33_9>='\u000E' && LA33_9<='&')||(LA33_9>='(' && LA33_9<='\uFFFF')) ) {s = 43;}

                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA33_10 = input.LA(1);

                        s = -1;
                        if ( (LA33_10=='\"') ) {s = 44;}

                        else if ( ((LA33_10>='\u0000' && LA33_10<='\t')||(LA33_10>='\u000B' && LA33_10<='\f')||(LA33_10>='\u000E' && LA33_10<='!')||(LA33_10>='#' && LA33_10<='\uFFFF')) ) {s = 45;}

                        if ( s>=0 ) return s;
                        break;
            }
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 33, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

}