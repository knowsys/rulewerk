package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_PNAME_LN", "RULE_IRI", "RULE_STRING_LITERAL1", "RULE_STRING_LITERAL2", "RULE_STRING_LITERAL_LONG1", "RULE_STRING_LITERAL_LONG2", "RULE_LANGTAG", "RULE_DATATYPE", "RULE_INTEGER", "RULE_DECIMAL", "RULE_DOUBLE", "RULE_UNIVAR", "RULE_EXIVAR", "RULE_VARORPREDNAME", "RULE_COMMA", "RULE_TILDE", "RULE_LPAREN", "RULE_RPAREN", "RULE_ARROW", "RULE_DOT", "RULE_E", "RULE_LOADCSV", "RULE_LOADRDF", "RULE_SPARQL", "RULE_SRC", "RULE_COLON", "RULE_PRFX", "RULE_PNAME_NS", "RULE_BS", "RULE_DIGITS", "RULE_EXPONENT", "RULE_SKIP", "RULE_ECHAR", "RULE_PN_PREFIX", "RULE_PN_LOCAL", "RULE_QMARK", "RULE_EMARK", "RULE_AT", "RULE_A2Z", "RULE_A2ZN", "RULE_A2ZNX", "RULE_DIRECTIVENAME", "RULE_LBRACK", "RULE_RBRACK", "RULE_PN_CHARS_BASE", "RULE_PN_CHARS_U", "RULE_PN_CHARS"
    };
    public static final int RULE_LPAREN=20;
    public static final int RULE_PRFX=30;
    public static final int RULE_ARROW=22;
    public static final int RULE_A2Z=42;
    public static final int RULE_A2ZNX=44;
    public static final int RULE_PNAME_LN=4;
    public static final int RULE_COMMA=18;
    public static final int RULE_DATATYPE=11;
    public static final int RULE_COLON=29;
    public static final int RULE_DECIMAL=13;
    public static final int RULE_DIRECTIVENAME=45;
    public static final int RULE_TILDE=19;
    public static final int RULE_SPARQL=27;
    public static final int RULE_PN_PREFIX=37;
    public static final int RULE_ECHAR=36;
    public static final int RULE_EXIVAR=16;
    public static final int RULE_SRC=28;
    public static final int RULE_EMARK=40;
    public static final int RULE_PN_CHARS_BASE=48;
    public static final int RULE_STRING_LITERAL1=6;
    public static final int RULE_STRING_LITERAL2=7;
    public static final int RULE_IRI=5;
    public static final int RULE_VARORPREDNAME=17;
    public static final int RULE_QMARK=39;
    public static final int RULE_A2ZN=43;
    public static final int RULE_STRING_LITERAL_LONG1=8;
    public static final int RULE_STRING_LITERAL_LONG2=9;
    public static final int RULE_SKIP=35;
    public static final int RULE_DIGITS=33;
    public static final int RULE_AT=41;
    public static final int RULE_PN_LOCAL=38;
    public static final int RULE_DOUBLE=14;
    public static final int RULE_UNIVAR=15;
    public static final int RULE_PNAME_NS=31;
    public static final int RULE_DOT=23;
    public static final int EOF=-1;
    public static final int RULE_LANGTAG=10;
    public static final int RULE_RBRACK=47;
    public static final int RULE_PN_CHARS=50;
    public static final int RULE_LOADRDF=26;
    public static final int RULE_BS=32;
    public static final int RULE_RPAREN=21;
    public static final int RULE_EXPONENT=34;
    public static final int RULE_PN_CHARS_U=49;
    public static final int RULE_E=24;
    public static final int RULE_LOADCSV=25;
    public static final int RULE_INTEGER=12;
    public static final int RULE_LBRACK=46;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }



     	private MyDslGrammarAccess grammarAccess;

        public InternalMyDslParser(TokenStream input, MyDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected MyDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalMyDsl.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalMyDsl.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalMyDsl.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalMyDsl.g:71:1: ruleModel returns [EObject current=null] : ( ( (lv_b_0_0= ruleBase ) )? ( (lv_p_1_0= rulePrefix ) )* ( (lv_s_2_0= ruleSource ) )* ( (lv_st_3_0= ruleStatement ) )* ) ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_b_0_0 = null;

        EObject lv_p_1_0 = null;

        EObject lv_s_2_0 = null;

        EObject lv_st_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:77:2: ( ( ( (lv_b_0_0= ruleBase ) )? ( (lv_p_1_0= rulePrefix ) )* ( (lv_s_2_0= ruleSource ) )* ( (lv_st_3_0= ruleStatement ) )* ) )
            // InternalMyDsl.g:78:2: ( ( (lv_b_0_0= ruleBase ) )? ( (lv_p_1_0= rulePrefix ) )* ( (lv_s_2_0= ruleSource ) )* ( (lv_st_3_0= ruleStatement ) )* )
            {
            // InternalMyDsl.g:78:2: ( ( (lv_b_0_0= ruleBase ) )? ( (lv_p_1_0= rulePrefix ) )* ( (lv_s_2_0= ruleSource ) )* ( (lv_st_3_0= ruleStatement ) )* )
            // InternalMyDsl.g:79:3: ( (lv_b_0_0= ruleBase ) )? ( (lv_p_1_0= rulePrefix ) )* ( (lv_s_2_0= ruleSource ) )* ( (lv_st_3_0= ruleStatement ) )*
            {
            // InternalMyDsl.g:79:3: ( (lv_b_0_0= ruleBase ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_BS) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyDsl.g:80:4: (lv_b_0_0= ruleBase )
                    {
                    // InternalMyDsl.g:80:4: (lv_b_0_0= ruleBase )
                    // InternalMyDsl.g:81:5: lv_b_0_0= ruleBase
                    {

                    					newCompositeNode(grammarAccess.getModelAccess().getBBaseParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_3);
                    lv_b_0_0=ruleBase();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getModelRule());
                    					}
                    					add(
                    						current,
                    						"b",
                    						lv_b_0_0,
                    						"org.xtext.example.mydsl.MyDsl.Base");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalMyDsl.g:98:3: ( (lv_p_1_0= rulePrefix ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==RULE_PRFX) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalMyDsl.g:99:4: (lv_p_1_0= rulePrefix )
            	    {
            	    // InternalMyDsl.g:99:4: (lv_p_1_0= rulePrefix )
            	    // InternalMyDsl.g:100:5: lv_p_1_0= rulePrefix
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getPPrefixParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_p_1_0=rulePrefix();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"p",
            	    						lv_p_1_0,
            	    						"org.xtext.example.mydsl.MyDsl.Prefix");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            // InternalMyDsl.g:117:3: ( (lv_s_2_0= ruleSource ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==RULE_SRC) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalMyDsl.g:118:4: (lv_s_2_0= ruleSource )
            	    {
            	    // InternalMyDsl.g:118:4: (lv_s_2_0= ruleSource )
            	    // InternalMyDsl.g:119:5: lv_s_2_0= ruleSource
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getSSourceParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_s_2_0=ruleSource();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"s",
            	    						lv_s_2_0,
            	    						"org.xtext.example.mydsl.MyDsl.Source");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // InternalMyDsl.g:136:3: ( (lv_st_3_0= ruleStatement ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>=RULE_PNAME_LN && LA4_0<=RULE_IRI)||LA4_0==RULE_VARORPREDNAME) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalMyDsl.g:137:4: (lv_st_3_0= ruleStatement )
            	    {
            	    // InternalMyDsl.g:137:4: (lv_st_3_0= ruleStatement )
            	    // InternalMyDsl.g:138:5: lv_st_3_0= ruleStatement
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getStStatementParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_5);
            	    lv_st_3_0=ruleStatement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"st",
            	    						lv_st_3_0,
            	    						"org.xtext.example.mydsl.MyDsl.Statement");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRulePrefixedName"
    // InternalMyDsl.g:159:1: entryRulePrefixedName returns [EObject current=null] : iv_rulePrefixedName= rulePrefixedName EOF ;
    public final EObject entryRulePrefixedName() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrefixedName = null;


        try {
            // InternalMyDsl.g:159:53: (iv_rulePrefixedName= rulePrefixedName EOF )
            // InternalMyDsl.g:160:2: iv_rulePrefixedName= rulePrefixedName EOF
            {
             newCompositeNode(grammarAccess.getPrefixedNameRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrefixedName=rulePrefixedName();

            state._fsp--;

             current =iv_rulePrefixedName; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrefixedName"


    // $ANTLR start "rulePrefixedName"
    // InternalMyDsl.g:166:1: rulePrefixedName returns [EObject current=null] : ( (lv_t_0_0= RULE_PNAME_LN ) ) ;
    public final EObject rulePrefixedName() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:172:2: ( ( (lv_t_0_0= RULE_PNAME_LN ) ) )
            // InternalMyDsl.g:173:2: ( (lv_t_0_0= RULE_PNAME_LN ) )
            {
            // InternalMyDsl.g:173:2: ( (lv_t_0_0= RULE_PNAME_LN ) )
            // InternalMyDsl.g:174:3: (lv_t_0_0= RULE_PNAME_LN )
            {
            // InternalMyDsl.g:174:3: (lv_t_0_0= RULE_PNAME_LN )
            // InternalMyDsl.g:175:4: lv_t_0_0= RULE_PNAME_LN
            {
            lv_t_0_0=(Token)match(input,RULE_PNAME_LN,FOLLOW_2); 

            				newLeafNode(lv_t_0_0, grammarAccess.getPrefixedNameAccess().getTPNAME_LNTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getPrefixedNameRule());
            				}
            				setWithLastConsumed(
            					current,
            					"t",
            					lv_t_0_0,
            					"org.xtext.example.mydsl.MyDsl.PNAME_LN");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrefixedName"


    // $ANTLR start "entryRuleIRIREF"
    // InternalMyDsl.g:194:1: entryRuleIRIREF returns [EObject current=null] : iv_ruleIRIREF= ruleIRIREF EOF ;
    public final EObject entryRuleIRIREF() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIRIREF = null;


        try {
            // InternalMyDsl.g:194:47: (iv_ruleIRIREF= ruleIRIREF EOF )
            // InternalMyDsl.g:195:2: iv_ruleIRIREF= ruleIRIREF EOF
            {
             newCompositeNode(grammarAccess.getIRIREFRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIRIREF=ruleIRIREF();

            state._fsp--;

             current =iv_ruleIRIREF; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIRIREF"


    // $ANTLR start "ruleIRIREF"
    // InternalMyDsl.g:201:1: ruleIRIREF returns [EObject current=null] : ( (lv_t_0_0= RULE_IRI ) ) ;
    public final EObject ruleIRIREF() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:207:2: ( ( (lv_t_0_0= RULE_IRI ) ) )
            // InternalMyDsl.g:208:2: ( (lv_t_0_0= RULE_IRI ) )
            {
            // InternalMyDsl.g:208:2: ( (lv_t_0_0= RULE_IRI ) )
            // InternalMyDsl.g:209:3: (lv_t_0_0= RULE_IRI )
            {
            // InternalMyDsl.g:209:3: (lv_t_0_0= RULE_IRI )
            // InternalMyDsl.g:210:4: lv_t_0_0= RULE_IRI
            {
            lv_t_0_0=(Token)match(input,RULE_IRI,FOLLOW_2); 

            				newLeafNode(lv_t_0_0, grammarAccess.getIRIREFAccess().getTIRITerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getIRIREFRule());
            				}
            				setWithLastConsumed(
            					current,
            					"t",
            					lv_t_0_0,
            					"org.xtext.example.mydsl.MyDsl.IRI");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIRIREF"


    // $ANTLR start "entryRuleIRIBOL"
    // InternalMyDsl.g:229:1: entryRuleIRIBOL returns [EObject current=null] : iv_ruleIRIBOL= ruleIRIBOL EOF ;
    public final EObject entryRuleIRIBOL() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIRIBOL = null;


        try {
            // InternalMyDsl.g:229:47: (iv_ruleIRIBOL= ruleIRIBOL EOF )
            // InternalMyDsl.g:230:2: iv_ruleIRIBOL= ruleIRIBOL EOF
            {
             newCompositeNode(grammarAccess.getIRIBOLRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIRIBOL=ruleIRIBOL();

            state._fsp--;

             current =iv_ruleIRIBOL; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIRIBOL"


    // $ANTLR start "ruleIRIBOL"
    // InternalMyDsl.g:236:1: ruleIRIBOL returns [EObject current=null] : ( ( (lv_t_0_0= ruleIRIREF ) ) | ( (lv_t_1_0= rulePrefixedName ) ) ) ;
    public final EObject ruleIRIBOL() throws RecognitionException {
        EObject current = null;

        EObject lv_t_0_0 = null;

        EObject lv_t_1_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:242:2: ( ( ( (lv_t_0_0= ruleIRIREF ) ) | ( (lv_t_1_0= rulePrefixedName ) ) ) )
            // InternalMyDsl.g:243:2: ( ( (lv_t_0_0= ruleIRIREF ) ) | ( (lv_t_1_0= rulePrefixedName ) ) )
            {
            // InternalMyDsl.g:243:2: ( ( (lv_t_0_0= ruleIRIREF ) ) | ( (lv_t_1_0= rulePrefixedName ) ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_IRI) ) {
                alt5=1;
            }
            else if ( (LA5_0==RULE_PNAME_LN) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyDsl.g:244:3: ( (lv_t_0_0= ruleIRIREF ) )
                    {
                    // InternalMyDsl.g:244:3: ( (lv_t_0_0= ruleIRIREF ) )
                    // InternalMyDsl.g:245:4: (lv_t_0_0= ruleIRIREF )
                    {
                    // InternalMyDsl.g:245:4: (lv_t_0_0= ruleIRIREF )
                    // InternalMyDsl.g:246:5: lv_t_0_0= ruleIRIREF
                    {

                    					newCompositeNode(grammarAccess.getIRIBOLAccess().getTIRIREFParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_t_0_0=ruleIRIREF();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getIRIBOLRule());
                    					}
                    					set(
                    						current,
                    						"t",
                    						lv_t_0_0,
                    						"org.xtext.example.mydsl.MyDsl.IRIREF");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:264:3: ( (lv_t_1_0= rulePrefixedName ) )
                    {
                    // InternalMyDsl.g:264:3: ( (lv_t_1_0= rulePrefixedName ) )
                    // InternalMyDsl.g:265:4: (lv_t_1_0= rulePrefixedName )
                    {
                    // InternalMyDsl.g:265:4: (lv_t_1_0= rulePrefixedName )
                    // InternalMyDsl.g:266:5: lv_t_1_0= rulePrefixedName
                    {

                    					newCompositeNode(grammarAccess.getIRIBOLAccess().getTPrefixedNameParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_t_1_0=rulePrefixedName();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getIRIBOLRule());
                    					}
                    					set(
                    						current,
                    						"t",
                    						lv_t_1_0,
                    						"org.xtext.example.mydsl.MyDsl.PrefixedName");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIRIBOL"


    // $ANTLR start "entryRuleStriing"
    // InternalMyDsl.g:287:1: entryRuleStriing returns [EObject current=null] : iv_ruleStriing= ruleStriing EOF ;
    public final EObject entryRuleStriing() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStriing = null;


        try {
            // InternalMyDsl.g:287:48: (iv_ruleStriing= ruleStriing EOF )
            // InternalMyDsl.g:288:2: iv_ruleStriing= ruleStriing EOF
            {
             newCompositeNode(grammarAccess.getStriingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStriing=ruleStriing();

            state._fsp--;

             current =iv_ruleStriing; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStriing"


    // $ANTLR start "ruleStriing"
    // InternalMyDsl.g:294:1: ruleStriing returns [EObject current=null] : ( ( (lv_t_0_0= RULE_STRING_LITERAL1 ) ) | ( (lv_t_1_0= RULE_STRING_LITERAL2 ) ) | ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) ) | ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) ) ) ;
    public final EObject ruleStriing() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;
        Token lv_t_1_0=null;
        Token lv_t_2_0=null;
        Token lv_t_3_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:300:2: ( ( ( (lv_t_0_0= RULE_STRING_LITERAL1 ) ) | ( (lv_t_1_0= RULE_STRING_LITERAL2 ) ) | ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) ) | ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) ) ) )
            // InternalMyDsl.g:301:2: ( ( (lv_t_0_0= RULE_STRING_LITERAL1 ) ) | ( (lv_t_1_0= RULE_STRING_LITERAL2 ) ) | ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) ) | ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) ) )
            {
            // InternalMyDsl.g:301:2: ( ( (lv_t_0_0= RULE_STRING_LITERAL1 ) ) | ( (lv_t_1_0= RULE_STRING_LITERAL2 ) ) | ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) ) | ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) ) )
            int alt6=4;
            switch ( input.LA(1) ) {
            case RULE_STRING_LITERAL1:
                {
                alt6=1;
                }
                break;
            case RULE_STRING_LITERAL2:
                {
                alt6=2;
                }
                break;
            case RULE_STRING_LITERAL_LONG1:
                {
                alt6=3;
                }
                break;
            case RULE_STRING_LITERAL_LONG2:
                {
                alt6=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:302:3: ( (lv_t_0_0= RULE_STRING_LITERAL1 ) )
                    {
                    // InternalMyDsl.g:302:3: ( (lv_t_0_0= RULE_STRING_LITERAL1 ) )
                    // InternalMyDsl.g:303:4: (lv_t_0_0= RULE_STRING_LITERAL1 )
                    {
                    // InternalMyDsl.g:303:4: (lv_t_0_0= RULE_STRING_LITERAL1 )
                    // InternalMyDsl.g:304:5: lv_t_0_0= RULE_STRING_LITERAL1
                    {
                    lv_t_0_0=(Token)match(input,RULE_STRING_LITERAL1,FOLLOW_2); 

                    					newLeafNode(lv_t_0_0, grammarAccess.getStriingAccess().getTSTRING_LITERAL1TerminalRuleCall_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getStriingRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_0_0,
                    						"org.xtext.example.mydsl.MyDsl.STRING_LITERAL1");
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:321:3: ( (lv_t_1_0= RULE_STRING_LITERAL2 ) )
                    {
                    // InternalMyDsl.g:321:3: ( (lv_t_1_0= RULE_STRING_LITERAL2 ) )
                    // InternalMyDsl.g:322:4: (lv_t_1_0= RULE_STRING_LITERAL2 )
                    {
                    // InternalMyDsl.g:322:4: (lv_t_1_0= RULE_STRING_LITERAL2 )
                    // InternalMyDsl.g:323:5: lv_t_1_0= RULE_STRING_LITERAL2
                    {
                    lv_t_1_0=(Token)match(input,RULE_STRING_LITERAL2,FOLLOW_2); 

                    					newLeafNode(lv_t_1_0, grammarAccess.getStriingAccess().getTSTRING_LITERAL2TerminalRuleCall_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getStriingRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_1_0,
                    						"org.xtext.example.mydsl.MyDsl.STRING_LITERAL2");
                    				

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:340:3: ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) )
                    {
                    // InternalMyDsl.g:340:3: ( (lv_t_2_0= RULE_STRING_LITERAL_LONG1 ) )
                    // InternalMyDsl.g:341:4: (lv_t_2_0= RULE_STRING_LITERAL_LONG1 )
                    {
                    // InternalMyDsl.g:341:4: (lv_t_2_0= RULE_STRING_LITERAL_LONG1 )
                    // InternalMyDsl.g:342:5: lv_t_2_0= RULE_STRING_LITERAL_LONG1
                    {
                    lv_t_2_0=(Token)match(input,RULE_STRING_LITERAL_LONG1,FOLLOW_2); 

                    					newLeafNode(lv_t_2_0, grammarAccess.getStriingAccess().getTSTRING_LITERAL_LONG1TerminalRuleCall_2_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getStriingRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_2_0,
                    						"org.xtext.example.mydsl.MyDsl.STRING_LITERAL_LONG1");
                    				

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:359:3: ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) )
                    {
                    // InternalMyDsl.g:359:3: ( (lv_t_3_0= RULE_STRING_LITERAL_LONG2 ) )
                    // InternalMyDsl.g:360:4: (lv_t_3_0= RULE_STRING_LITERAL_LONG2 )
                    {
                    // InternalMyDsl.g:360:4: (lv_t_3_0= RULE_STRING_LITERAL_LONG2 )
                    // InternalMyDsl.g:361:5: lv_t_3_0= RULE_STRING_LITERAL_LONG2
                    {
                    lv_t_3_0=(Token)match(input,RULE_STRING_LITERAL_LONG2,FOLLOW_2); 

                    					newLeafNode(lv_t_3_0, grammarAccess.getStriingAccess().getTSTRING_LITERAL_LONG2TerminalRuleCall_3_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getStriingRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_3_0,
                    						"org.xtext.example.mydsl.MyDsl.STRING_LITERAL_LONG2");
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStriing"


    // $ANTLR start "entryRuleLangtagg"
    // InternalMyDsl.g:381:1: entryRuleLangtagg returns [EObject current=null] : iv_ruleLangtagg= ruleLangtagg EOF ;
    public final EObject entryRuleLangtagg() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLangtagg = null;


        try {
            // InternalMyDsl.g:381:49: (iv_ruleLangtagg= ruleLangtagg EOF )
            // InternalMyDsl.g:382:2: iv_ruleLangtagg= ruleLangtagg EOF
            {
             newCompositeNode(grammarAccess.getLangtaggRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLangtagg=ruleLangtagg();

            state._fsp--;

             current =iv_ruleLangtagg; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLangtagg"


    // $ANTLR start "ruleLangtagg"
    // InternalMyDsl.g:388:1: ruleLangtagg returns [EObject current=null] : ( (lv_t_0_0= RULE_LANGTAG ) ) ;
    public final EObject ruleLangtagg() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:394:2: ( ( (lv_t_0_0= RULE_LANGTAG ) ) )
            // InternalMyDsl.g:395:2: ( (lv_t_0_0= RULE_LANGTAG ) )
            {
            // InternalMyDsl.g:395:2: ( (lv_t_0_0= RULE_LANGTAG ) )
            // InternalMyDsl.g:396:3: (lv_t_0_0= RULE_LANGTAG )
            {
            // InternalMyDsl.g:396:3: (lv_t_0_0= RULE_LANGTAG )
            // InternalMyDsl.g:397:4: lv_t_0_0= RULE_LANGTAG
            {
            lv_t_0_0=(Token)match(input,RULE_LANGTAG,FOLLOW_2); 

            				newLeafNode(lv_t_0_0, grammarAccess.getLangtaggAccess().getTLANGTAGTerminalRuleCall_0());
            			

            				if (current==null) {
            					current = createModelElement(grammarAccess.getLangtaggRule());
            				}
            				setWithLastConsumed(
            					current,
            					"t",
            					lv_t_0_0,
            					"org.xtext.example.mydsl.MyDsl.LANGTAG");
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLangtagg"


    // $ANTLR start "entryRuleRDFLiteral"
    // InternalMyDsl.g:416:1: entryRuleRDFLiteral returns [EObject current=null] : iv_ruleRDFLiteral= ruleRDFLiteral EOF ;
    public final EObject entryRuleRDFLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRDFLiteral = null;


        try {
            // InternalMyDsl.g:416:51: (iv_ruleRDFLiteral= ruleRDFLiteral EOF )
            // InternalMyDsl.g:417:2: iv_ruleRDFLiteral= ruleRDFLiteral EOF
            {
             newCompositeNode(grammarAccess.getRDFLiteralRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRDFLiteral=ruleRDFLiteral();

            state._fsp--;

             current =iv_ruleRDFLiteral; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRDFLiteral"


    // $ANTLR start "ruleRDFLiteral"
    // InternalMyDsl.g:423:1: ruleRDFLiteral returns [EObject current=null] : ( ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )? ) ;
    public final EObject ruleRDFLiteral() throws RecognitionException {
        EObject current = null;

        Token this_DATATYPE_2=null;
        EObject lv_s_0_0 = null;

        EObject lv_l_1_0 = null;

        EObject lv_dt_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:429:2: ( ( ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )? ) )
            // InternalMyDsl.g:430:2: ( ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )? )
            {
            // InternalMyDsl.g:430:2: ( ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )? )
            // InternalMyDsl.g:431:3: ( (lv_s_0_0= ruleStriing ) ) ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )?
            {
            // InternalMyDsl.g:431:3: ( (lv_s_0_0= ruleStriing ) )
            // InternalMyDsl.g:432:4: (lv_s_0_0= ruleStriing )
            {
            // InternalMyDsl.g:432:4: (lv_s_0_0= ruleStriing )
            // InternalMyDsl.g:433:5: lv_s_0_0= ruleStriing
            {

            					newCompositeNode(grammarAccess.getRDFLiteralAccess().getSStriingParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_6);
            lv_s_0_0=ruleStriing();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRDFLiteralRule());
            					}
            					set(
            						current,
            						"s",
            						lv_s_0_0,
            						"org.xtext.example.mydsl.MyDsl.Striing");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:450:3: ( ( (lv_l_1_0= ruleLangtagg ) ) | (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) ) )?
            int alt7=3;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_LANGTAG) ) {
                alt7=1;
            }
            else if ( (LA7_0==RULE_DATATYPE) ) {
                alt7=2;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyDsl.g:451:4: ( (lv_l_1_0= ruleLangtagg ) )
                    {
                    // InternalMyDsl.g:451:4: ( (lv_l_1_0= ruleLangtagg ) )
                    // InternalMyDsl.g:452:5: (lv_l_1_0= ruleLangtagg )
                    {
                    // InternalMyDsl.g:452:5: (lv_l_1_0= ruleLangtagg )
                    // InternalMyDsl.g:453:6: lv_l_1_0= ruleLangtagg
                    {

                    						newCompositeNode(grammarAccess.getRDFLiteralAccess().getLLangtaggParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_l_1_0=ruleLangtagg();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getRDFLiteralRule());
                    						}
                    						set(
                    							current,
                    							"l",
                    							lv_l_1_0,
                    							"org.xtext.example.mydsl.MyDsl.Langtagg");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:471:4: (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) )
                    {
                    // InternalMyDsl.g:471:4: (this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) ) )
                    // InternalMyDsl.g:472:5: this_DATATYPE_2= RULE_DATATYPE ( (lv_dt_3_0= ruleIRIBOL ) )
                    {
                    this_DATATYPE_2=(Token)match(input,RULE_DATATYPE,FOLLOW_7); 

                    					newLeafNode(this_DATATYPE_2, grammarAccess.getRDFLiteralAccess().getDATATYPETerminalRuleCall_1_1_0());
                    				
                    // InternalMyDsl.g:476:5: ( (lv_dt_3_0= ruleIRIBOL ) )
                    // InternalMyDsl.g:477:6: (lv_dt_3_0= ruleIRIBOL )
                    {
                    // InternalMyDsl.g:477:6: (lv_dt_3_0= ruleIRIBOL )
                    // InternalMyDsl.g:478:7: lv_dt_3_0= ruleIRIBOL
                    {

                    							newCompositeNode(grammarAccess.getRDFLiteralAccess().getDtIRIBOLParserRuleCall_1_1_1_0());
                    						
                    pushFollow(FOLLOW_2);
                    lv_dt_3_0=ruleIRIBOL();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getRDFLiteralRule());
                    							}
                    							set(
                    								current,
                    								"dt",
                    								lv_dt_3_0,
                    								"org.xtext.example.mydsl.MyDsl.IRIBOL");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRDFLiteral"


    // $ANTLR start "entryRuleNumericLiteral"
    // InternalMyDsl.g:501:1: entryRuleNumericLiteral returns [EObject current=null] : iv_ruleNumericLiteral= ruleNumericLiteral EOF ;
    public final EObject entryRuleNumericLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNumericLiteral = null;


        try {
            // InternalMyDsl.g:501:55: (iv_ruleNumericLiteral= ruleNumericLiteral EOF )
            // InternalMyDsl.g:502:2: iv_ruleNumericLiteral= ruleNumericLiteral EOF
            {
             newCompositeNode(grammarAccess.getNumericLiteralRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNumericLiteral=ruleNumericLiteral();

            state._fsp--;

             current =iv_ruleNumericLiteral; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNumericLiteral"


    // $ANTLR start "ruleNumericLiteral"
    // InternalMyDsl.g:508:1: ruleNumericLiteral returns [EObject current=null] : ( ( (lv_t_0_0= RULE_INTEGER ) ) | ( (lv_t_1_0= RULE_DECIMAL ) ) | ( (lv_t_2_0= RULE_DOUBLE ) ) ) ;
    public final EObject ruleNumericLiteral() throws RecognitionException {
        EObject current = null;

        Token lv_t_0_0=null;
        Token lv_t_1_0=null;
        Token lv_t_2_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:514:2: ( ( ( (lv_t_0_0= RULE_INTEGER ) ) | ( (lv_t_1_0= RULE_DECIMAL ) ) | ( (lv_t_2_0= RULE_DOUBLE ) ) ) )
            // InternalMyDsl.g:515:2: ( ( (lv_t_0_0= RULE_INTEGER ) ) | ( (lv_t_1_0= RULE_DECIMAL ) ) | ( (lv_t_2_0= RULE_DOUBLE ) ) )
            {
            // InternalMyDsl.g:515:2: ( ( (lv_t_0_0= RULE_INTEGER ) ) | ( (lv_t_1_0= RULE_DECIMAL ) ) | ( (lv_t_2_0= RULE_DOUBLE ) ) )
            int alt8=3;
            switch ( input.LA(1) ) {
            case RULE_INTEGER:
                {
                alt8=1;
                }
                break;
            case RULE_DECIMAL:
                {
                alt8=2;
                }
                break;
            case RULE_DOUBLE:
                {
                alt8=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // InternalMyDsl.g:516:3: ( (lv_t_0_0= RULE_INTEGER ) )
                    {
                    // InternalMyDsl.g:516:3: ( (lv_t_0_0= RULE_INTEGER ) )
                    // InternalMyDsl.g:517:4: (lv_t_0_0= RULE_INTEGER )
                    {
                    // InternalMyDsl.g:517:4: (lv_t_0_0= RULE_INTEGER )
                    // InternalMyDsl.g:518:5: lv_t_0_0= RULE_INTEGER
                    {
                    lv_t_0_0=(Token)match(input,RULE_INTEGER,FOLLOW_2); 

                    					newLeafNode(lv_t_0_0, grammarAccess.getNumericLiteralAccess().getTINTEGERTerminalRuleCall_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getNumericLiteralRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_0_0,
                    						"org.xtext.example.mydsl.MyDsl.INTEGER");
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:535:3: ( (lv_t_1_0= RULE_DECIMAL ) )
                    {
                    // InternalMyDsl.g:535:3: ( (lv_t_1_0= RULE_DECIMAL ) )
                    // InternalMyDsl.g:536:4: (lv_t_1_0= RULE_DECIMAL )
                    {
                    // InternalMyDsl.g:536:4: (lv_t_1_0= RULE_DECIMAL )
                    // InternalMyDsl.g:537:5: lv_t_1_0= RULE_DECIMAL
                    {
                    lv_t_1_0=(Token)match(input,RULE_DECIMAL,FOLLOW_2); 

                    					newLeafNode(lv_t_1_0, grammarAccess.getNumericLiteralAccess().getTDECIMALTerminalRuleCall_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getNumericLiteralRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_1_0,
                    						"org.xtext.example.mydsl.MyDsl.DECIMAL");
                    				

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:554:3: ( (lv_t_2_0= RULE_DOUBLE ) )
                    {
                    // InternalMyDsl.g:554:3: ( (lv_t_2_0= RULE_DOUBLE ) )
                    // InternalMyDsl.g:555:4: (lv_t_2_0= RULE_DOUBLE )
                    {
                    // InternalMyDsl.g:555:4: (lv_t_2_0= RULE_DOUBLE )
                    // InternalMyDsl.g:556:5: lv_t_2_0= RULE_DOUBLE
                    {
                    lv_t_2_0=(Token)match(input,RULE_DOUBLE,FOLLOW_2); 

                    					newLeafNode(lv_t_2_0, grammarAccess.getNumericLiteralAccess().getTDOUBLETerminalRuleCall_2_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getNumericLiteralRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_2_0,
                    						"org.xtext.example.mydsl.MyDsl.DOUBLE");
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNumericLiteral"


    // $ANTLR start "entryRuleTerm"
    // InternalMyDsl.g:576:1: entryRuleTerm returns [EObject current=null] : iv_ruleTerm= ruleTerm EOF ;
    public final EObject entryRuleTerm() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTerm = null;


        try {
            // InternalMyDsl.g:576:45: (iv_ruleTerm= ruleTerm EOF )
            // InternalMyDsl.g:577:2: iv_ruleTerm= ruleTerm EOF
            {
             newCompositeNode(grammarAccess.getTermRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTerm=ruleTerm();

            state._fsp--;

             current =iv_ruleTerm; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTerm"


    // $ANTLR start "ruleTerm"
    // InternalMyDsl.g:583:1: ruleTerm returns [EObject current=null] : ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_c_1_0= ruleNumericLiteral ) ) | ( (lv_s_2_0= ruleRDFLiteral ) ) | ( (lv_t_3_0= RULE_UNIVAR ) ) | ( (lv_t_4_0= RULE_EXIVAR ) ) | ( (lv_t_5_0= RULE_VARORPREDNAME ) ) ) ;
    public final EObject ruleTerm() throws RecognitionException {
        EObject current = null;

        Token lv_t_3_0=null;
        Token lv_t_4_0=null;
        Token lv_t_5_0=null;
        EObject lv_s_0_0 = null;

        EObject lv_c_1_0 = null;

        EObject lv_s_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:589:2: ( ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_c_1_0= ruleNumericLiteral ) ) | ( (lv_s_2_0= ruleRDFLiteral ) ) | ( (lv_t_3_0= RULE_UNIVAR ) ) | ( (lv_t_4_0= RULE_EXIVAR ) ) | ( (lv_t_5_0= RULE_VARORPREDNAME ) ) ) )
            // InternalMyDsl.g:590:2: ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_c_1_0= ruleNumericLiteral ) ) | ( (lv_s_2_0= ruleRDFLiteral ) ) | ( (lv_t_3_0= RULE_UNIVAR ) ) | ( (lv_t_4_0= RULE_EXIVAR ) ) | ( (lv_t_5_0= RULE_VARORPREDNAME ) ) )
            {
            // InternalMyDsl.g:590:2: ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_c_1_0= ruleNumericLiteral ) ) | ( (lv_s_2_0= ruleRDFLiteral ) ) | ( (lv_t_3_0= RULE_UNIVAR ) ) | ( (lv_t_4_0= RULE_EXIVAR ) ) | ( (lv_t_5_0= RULE_VARORPREDNAME ) ) )
            int alt9=6;
            switch ( input.LA(1) ) {
            case RULE_PNAME_LN:
            case RULE_IRI:
                {
                alt9=1;
                }
                break;
            case RULE_INTEGER:
            case RULE_DECIMAL:
            case RULE_DOUBLE:
                {
                alt9=2;
                }
                break;
            case RULE_STRING_LITERAL1:
            case RULE_STRING_LITERAL2:
            case RULE_STRING_LITERAL_LONG1:
            case RULE_STRING_LITERAL_LONG2:
                {
                alt9=3;
                }
                break;
            case RULE_UNIVAR:
                {
                alt9=4;
                }
                break;
            case RULE_EXIVAR:
                {
                alt9=5;
                }
                break;
            case RULE_VARORPREDNAME:
                {
                alt9=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:591:3: ( (lv_s_0_0= ruleIRIBOL ) )
                    {
                    // InternalMyDsl.g:591:3: ( (lv_s_0_0= ruleIRIBOL ) )
                    // InternalMyDsl.g:592:4: (lv_s_0_0= ruleIRIBOL )
                    {
                    // InternalMyDsl.g:592:4: (lv_s_0_0= ruleIRIBOL )
                    // InternalMyDsl.g:593:5: lv_s_0_0= ruleIRIBOL
                    {

                    					newCompositeNode(grammarAccess.getTermAccess().getSIRIBOLParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_s_0_0=ruleIRIBOL();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTermRule());
                    					}
                    					set(
                    						current,
                    						"s",
                    						lv_s_0_0,
                    						"org.xtext.example.mydsl.MyDsl.IRIBOL");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:611:3: ( (lv_c_1_0= ruleNumericLiteral ) )
                    {
                    // InternalMyDsl.g:611:3: ( (lv_c_1_0= ruleNumericLiteral ) )
                    // InternalMyDsl.g:612:4: (lv_c_1_0= ruleNumericLiteral )
                    {
                    // InternalMyDsl.g:612:4: (lv_c_1_0= ruleNumericLiteral )
                    // InternalMyDsl.g:613:5: lv_c_1_0= ruleNumericLiteral
                    {

                    					newCompositeNode(grammarAccess.getTermAccess().getCNumericLiteralParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_c_1_0=ruleNumericLiteral();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTermRule());
                    					}
                    					set(
                    						current,
                    						"c",
                    						lv_c_1_0,
                    						"org.xtext.example.mydsl.MyDsl.NumericLiteral");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:631:3: ( (lv_s_2_0= ruleRDFLiteral ) )
                    {
                    // InternalMyDsl.g:631:3: ( (lv_s_2_0= ruleRDFLiteral ) )
                    // InternalMyDsl.g:632:4: (lv_s_2_0= ruleRDFLiteral )
                    {
                    // InternalMyDsl.g:632:4: (lv_s_2_0= ruleRDFLiteral )
                    // InternalMyDsl.g:633:5: lv_s_2_0= ruleRDFLiteral
                    {

                    					newCompositeNode(grammarAccess.getTermAccess().getSRDFLiteralParserRuleCall_2_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_s_2_0=ruleRDFLiteral();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getTermRule());
                    					}
                    					set(
                    						current,
                    						"s",
                    						lv_s_2_0,
                    						"org.xtext.example.mydsl.MyDsl.RDFLiteral");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:651:3: ( (lv_t_3_0= RULE_UNIVAR ) )
                    {
                    // InternalMyDsl.g:651:3: ( (lv_t_3_0= RULE_UNIVAR ) )
                    // InternalMyDsl.g:652:4: (lv_t_3_0= RULE_UNIVAR )
                    {
                    // InternalMyDsl.g:652:4: (lv_t_3_0= RULE_UNIVAR )
                    // InternalMyDsl.g:653:5: lv_t_3_0= RULE_UNIVAR
                    {
                    lv_t_3_0=(Token)match(input,RULE_UNIVAR,FOLLOW_2); 

                    					newLeafNode(lv_t_3_0, grammarAccess.getTermAccess().getTUNIVARTerminalRuleCall_3_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getTermRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_3_0,
                    						"org.xtext.example.mydsl.MyDsl.UNIVAR");
                    				

                    }


                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:670:3: ( (lv_t_4_0= RULE_EXIVAR ) )
                    {
                    // InternalMyDsl.g:670:3: ( (lv_t_4_0= RULE_EXIVAR ) )
                    // InternalMyDsl.g:671:4: (lv_t_4_0= RULE_EXIVAR )
                    {
                    // InternalMyDsl.g:671:4: (lv_t_4_0= RULE_EXIVAR )
                    // InternalMyDsl.g:672:5: lv_t_4_0= RULE_EXIVAR
                    {
                    lv_t_4_0=(Token)match(input,RULE_EXIVAR,FOLLOW_2); 

                    					newLeafNode(lv_t_4_0, grammarAccess.getTermAccess().getTEXIVARTerminalRuleCall_4_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getTermRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_4_0,
                    						"org.xtext.example.mydsl.MyDsl.EXIVAR");
                    				

                    }


                    }


                    }
                    break;
                case 6 :
                    // InternalMyDsl.g:689:3: ( (lv_t_5_0= RULE_VARORPREDNAME ) )
                    {
                    // InternalMyDsl.g:689:3: ( (lv_t_5_0= RULE_VARORPREDNAME ) )
                    // InternalMyDsl.g:690:4: (lv_t_5_0= RULE_VARORPREDNAME )
                    {
                    // InternalMyDsl.g:690:4: (lv_t_5_0= RULE_VARORPREDNAME )
                    // InternalMyDsl.g:691:5: lv_t_5_0= RULE_VARORPREDNAME
                    {
                    lv_t_5_0=(Token)match(input,RULE_VARORPREDNAME,FOLLOW_2); 

                    					newLeafNode(lv_t_5_0, grammarAccess.getTermAccess().getTVARORPREDNAMETerminalRuleCall_5_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getTermRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_5_0,
                    						"org.xtext.example.mydsl.MyDsl.VARORPREDNAME");
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTerm"


    // $ANTLR start "entryRulepredicateName"
    // InternalMyDsl.g:711:1: entryRulepredicateName returns [EObject current=null] : iv_rulepredicateName= rulepredicateName EOF ;
    public final EObject entryRulepredicateName() throws RecognitionException {
        EObject current = null;

        EObject iv_rulepredicateName = null;


        try {
            // InternalMyDsl.g:711:54: (iv_rulepredicateName= rulepredicateName EOF )
            // InternalMyDsl.g:712:2: iv_rulepredicateName= rulepredicateName EOF
            {
             newCompositeNode(grammarAccess.getPredicateNameRule()); 
            pushFollow(FOLLOW_1);
            iv_rulepredicateName=rulepredicateName();

            state._fsp--;

             current =iv_rulepredicateName; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulepredicateName"


    // $ANTLR start "rulepredicateName"
    // InternalMyDsl.g:718:1: rulepredicateName returns [EObject current=null] : ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_t_1_0= RULE_VARORPREDNAME ) ) ) ;
    public final EObject rulepredicateName() throws RecognitionException {
        EObject current = null;

        Token lv_t_1_0=null;
        EObject lv_s_0_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:724:2: ( ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_t_1_0= RULE_VARORPREDNAME ) ) ) )
            // InternalMyDsl.g:725:2: ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_t_1_0= RULE_VARORPREDNAME ) ) )
            {
            // InternalMyDsl.g:725:2: ( ( (lv_s_0_0= ruleIRIBOL ) ) | ( (lv_t_1_0= RULE_VARORPREDNAME ) ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( ((LA10_0>=RULE_PNAME_LN && LA10_0<=RULE_IRI)) ) {
                alt10=1;
            }
            else if ( (LA10_0==RULE_VARORPREDNAME) ) {
                alt10=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyDsl.g:726:3: ( (lv_s_0_0= ruleIRIBOL ) )
                    {
                    // InternalMyDsl.g:726:3: ( (lv_s_0_0= ruleIRIBOL ) )
                    // InternalMyDsl.g:727:4: (lv_s_0_0= ruleIRIBOL )
                    {
                    // InternalMyDsl.g:727:4: (lv_s_0_0= ruleIRIBOL )
                    // InternalMyDsl.g:728:5: lv_s_0_0= ruleIRIBOL
                    {

                    					newCompositeNode(grammarAccess.getPredicateNameAccess().getSIRIBOLParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_s_0_0=ruleIRIBOL();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPredicateNameRule());
                    					}
                    					set(
                    						current,
                    						"s",
                    						lv_s_0_0,
                    						"org.xtext.example.mydsl.MyDsl.IRIBOL");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:746:3: ( (lv_t_1_0= RULE_VARORPREDNAME ) )
                    {
                    // InternalMyDsl.g:746:3: ( (lv_t_1_0= RULE_VARORPREDNAME ) )
                    // InternalMyDsl.g:747:4: (lv_t_1_0= RULE_VARORPREDNAME )
                    {
                    // InternalMyDsl.g:747:4: (lv_t_1_0= RULE_VARORPREDNAME )
                    // InternalMyDsl.g:748:5: lv_t_1_0= RULE_VARORPREDNAME
                    {
                    lv_t_1_0=(Token)match(input,RULE_VARORPREDNAME,FOLLOW_2); 

                    					newLeafNode(lv_t_1_0, grammarAccess.getPredicateNameAccess().getTVARORPREDNAMETerminalRuleCall_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getPredicateNameRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"t",
                    						lv_t_1_0,
                    						"org.xtext.example.mydsl.MyDsl.VARORPREDNAME");
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulepredicateName"


    // $ANTLR start "entryRulelistOfTerms"
    // InternalMyDsl.g:768:1: entryRulelistOfTerms returns [EObject current=null] : iv_rulelistOfTerms= rulelistOfTerms EOF ;
    public final EObject entryRulelistOfTerms() throws RecognitionException {
        EObject current = null;

        EObject iv_rulelistOfTerms = null;


        try {
            // InternalMyDsl.g:768:52: (iv_rulelistOfTerms= rulelistOfTerms EOF )
            // InternalMyDsl.g:769:2: iv_rulelistOfTerms= rulelistOfTerms EOF
            {
             newCompositeNode(grammarAccess.getListOfTermsRule()); 
            pushFollow(FOLLOW_1);
            iv_rulelistOfTerms=rulelistOfTerms();

            state._fsp--;

             current =iv_rulelistOfTerms; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulelistOfTerms"


    // $ANTLR start "rulelistOfTerms"
    // InternalMyDsl.g:775:1: rulelistOfTerms returns [EObject current=null] : ( ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )* ) ;
    public final EObject rulelistOfTerms() throws RecognitionException {
        EObject current = null;

        Token this_COMMA_1=null;
        EObject lv_t_0_0 = null;

        EObject lv_t_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:781:2: ( ( ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )* ) )
            // InternalMyDsl.g:782:2: ( ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )* )
            {
            // InternalMyDsl.g:782:2: ( ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )* )
            // InternalMyDsl.g:783:3: ( (lv_t_0_0= ruleTerm ) ) (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )*
            {
            // InternalMyDsl.g:783:3: ( (lv_t_0_0= ruleTerm ) )
            // InternalMyDsl.g:784:4: (lv_t_0_0= ruleTerm )
            {
            // InternalMyDsl.g:784:4: (lv_t_0_0= ruleTerm )
            // InternalMyDsl.g:785:5: lv_t_0_0= ruleTerm
            {

            					newCompositeNode(grammarAccess.getListOfTermsAccess().getTTermParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_8);
            lv_t_0_0=ruleTerm();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getListOfTermsRule());
            					}
            					add(
            						current,
            						"t",
            						lv_t_0_0,
            						"org.xtext.example.mydsl.MyDsl.Term");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:802:3: (this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==RULE_COMMA) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalMyDsl.g:803:4: this_COMMA_1= RULE_COMMA ( (lv_t_2_0= ruleTerm ) )
            	    {
            	    this_COMMA_1=(Token)match(input,RULE_COMMA,FOLLOW_9); 

            	    				newLeafNode(this_COMMA_1, grammarAccess.getListOfTermsAccess().getCOMMATerminalRuleCall_1_0());
            	    			
            	    // InternalMyDsl.g:807:4: ( (lv_t_2_0= ruleTerm ) )
            	    // InternalMyDsl.g:808:5: (lv_t_2_0= ruleTerm )
            	    {
            	    // InternalMyDsl.g:808:5: (lv_t_2_0= ruleTerm )
            	    // InternalMyDsl.g:809:6: lv_t_2_0= ruleTerm
            	    {

            	    						newCompositeNode(grammarAccess.getListOfTermsAccess().getTTermParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_8);
            	    lv_t_2_0=ruleTerm();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getListOfTermsRule());
            	    						}
            	    						add(
            	    							current,
            	    							"t",
            	    							lv_t_2_0,
            	    							"org.xtext.example.mydsl.MyDsl.Term");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelistOfTerms"


    // $ANTLR start "entryRuleNegativeLiteral"
    // InternalMyDsl.g:831:1: entryRuleNegativeLiteral returns [EObject current=null] : iv_ruleNegativeLiteral= ruleNegativeLiteral EOF ;
    public final EObject entryRuleNegativeLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleNegativeLiteral = null;


        try {
            // InternalMyDsl.g:831:56: (iv_ruleNegativeLiteral= ruleNegativeLiteral EOF )
            // InternalMyDsl.g:832:2: iv_ruleNegativeLiteral= ruleNegativeLiteral EOF
            {
             newCompositeNode(grammarAccess.getNegativeLiteralRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleNegativeLiteral=ruleNegativeLiteral();

            state._fsp--;

             current =iv_ruleNegativeLiteral; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleNegativeLiteral"


    // $ANTLR start "ruleNegativeLiteral"
    // InternalMyDsl.g:838:1: ruleNegativeLiteral returns [EObject current=null] : (this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN ) ;
    public final EObject ruleNegativeLiteral() throws RecognitionException {
        EObject current = null;

        Token this_TILDE_0=null;
        Token this_LPAREN_2=null;
        Token this_RPAREN_4=null;
        EObject lv_predicatename_1_0 = null;

        EObject lv_terms_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:844:2: ( (this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN ) )
            // InternalMyDsl.g:845:2: (this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN )
            {
            // InternalMyDsl.g:845:2: (this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN )
            // InternalMyDsl.g:846:3: this_TILDE_0= RULE_TILDE ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_terms_3_0= rulelistOfTerms ) ) this_RPAREN_4= RULE_RPAREN
            {
            this_TILDE_0=(Token)match(input,RULE_TILDE,FOLLOW_10); 

            			newLeafNode(this_TILDE_0, grammarAccess.getNegativeLiteralAccess().getTILDETerminalRuleCall_0());
            		
            // InternalMyDsl.g:850:3: ( (lv_predicatename_1_0= rulepredicateName ) )
            // InternalMyDsl.g:851:4: (lv_predicatename_1_0= rulepredicateName )
            {
            // InternalMyDsl.g:851:4: (lv_predicatename_1_0= rulepredicateName )
            // InternalMyDsl.g:852:5: lv_predicatename_1_0= rulepredicateName
            {

            					newCompositeNode(grammarAccess.getNegativeLiteralAccess().getPredicatenamePredicateNameParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_11);
            lv_predicatename_1_0=rulepredicateName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getNegativeLiteralRule());
            					}
            					set(
            						current,
            						"predicatename",
            						lv_predicatename_1_0,
            						"org.xtext.example.mydsl.MyDsl.predicateName");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_LPAREN_2=(Token)match(input,RULE_LPAREN,FOLLOW_9); 

            			newLeafNode(this_LPAREN_2, grammarAccess.getNegativeLiteralAccess().getLPARENTerminalRuleCall_2());
            		
            // InternalMyDsl.g:873:3: ( (lv_terms_3_0= rulelistOfTerms ) )
            // InternalMyDsl.g:874:4: (lv_terms_3_0= rulelistOfTerms )
            {
            // InternalMyDsl.g:874:4: (lv_terms_3_0= rulelistOfTerms )
            // InternalMyDsl.g:875:5: lv_terms_3_0= rulelistOfTerms
            {

            					newCompositeNode(grammarAccess.getNegativeLiteralAccess().getTermsListOfTermsParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_12);
            lv_terms_3_0=rulelistOfTerms();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getNegativeLiteralRule());
            					}
            					set(
            						current,
            						"terms",
            						lv_terms_3_0,
            						"org.xtext.example.mydsl.MyDsl.listOfTerms");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_RPAREN_4=(Token)match(input,RULE_RPAREN,FOLLOW_2); 

            			newLeafNode(this_RPAREN_4, grammarAccess.getNegativeLiteralAccess().getRPARENTerminalRuleCall_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleNegativeLiteral"


    // $ANTLR start "entryRuleFact"
    // InternalMyDsl.g:900:1: entryRuleFact returns [EObject current=null] : iv_ruleFact= ruleFact EOF ;
    public final EObject entryRuleFact() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFact = null;


        try {
            // InternalMyDsl.g:900:45: (iv_ruleFact= ruleFact EOF )
            // InternalMyDsl.g:901:2: iv_ruleFact= ruleFact EOF
            {
             newCompositeNode(grammarAccess.getFactRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFact=ruleFact();

            state._fsp--;

             current =iv_ruleFact; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFact"


    // $ANTLR start "ruleFact"
    // InternalMyDsl.g:907:1: ruleFact returns [EObject current=null] : ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN ) ;
    public final EObject ruleFact() throws RecognitionException {
        EObject current = null;

        Token this_LPAREN_1=null;
        Token this_RPAREN_3=null;
        EObject lv_predicatename_0_0 = null;

        EObject lv_terms_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:913:2: ( ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN ) )
            // InternalMyDsl.g:914:2: ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN )
            {
            // InternalMyDsl.g:914:2: ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN )
            // InternalMyDsl.g:915:3: ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN
            {
            // InternalMyDsl.g:915:3: ( (lv_predicatename_0_0= rulepredicateName ) )
            // InternalMyDsl.g:916:4: (lv_predicatename_0_0= rulepredicateName )
            {
            // InternalMyDsl.g:916:4: (lv_predicatename_0_0= rulepredicateName )
            // InternalMyDsl.g:917:5: lv_predicatename_0_0= rulepredicateName
            {

            					newCompositeNode(grammarAccess.getFactAccess().getPredicatenamePredicateNameParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_11);
            lv_predicatename_0_0=rulepredicateName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFactRule());
            					}
            					set(
            						current,
            						"predicatename",
            						lv_predicatename_0_0,
            						"org.xtext.example.mydsl.MyDsl.predicateName");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_LPAREN_1=(Token)match(input,RULE_LPAREN,FOLLOW_9); 

            			newLeafNode(this_LPAREN_1, grammarAccess.getFactAccess().getLPARENTerminalRuleCall_1());
            		
            // InternalMyDsl.g:938:3: ( (lv_terms_2_0= rulelistOfTerms ) )
            // InternalMyDsl.g:939:4: (lv_terms_2_0= rulelistOfTerms )
            {
            // InternalMyDsl.g:939:4: (lv_terms_2_0= rulelistOfTerms )
            // InternalMyDsl.g:940:5: lv_terms_2_0= rulelistOfTerms
            {

            					newCompositeNode(grammarAccess.getFactAccess().getTermsListOfTermsParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_12);
            lv_terms_2_0=rulelistOfTerms();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getFactRule());
            					}
            					set(
            						current,
            						"terms",
            						lv_terms_2_0,
            						"org.xtext.example.mydsl.MyDsl.listOfTerms");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_RPAREN_3=(Token)match(input,RULE_RPAREN,FOLLOW_2); 

            			newLeafNode(this_RPAREN_3, grammarAccess.getFactAccess().getRPARENTerminalRuleCall_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFact"


    // $ANTLR start "entryRulePositiveLiteral"
    // InternalMyDsl.g:965:1: entryRulePositiveLiteral returns [EObject current=null] : iv_rulePositiveLiteral= rulePositiveLiteral EOF ;
    public final EObject entryRulePositiveLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePositiveLiteral = null;


        try {
            // InternalMyDsl.g:965:56: (iv_rulePositiveLiteral= rulePositiveLiteral EOF )
            // InternalMyDsl.g:966:2: iv_rulePositiveLiteral= rulePositiveLiteral EOF
            {
             newCompositeNode(grammarAccess.getPositiveLiteralRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePositiveLiteral=rulePositiveLiteral();

            state._fsp--;

             current =iv_rulePositiveLiteral; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePositiveLiteral"


    // $ANTLR start "rulePositiveLiteral"
    // InternalMyDsl.g:972:1: rulePositiveLiteral returns [EObject current=null] : ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN ) ;
    public final EObject rulePositiveLiteral() throws RecognitionException {
        EObject current = null;

        Token this_LPAREN_1=null;
        Token this_RPAREN_3=null;
        EObject lv_predicatename_0_0 = null;

        EObject lv_terms_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:978:2: ( ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN ) )
            // InternalMyDsl.g:979:2: ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN )
            {
            // InternalMyDsl.g:979:2: ( ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN )
            // InternalMyDsl.g:980:3: ( (lv_predicatename_0_0= rulepredicateName ) ) this_LPAREN_1= RULE_LPAREN ( (lv_terms_2_0= rulelistOfTerms ) ) this_RPAREN_3= RULE_RPAREN
            {
            // InternalMyDsl.g:980:3: ( (lv_predicatename_0_0= rulepredicateName ) )
            // InternalMyDsl.g:981:4: (lv_predicatename_0_0= rulepredicateName )
            {
            // InternalMyDsl.g:981:4: (lv_predicatename_0_0= rulepredicateName )
            // InternalMyDsl.g:982:5: lv_predicatename_0_0= rulepredicateName
            {

            					newCompositeNode(grammarAccess.getPositiveLiteralAccess().getPredicatenamePredicateNameParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_11);
            lv_predicatename_0_0=rulepredicateName();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPositiveLiteralRule());
            					}
            					set(
            						current,
            						"predicatename",
            						lv_predicatename_0_0,
            						"org.xtext.example.mydsl.MyDsl.predicateName");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_LPAREN_1=(Token)match(input,RULE_LPAREN,FOLLOW_9); 

            			newLeafNode(this_LPAREN_1, grammarAccess.getPositiveLiteralAccess().getLPARENTerminalRuleCall_1());
            		
            // InternalMyDsl.g:1003:3: ( (lv_terms_2_0= rulelistOfTerms ) )
            // InternalMyDsl.g:1004:4: (lv_terms_2_0= rulelistOfTerms )
            {
            // InternalMyDsl.g:1004:4: (lv_terms_2_0= rulelistOfTerms )
            // InternalMyDsl.g:1005:5: lv_terms_2_0= rulelistOfTerms
            {

            					newCompositeNode(grammarAccess.getPositiveLiteralAccess().getTermsListOfTermsParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_12);
            lv_terms_2_0=rulelistOfTerms();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPositiveLiteralRule());
            					}
            					set(
            						current,
            						"terms",
            						lv_terms_2_0,
            						"org.xtext.example.mydsl.MyDsl.listOfTerms");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_RPAREN_3=(Token)match(input,RULE_RPAREN,FOLLOW_2); 

            			newLeafNode(this_RPAREN_3, grammarAccess.getPositiveLiteralAccess().getRPARENTerminalRuleCall_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePositiveLiteral"


    // $ANTLR start "entryRuleLiteral"
    // InternalMyDsl.g:1030:1: entryRuleLiteral returns [EObject current=null] : iv_ruleLiteral= ruleLiteral EOF ;
    public final EObject entryRuleLiteral() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLiteral = null;


        try {
            // InternalMyDsl.g:1030:48: (iv_ruleLiteral= ruleLiteral EOF )
            // InternalMyDsl.g:1031:2: iv_ruleLiteral= ruleLiteral EOF
            {
             newCompositeNode(grammarAccess.getLiteralRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLiteral=ruleLiteral();

            state._fsp--;

             current =iv_ruleLiteral; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLiteral"


    // $ANTLR start "ruleLiteral"
    // InternalMyDsl.g:1037:1: ruleLiteral returns [EObject current=null] : ( ( (lv_l_0_0= rulePositiveLiteral ) ) | ( (lv_l_1_0= ruleNegativeLiteral ) ) ) ;
    public final EObject ruleLiteral() throws RecognitionException {
        EObject current = null;

        EObject lv_l_0_0 = null;

        EObject lv_l_1_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1043:2: ( ( ( (lv_l_0_0= rulePositiveLiteral ) ) | ( (lv_l_1_0= ruleNegativeLiteral ) ) ) )
            // InternalMyDsl.g:1044:2: ( ( (lv_l_0_0= rulePositiveLiteral ) ) | ( (lv_l_1_0= ruleNegativeLiteral ) ) )
            {
            // InternalMyDsl.g:1044:2: ( ( (lv_l_0_0= rulePositiveLiteral ) ) | ( (lv_l_1_0= ruleNegativeLiteral ) ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( ((LA12_0>=RULE_PNAME_LN && LA12_0<=RULE_IRI)||LA12_0==RULE_VARORPREDNAME) ) {
                alt12=1;
            }
            else if ( (LA12_0==RULE_TILDE) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyDsl.g:1045:3: ( (lv_l_0_0= rulePositiveLiteral ) )
                    {
                    // InternalMyDsl.g:1045:3: ( (lv_l_0_0= rulePositiveLiteral ) )
                    // InternalMyDsl.g:1046:4: (lv_l_0_0= rulePositiveLiteral )
                    {
                    // InternalMyDsl.g:1046:4: (lv_l_0_0= rulePositiveLiteral )
                    // InternalMyDsl.g:1047:5: lv_l_0_0= rulePositiveLiteral
                    {

                    					newCompositeNode(grammarAccess.getLiteralAccess().getLPositiveLiteralParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_l_0_0=rulePositiveLiteral();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getLiteralRule());
                    					}
                    					set(
                    						current,
                    						"l",
                    						lv_l_0_0,
                    						"org.xtext.example.mydsl.MyDsl.PositiveLiteral");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1065:3: ( (lv_l_1_0= ruleNegativeLiteral ) )
                    {
                    // InternalMyDsl.g:1065:3: ( (lv_l_1_0= ruleNegativeLiteral ) )
                    // InternalMyDsl.g:1066:4: (lv_l_1_0= ruleNegativeLiteral )
                    {
                    // InternalMyDsl.g:1066:4: (lv_l_1_0= ruleNegativeLiteral )
                    // InternalMyDsl.g:1067:5: lv_l_1_0= ruleNegativeLiteral
                    {

                    					newCompositeNode(grammarAccess.getLiteralAccess().getLNegativeLiteralParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_l_1_0=ruleNegativeLiteral();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getLiteralRule());
                    					}
                    					set(
                    						current,
                    						"l",
                    						lv_l_1_0,
                    						"org.xtext.example.mydsl.MyDsl.NegativeLiteral");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLiteral"


    // $ANTLR start "entryRulelistOfLiterals"
    // InternalMyDsl.g:1088:1: entryRulelistOfLiterals returns [EObject current=null] : iv_rulelistOfLiterals= rulelistOfLiterals EOF ;
    public final EObject entryRulelistOfLiterals() throws RecognitionException {
        EObject current = null;

        EObject iv_rulelistOfLiterals = null;


        try {
            // InternalMyDsl.g:1088:55: (iv_rulelistOfLiterals= rulelistOfLiterals EOF )
            // InternalMyDsl.g:1089:2: iv_rulelistOfLiterals= rulelistOfLiterals EOF
            {
             newCompositeNode(grammarAccess.getListOfLiteralsRule()); 
            pushFollow(FOLLOW_1);
            iv_rulelistOfLiterals=rulelistOfLiterals();

            state._fsp--;

             current =iv_rulelistOfLiterals; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulelistOfLiterals"


    // $ANTLR start "rulelistOfLiterals"
    // InternalMyDsl.g:1095:1: rulelistOfLiterals returns [EObject current=null] : ( ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )* ) ;
    public final EObject rulelistOfLiterals() throws RecognitionException {
        EObject current = null;

        Token this_COMMA_1=null;
        EObject lv_l_0_0 = null;

        EObject lv_l_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1101:2: ( ( ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )* ) )
            // InternalMyDsl.g:1102:2: ( ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )* )
            {
            // InternalMyDsl.g:1102:2: ( ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )* )
            // InternalMyDsl.g:1103:3: ( (lv_l_0_0= ruleLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )*
            {
            // InternalMyDsl.g:1103:3: ( (lv_l_0_0= ruleLiteral ) )
            // InternalMyDsl.g:1104:4: (lv_l_0_0= ruleLiteral )
            {
            // InternalMyDsl.g:1104:4: (lv_l_0_0= ruleLiteral )
            // InternalMyDsl.g:1105:5: lv_l_0_0= ruleLiteral
            {

            					newCompositeNode(grammarAccess.getListOfLiteralsAccess().getLLiteralParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_8);
            lv_l_0_0=ruleLiteral();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getListOfLiteralsRule());
            					}
            					add(
            						current,
            						"l",
            						lv_l_0_0,
            						"org.xtext.example.mydsl.MyDsl.Literal");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:1122:3: (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) ) )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==RULE_COMMA) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalMyDsl.g:1123:4: this_COMMA_1= RULE_COMMA ( (lv_l_2_0= ruleLiteral ) )
            	    {
            	    this_COMMA_1=(Token)match(input,RULE_COMMA,FOLLOW_13); 

            	    				newLeafNode(this_COMMA_1, grammarAccess.getListOfLiteralsAccess().getCOMMATerminalRuleCall_1_0());
            	    			
            	    // InternalMyDsl.g:1127:4: ( (lv_l_2_0= ruleLiteral ) )
            	    // InternalMyDsl.g:1128:5: (lv_l_2_0= ruleLiteral )
            	    {
            	    // InternalMyDsl.g:1128:5: (lv_l_2_0= ruleLiteral )
            	    // InternalMyDsl.g:1129:6: lv_l_2_0= ruleLiteral
            	    {

            	    						newCompositeNode(grammarAccess.getListOfLiteralsAccess().getLLiteralParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_8);
            	    lv_l_2_0=ruleLiteral();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getListOfLiteralsRule());
            	    						}
            	    						add(
            	    							current,
            	    							"l",
            	    							lv_l_2_0,
            	    							"org.xtext.example.mydsl.MyDsl.Literal");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelistOfLiterals"


    // $ANTLR start "entryRulelistOfPositiveLiterals"
    // InternalMyDsl.g:1151:1: entryRulelistOfPositiveLiterals returns [EObject current=null] : iv_rulelistOfPositiveLiterals= rulelistOfPositiveLiterals EOF ;
    public final EObject entryRulelistOfPositiveLiterals() throws RecognitionException {
        EObject current = null;

        EObject iv_rulelistOfPositiveLiterals = null;


        try {
            // InternalMyDsl.g:1151:63: (iv_rulelistOfPositiveLiterals= rulelistOfPositiveLiterals EOF )
            // InternalMyDsl.g:1152:2: iv_rulelistOfPositiveLiterals= rulelistOfPositiveLiterals EOF
            {
             newCompositeNode(grammarAccess.getListOfPositiveLiteralsRule()); 
            pushFollow(FOLLOW_1);
            iv_rulelistOfPositiveLiterals=rulelistOfPositiveLiterals();

            state._fsp--;

             current =iv_rulelistOfPositiveLiterals; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulelistOfPositiveLiterals"


    // $ANTLR start "rulelistOfPositiveLiterals"
    // InternalMyDsl.g:1158:1: rulelistOfPositiveLiterals returns [EObject current=null] : ( ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )* ) ;
    public final EObject rulelistOfPositiveLiterals() throws RecognitionException {
        EObject current = null;

        Token this_COMMA_1=null;
        EObject lv_l_0_0 = null;

        EObject lv_l_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1164:2: ( ( ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )* ) )
            // InternalMyDsl.g:1165:2: ( ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )* )
            {
            // InternalMyDsl.g:1165:2: ( ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )* )
            // InternalMyDsl.g:1166:3: ( (lv_l_0_0= rulePositiveLiteral ) ) (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )*
            {
            // InternalMyDsl.g:1166:3: ( (lv_l_0_0= rulePositiveLiteral ) )
            // InternalMyDsl.g:1167:4: (lv_l_0_0= rulePositiveLiteral )
            {
            // InternalMyDsl.g:1167:4: (lv_l_0_0= rulePositiveLiteral )
            // InternalMyDsl.g:1168:5: lv_l_0_0= rulePositiveLiteral
            {

            					newCompositeNode(grammarAccess.getListOfPositiveLiteralsAccess().getLPositiveLiteralParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_8);
            lv_l_0_0=rulePositiveLiteral();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getListOfPositiveLiteralsRule());
            					}
            					add(
            						current,
            						"l",
            						lv_l_0_0,
            						"org.xtext.example.mydsl.MyDsl.PositiveLiteral");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMyDsl.g:1185:3: (this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) ) )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==RULE_COMMA) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalMyDsl.g:1186:4: this_COMMA_1= RULE_COMMA ( (lv_l_2_0= rulePositiveLiteral ) )
            	    {
            	    this_COMMA_1=(Token)match(input,RULE_COMMA,FOLLOW_10); 

            	    				newLeafNode(this_COMMA_1, grammarAccess.getListOfPositiveLiteralsAccess().getCOMMATerminalRuleCall_1_0());
            	    			
            	    // InternalMyDsl.g:1190:4: ( (lv_l_2_0= rulePositiveLiteral ) )
            	    // InternalMyDsl.g:1191:5: (lv_l_2_0= rulePositiveLiteral )
            	    {
            	    // InternalMyDsl.g:1191:5: (lv_l_2_0= rulePositiveLiteral )
            	    // InternalMyDsl.g:1192:6: lv_l_2_0= rulePositiveLiteral
            	    {

            	    						newCompositeNode(grammarAccess.getListOfPositiveLiteralsAccess().getLPositiveLiteralParserRuleCall_1_1_0());
            	    					
            	    pushFollow(FOLLOW_8);
            	    lv_l_2_0=rulePositiveLiteral();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getListOfPositiveLiteralsRule());
            	    						}
            	    						add(
            	    							current,
            	    							"l",
            	    							lv_l_2_0,
            	    							"org.xtext.example.mydsl.MyDsl.PositiveLiteral");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulelistOfPositiveLiterals"


    // $ANTLR start "entryRuleRule"
    // InternalMyDsl.g:1214:1: entryRuleRule returns [EObject current=null] : iv_ruleRule= ruleRule EOF ;
    public final EObject entryRuleRule() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRule = null;


        try {
            // InternalMyDsl.g:1214:45: (iv_ruleRule= ruleRule EOF )
            // InternalMyDsl.g:1215:2: iv_ruleRule= ruleRule EOF
            {
             newCompositeNode(grammarAccess.getRuleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRule=ruleRule();

            state._fsp--;

             current =iv_ruleRule; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRule"


    // $ANTLR start "ruleRule"
    // InternalMyDsl.g:1221:1: ruleRule returns [EObject current=null] : ( ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT ) ;
    public final EObject ruleRule() throws RecognitionException {
        EObject current = null;

        Token this_ARROW_1=null;
        Token this_DOT_3=null;
        EObject lv_head_0_0 = null;

        EObject lv_body_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1227:2: ( ( ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT ) )
            // InternalMyDsl.g:1228:2: ( ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT )
            {
            // InternalMyDsl.g:1228:2: ( ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT )
            // InternalMyDsl.g:1229:3: ( (lv_head_0_0= rulelistOfPositiveLiterals ) ) this_ARROW_1= RULE_ARROW ( (lv_body_2_0= rulelistOfLiterals ) ) this_DOT_3= RULE_DOT
            {
            // InternalMyDsl.g:1229:3: ( (lv_head_0_0= rulelistOfPositiveLiterals ) )
            // InternalMyDsl.g:1230:4: (lv_head_0_0= rulelistOfPositiveLiterals )
            {
            // InternalMyDsl.g:1230:4: (lv_head_0_0= rulelistOfPositiveLiterals )
            // InternalMyDsl.g:1231:5: lv_head_0_0= rulelistOfPositiveLiterals
            {

            					newCompositeNode(grammarAccess.getRuleAccess().getHeadListOfPositiveLiteralsParserRuleCall_0_0());
            				
            pushFollow(FOLLOW_14);
            lv_head_0_0=rulelistOfPositiveLiterals();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRuleRule());
            					}
            					set(
            						current,
            						"head",
            						lv_head_0_0,
            						"org.xtext.example.mydsl.MyDsl.listOfPositiveLiterals");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_ARROW_1=(Token)match(input,RULE_ARROW,FOLLOW_13); 

            			newLeafNode(this_ARROW_1, grammarAccess.getRuleAccess().getARROWTerminalRuleCall_1());
            		
            // InternalMyDsl.g:1252:3: ( (lv_body_2_0= rulelistOfLiterals ) )
            // InternalMyDsl.g:1253:4: (lv_body_2_0= rulelistOfLiterals )
            {
            // InternalMyDsl.g:1253:4: (lv_body_2_0= rulelistOfLiterals )
            // InternalMyDsl.g:1254:5: lv_body_2_0= rulelistOfLiterals
            {

            					newCompositeNode(grammarAccess.getRuleAccess().getBodyListOfLiteralsParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_15);
            lv_body_2_0=rulelistOfLiterals();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRuleRule());
            					}
            					set(
            						current,
            						"body",
            						lv_body_2_0,
            						"org.xtext.example.mydsl.MyDsl.listOfLiterals");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            this_DOT_3=(Token)match(input,RULE_DOT,FOLLOW_2); 

            			newLeafNode(this_DOT_3, grammarAccess.getRuleAccess().getDOTTerminalRuleCall_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRule"


    // $ANTLR start "entryRuleStatement"
    // InternalMyDsl.g:1279:1: entryRuleStatement returns [EObject current=null] : iv_ruleStatement= ruleStatement EOF ;
    public final EObject entryRuleStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStatement = null;


        try {
            // InternalMyDsl.g:1279:50: (iv_ruleStatement= ruleStatement EOF )
            // InternalMyDsl.g:1280:2: iv_ruleStatement= ruleStatement EOF
            {
             newCompositeNode(grammarAccess.getStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStatement=ruleStatement();

            state._fsp--;

             current =iv_ruleStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStatement"


    // $ANTLR start "ruleStatement"
    // InternalMyDsl.g:1286:1: ruleStatement returns [EObject current=null] : ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) | ( ( (lv_statement_3_0= ruleRule ) ) this_E_4= RULE_E ) | ( ( (lv_statement_5_0= ruleFact ) ) this_DOT_6= RULE_DOT this_E_7= RULE_E ) ) ;
    public final EObject ruleStatement() throws RecognitionException {
        EObject current = null;

        Token this_DOT_2=null;
        Token this_E_4=null;
        Token this_DOT_6=null;
        Token this_E_7=null;
        EObject lv_statement_0_0 = null;

        EObject lv_statement_1_0 = null;

        EObject lv_statement_3_0 = null;

        EObject lv_statement_5_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1292:2: ( ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) | ( ( (lv_statement_3_0= ruleRule ) ) this_E_4= RULE_E ) | ( ( (lv_statement_5_0= ruleFact ) ) this_DOT_6= RULE_DOT this_E_7= RULE_E ) ) )
            // InternalMyDsl.g:1293:2: ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) | ( ( (lv_statement_3_0= ruleRule ) ) this_E_4= RULE_E ) | ( ( (lv_statement_5_0= ruleFact ) ) this_DOT_6= RULE_DOT this_E_7= RULE_E ) )
            {
            // InternalMyDsl.g:1293:2: ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) | ( ( (lv_statement_3_0= ruleRule ) ) this_E_4= RULE_E ) | ( ( (lv_statement_5_0= ruleFact ) ) this_DOT_6= RULE_DOT this_E_7= RULE_E ) )
            int alt15=4;
            alt15 = dfa15.predict(input);
            switch (alt15) {
                case 1 :
                    // InternalMyDsl.g:1294:3: ( (lv_statement_0_0= ruleRule ) )
                    {
                    // InternalMyDsl.g:1294:3: ( (lv_statement_0_0= ruleRule ) )
                    // InternalMyDsl.g:1295:4: (lv_statement_0_0= ruleRule )
                    {
                    // InternalMyDsl.g:1295:4: (lv_statement_0_0= ruleRule )
                    // InternalMyDsl.g:1296:5: lv_statement_0_0= ruleRule
                    {

                    					newCompositeNode(grammarAccess.getStatementAccess().getStatementRuleParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_statement_0_0=ruleRule();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getStatementRule());
                    					}
                    					set(
                    						current,
                    						"statement",
                    						lv_statement_0_0,
                    						"org.xtext.example.mydsl.MyDsl.Rule");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1314:3: ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT )
                    {
                    // InternalMyDsl.g:1314:3: ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT )
                    // InternalMyDsl.g:1315:4: ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT
                    {
                    // InternalMyDsl.g:1315:4: ( (lv_statement_1_0= ruleFact ) )
                    // InternalMyDsl.g:1316:5: (lv_statement_1_0= ruleFact )
                    {
                    // InternalMyDsl.g:1316:5: (lv_statement_1_0= ruleFact )
                    // InternalMyDsl.g:1317:6: lv_statement_1_0= ruleFact
                    {

                    						newCompositeNode(grammarAccess.getStatementAccess().getStatementFactParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_statement_1_0=ruleFact();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStatementRule());
                    						}
                    						set(
                    							current,
                    							"statement",
                    							lv_statement_1_0,
                    							"org.xtext.example.mydsl.MyDsl.Fact");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_2=(Token)match(input,RULE_DOT,FOLLOW_2); 

                    				newLeafNode(this_DOT_2, grammarAccess.getStatementAccess().getDOTTerminalRuleCall_1_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1340:3: ( ( (lv_statement_3_0= ruleRule ) ) this_E_4= RULE_E )
                    {
                    // InternalMyDsl.g:1340:3: ( ( (lv_statement_3_0= ruleRule ) ) this_E_4= RULE_E )
                    // InternalMyDsl.g:1341:4: ( (lv_statement_3_0= ruleRule ) ) this_E_4= RULE_E
                    {
                    // InternalMyDsl.g:1341:4: ( (lv_statement_3_0= ruleRule ) )
                    // InternalMyDsl.g:1342:5: (lv_statement_3_0= ruleRule )
                    {
                    // InternalMyDsl.g:1342:5: (lv_statement_3_0= ruleRule )
                    // InternalMyDsl.g:1343:6: lv_statement_3_0= ruleRule
                    {

                    						newCompositeNode(grammarAccess.getStatementAccess().getStatementRuleParserRuleCall_2_0_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_statement_3_0=ruleRule();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStatementRule());
                    						}
                    						set(
                    							current,
                    							"statement",
                    							lv_statement_3_0,
                    							"org.xtext.example.mydsl.MyDsl.Rule");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_E_4=(Token)match(input,RULE_E,FOLLOW_2); 

                    				newLeafNode(this_E_4, grammarAccess.getStatementAccess().getETerminalRuleCall_2_1());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:1366:3: ( ( (lv_statement_5_0= ruleFact ) ) this_DOT_6= RULE_DOT this_E_7= RULE_E )
                    {
                    // InternalMyDsl.g:1366:3: ( ( (lv_statement_5_0= ruleFact ) ) this_DOT_6= RULE_DOT this_E_7= RULE_E )
                    // InternalMyDsl.g:1367:4: ( (lv_statement_5_0= ruleFact ) ) this_DOT_6= RULE_DOT this_E_7= RULE_E
                    {
                    // InternalMyDsl.g:1367:4: ( (lv_statement_5_0= ruleFact ) )
                    // InternalMyDsl.g:1368:5: (lv_statement_5_0= ruleFact )
                    {
                    // InternalMyDsl.g:1368:5: (lv_statement_5_0= ruleFact )
                    // InternalMyDsl.g:1369:6: lv_statement_5_0= ruleFact
                    {

                    						newCompositeNode(grammarAccess.getStatementAccess().getStatementFactParserRuleCall_3_0_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_statement_5_0=ruleFact();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStatementRule());
                    						}
                    						set(
                    							current,
                    							"statement",
                    							lv_statement_5_0,
                    							"org.xtext.example.mydsl.MyDsl.Fact");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_6=(Token)match(input,RULE_DOT,FOLLOW_16); 

                    				newLeafNode(this_DOT_6, grammarAccess.getStatementAccess().getDOTTerminalRuleCall_3_1());
                    			
                    this_E_7=(Token)match(input,RULE_E,FOLLOW_2); 

                    				newLeafNode(this_E_7, grammarAccess.getStatementAccess().getETerminalRuleCall_3_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStatement"


    // $ANTLR start "entryRuleDataSource"
    // InternalMyDsl.g:1399:1: entryRuleDataSource returns [EObject current=null] : iv_ruleDataSource= ruleDataSource EOF ;
    public final EObject entryRuleDataSource() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataSource = null;


        try {
            // InternalMyDsl.g:1399:51: (iv_ruleDataSource= ruleDataSource EOF )
            // InternalMyDsl.g:1400:2: iv_ruleDataSource= ruleDataSource EOF
            {
             newCompositeNode(grammarAccess.getDataSourceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataSource=ruleDataSource();

            state._fsp--;

             current =iv_ruleDataSource; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataSource"


    // $ANTLR start "ruleDataSource"
    // InternalMyDsl.g:1406:1: ruleDataSource returns [EObject current=null] : ( (this_LOADCSV_0= RULE_LOADCSV this_LPAREN_1= RULE_LPAREN ( (lv_fileName_2_0= ruleStriing ) ) this_RPAREN_3= RULE_RPAREN ) | (this_LOADRDF_4= RULE_LOADRDF this_LPAREN_5= RULE_LPAREN ( (lv_fileName_6_0= ruleStriing ) ) this_RPAREN_7= RULE_RPAREN ) | (this_SPARQL_8= RULE_SPARQL this_LPAREN_9= RULE_LPAREN ( (lv_endpoint_10_0= ruleIRIBOL ) ) this_COMMA_11= RULE_COMMA ( (lv_variables_12_0= ruleStriing ) ) this_COMMA_13= RULE_COMMA ( (lv_query_14_0= ruleStriing ) ) this_RPAREN_15= RULE_RPAREN ) ) ;
    public final EObject ruleDataSource() throws RecognitionException {
        EObject current = null;

        Token this_LOADCSV_0=null;
        Token this_LPAREN_1=null;
        Token this_RPAREN_3=null;
        Token this_LOADRDF_4=null;
        Token this_LPAREN_5=null;
        Token this_RPAREN_7=null;
        Token this_SPARQL_8=null;
        Token this_LPAREN_9=null;
        Token this_COMMA_11=null;
        Token this_COMMA_13=null;
        Token this_RPAREN_15=null;
        EObject lv_fileName_2_0 = null;

        EObject lv_fileName_6_0 = null;

        EObject lv_endpoint_10_0 = null;

        EObject lv_variables_12_0 = null;

        EObject lv_query_14_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1412:2: ( ( (this_LOADCSV_0= RULE_LOADCSV this_LPAREN_1= RULE_LPAREN ( (lv_fileName_2_0= ruleStriing ) ) this_RPAREN_3= RULE_RPAREN ) | (this_LOADRDF_4= RULE_LOADRDF this_LPAREN_5= RULE_LPAREN ( (lv_fileName_6_0= ruleStriing ) ) this_RPAREN_7= RULE_RPAREN ) | (this_SPARQL_8= RULE_SPARQL this_LPAREN_9= RULE_LPAREN ( (lv_endpoint_10_0= ruleIRIBOL ) ) this_COMMA_11= RULE_COMMA ( (lv_variables_12_0= ruleStriing ) ) this_COMMA_13= RULE_COMMA ( (lv_query_14_0= ruleStriing ) ) this_RPAREN_15= RULE_RPAREN ) ) )
            // InternalMyDsl.g:1413:2: ( (this_LOADCSV_0= RULE_LOADCSV this_LPAREN_1= RULE_LPAREN ( (lv_fileName_2_0= ruleStriing ) ) this_RPAREN_3= RULE_RPAREN ) | (this_LOADRDF_4= RULE_LOADRDF this_LPAREN_5= RULE_LPAREN ( (lv_fileName_6_0= ruleStriing ) ) this_RPAREN_7= RULE_RPAREN ) | (this_SPARQL_8= RULE_SPARQL this_LPAREN_9= RULE_LPAREN ( (lv_endpoint_10_0= ruleIRIBOL ) ) this_COMMA_11= RULE_COMMA ( (lv_variables_12_0= ruleStriing ) ) this_COMMA_13= RULE_COMMA ( (lv_query_14_0= ruleStriing ) ) this_RPAREN_15= RULE_RPAREN ) )
            {
            // InternalMyDsl.g:1413:2: ( (this_LOADCSV_0= RULE_LOADCSV this_LPAREN_1= RULE_LPAREN ( (lv_fileName_2_0= ruleStriing ) ) this_RPAREN_3= RULE_RPAREN ) | (this_LOADRDF_4= RULE_LOADRDF this_LPAREN_5= RULE_LPAREN ( (lv_fileName_6_0= ruleStriing ) ) this_RPAREN_7= RULE_RPAREN ) | (this_SPARQL_8= RULE_SPARQL this_LPAREN_9= RULE_LPAREN ( (lv_endpoint_10_0= ruleIRIBOL ) ) this_COMMA_11= RULE_COMMA ( (lv_variables_12_0= ruleStriing ) ) this_COMMA_13= RULE_COMMA ( (lv_query_14_0= ruleStriing ) ) this_RPAREN_15= RULE_RPAREN ) )
            int alt16=3;
            switch ( input.LA(1) ) {
            case RULE_LOADCSV:
                {
                alt16=1;
                }
                break;
            case RULE_LOADRDF:
                {
                alt16=2;
                }
                break;
            case RULE_SPARQL:
                {
                alt16=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }

            switch (alt16) {
                case 1 :
                    // InternalMyDsl.g:1414:3: (this_LOADCSV_0= RULE_LOADCSV this_LPAREN_1= RULE_LPAREN ( (lv_fileName_2_0= ruleStriing ) ) this_RPAREN_3= RULE_RPAREN )
                    {
                    // InternalMyDsl.g:1414:3: (this_LOADCSV_0= RULE_LOADCSV this_LPAREN_1= RULE_LPAREN ( (lv_fileName_2_0= ruleStriing ) ) this_RPAREN_3= RULE_RPAREN )
                    // InternalMyDsl.g:1415:4: this_LOADCSV_0= RULE_LOADCSV this_LPAREN_1= RULE_LPAREN ( (lv_fileName_2_0= ruleStriing ) ) this_RPAREN_3= RULE_RPAREN
                    {
                    this_LOADCSV_0=(Token)match(input,RULE_LOADCSV,FOLLOW_11); 

                    				newLeafNode(this_LOADCSV_0, grammarAccess.getDataSourceAccess().getLOADCSVTerminalRuleCall_0_0());
                    			
                    this_LPAREN_1=(Token)match(input,RULE_LPAREN,FOLLOW_17); 

                    				newLeafNode(this_LPAREN_1, grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_0_1());
                    			
                    // InternalMyDsl.g:1423:4: ( (lv_fileName_2_0= ruleStriing ) )
                    // InternalMyDsl.g:1424:5: (lv_fileName_2_0= ruleStriing )
                    {
                    // InternalMyDsl.g:1424:5: (lv_fileName_2_0= ruleStriing )
                    // InternalMyDsl.g:1425:6: lv_fileName_2_0= ruleStriing
                    {

                    						newCompositeNode(grammarAccess.getDataSourceAccess().getFileNameStriingParserRuleCall_0_2_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_fileName_2_0=ruleStriing();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDataSourceRule());
                    						}
                    						set(
                    							current,
                    							"fileName",
                    							lv_fileName_2_0,
                    							"org.xtext.example.mydsl.MyDsl.Striing");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_RPAREN_3=(Token)match(input,RULE_RPAREN,FOLLOW_2); 

                    				newLeafNode(this_RPAREN_3, grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_0_3());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1448:3: (this_LOADRDF_4= RULE_LOADRDF this_LPAREN_5= RULE_LPAREN ( (lv_fileName_6_0= ruleStriing ) ) this_RPAREN_7= RULE_RPAREN )
                    {
                    // InternalMyDsl.g:1448:3: (this_LOADRDF_4= RULE_LOADRDF this_LPAREN_5= RULE_LPAREN ( (lv_fileName_6_0= ruleStriing ) ) this_RPAREN_7= RULE_RPAREN )
                    // InternalMyDsl.g:1449:4: this_LOADRDF_4= RULE_LOADRDF this_LPAREN_5= RULE_LPAREN ( (lv_fileName_6_0= ruleStriing ) ) this_RPAREN_7= RULE_RPAREN
                    {
                    this_LOADRDF_4=(Token)match(input,RULE_LOADRDF,FOLLOW_11); 

                    				newLeafNode(this_LOADRDF_4, grammarAccess.getDataSourceAccess().getLOADRDFTerminalRuleCall_1_0());
                    			
                    this_LPAREN_5=(Token)match(input,RULE_LPAREN,FOLLOW_17); 

                    				newLeafNode(this_LPAREN_5, grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_1_1());
                    			
                    // InternalMyDsl.g:1457:4: ( (lv_fileName_6_0= ruleStriing ) )
                    // InternalMyDsl.g:1458:5: (lv_fileName_6_0= ruleStriing )
                    {
                    // InternalMyDsl.g:1458:5: (lv_fileName_6_0= ruleStriing )
                    // InternalMyDsl.g:1459:6: lv_fileName_6_0= ruleStriing
                    {

                    						newCompositeNode(grammarAccess.getDataSourceAccess().getFileNameStriingParserRuleCall_1_2_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_fileName_6_0=ruleStriing();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDataSourceRule());
                    						}
                    						set(
                    							current,
                    							"fileName",
                    							lv_fileName_6_0,
                    							"org.xtext.example.mydsl.MyDsl.Striing");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_RPAREN_7=(Token)match(input,RULE_RPAREN,FOLLOW_2); 

                    				newLeafNode(this_RPAREN_7, grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_1_3());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1482:3: (this_SPARQL_8= RULE_SPARQL this_LPAREN_9= RULE_LPAREN ( (lv_endpoint_10_0= ruleIRIBOL ) ) this_COMMA_11= RULE_COMMA ( (lv_variables_12_0= ruleStriing ) ) this_COMMA_13= RULE_COMMA ( (lv_query_14_0= ruleStriing ) ) this_RPAREN_15= RULE_RPAREN )
                    {
                    // InternalMyDsl.g:1482:3: (this_SPARQL_8= RULE_SPARQL this_LPAREN_9= RULE_LPAREN ( (lv_endpoint_10_0= ruleIRIBOL ) ) this_COMMA_11= RULE_COMMA ( (lv_variables_12_0= ruleStriing ) ) this_COMMA_13= RULE_COMMA ( (lv_query_14_0= ruleStriing ) ) this_RPAREN_15= RULE_RPAREN )
                    // InternalMyDsl.g:1483:4: this_SPARQL_8= RULE_SPARQL this_LPAREN_9= RULE_LPAREN ( (lv_endpoint_10_0= ruleIRIBOL ) ) this_COMMA_11= RULE_COMMA ( (lv_variables_12_0= ruleStriing ) ) this_COMMA_13= RULE_COMMA ( (lv_query_14_0= ruleStriing ) ) this_RPAREN_15= RULE_RPAREN
                    {
                    this_SPARQL_8=(Token)match(input,RULE_SPARQL,FOLLOW_11); 

                    				newLeafNode(this_SPARQL_8, grammarAccess.getDataSourceAccess().getSPARQLTerminalRuleCall_2_0());
                    			
                    this_LPAREN_9=(Token)match(input,RULE_LPAREN,FOLLOW_7); 

                    				newLeafNode(this_LPAREN_9, grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_2_1());
                    			
                    // InternalMyDsl.g:1491:4: ( (lv_endpoint_10_0= ruleIRIBOL ) )
                    // InternalMyDsl.g:1492:5: (lv_endpoint_10_0= ruleIRIBOL )
                    {
                    // InternalMyDsl.g:1492:5: (lv_endpoint_10_0= ruleIRIBOL )
                    // InternalMyDsl.g:1493:6: lv_endpoint_10_0= ruleIRIBOL
                    {

                    						newCompositeNode(grammarAccess.getDataSourceAccess().getEndpointIRIBOLParserRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_endpoint_10_0=ruleIRIBOL();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDataSourceRule());
                    						}
                    						set(
                    							current,
                    							"endpoint",
                    							lv_endpoint_10_0,
                    							"org.xtext.example.mydsl.MyDsl.IRIBOL");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_COMMA_11=(Token)match(input,RULE_COMMA,FOLLOW_17); 

                    				newLeafNode(this_COMMA_11, grammarAccess.getDataSourceAccess().getCOMMATerminalRuleCall_2_3());
                    			
                    // InternalMyDsl.g:1514:4: ( (lv_variables_12_0= ruleStriing ) )
                    // InternalMyDsl.g:1515:5: (lv_variables_12_0= ruleStriing )
                    {
                    // InternalMyDsl.g:1515:5: (lv_variables_12_0= ruleStriing )
                    // InternalMyDsl.g:1516:6: lv_variables_12_0= ruleStriing
                    {

                    						newCompositeNode(grammarAccess.getDataSourceAccess().getVariablesStriingParserRuleCall_2_4_0());
                    					
                    pushFollow(FOLLOW_18);
                    lv_variables_12_0=ruleStriing();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDataSourceRule());
                    						}
                    						set(
                    							current,
                    							"variables",
                    							lv_variables_12_0,
                    							"org.xtext.example.mydsl.MyDsl.Striing");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_COMMA_13=(Token)match(input,RULE_COMMA,FOLLOW_17); 

                    				newLeafNode(this_COMMA_13, grammarAccess.getDataSourceAccess().getCOMMATerminalRuleCall_2_5());
                    			
                    // InternalMyDsl.g:1537:4: ( (lv_query_14_0= ruleStriing ) )
                    // InternalMyDsl.g:1538:5: (lv_query_14_0= ruleStriing )
                    {
                    // InternalMyDsl.g:1538:5: (lv_query_14_0= ruleStriing )
                    // InternalMyDsl.g:1539:6: lv_query_14_0= ruleStriing
                    {

                    						newCompositeNode(grammarAccess.getDataSourceAccess().getQueryStriingParserRuleCall_2_6_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_query_14_0=ruleStriing();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDataSourceRule());
                    						}
                    						set(
                    							current,
                    							"query",
                    							lv_query_14_0,
                    							"org.xtext.example.mydsl.MyDsl.Striing");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_RPAREN_15=(Token)match(input,RULE_RPAREN,FOLLOW_2); 

                    				newLeafNode(this_RPAREN_15, grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_2_7());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataSource"


    // $ANTLR start "entryRuleSource"
    // InternalMyDsl.g:1565:1: entryRuleSource returns [EObject current=null] : iv_ruleSource= ruleSource EOF ;
    public final EObject entryRuleSource() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSource = null;


        try {
            // InternalMyDsl.g:1565:47: (iv_ruleSource= ruleSource EOF )
            // InternalMyDsl.g:1566:2: iv_ruleSource= ruleSource EOF
            {
             newCompositeNode(grammarAccess.getSourceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSource=ruleSource();

            state._fsp--;

             current =iv_ruleSource; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSource"


    // $ANTLR start "ruleSource"
    // InternalMyDsl.g:1572:1: ruleSource returns [EObject current=null] : ( (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arity_3_0= RULE_INTEGER ) ) this_RPAREN_4= RULE_RPAREN this_COLON_5= RULE_COLON ( (lv_dataSource_6_0= ruleDataSource ) ) this_DOT_7= RULE_DOT ) | (this_SRC_8= RULE_SRC ( (lv_predicatename_9_0= rulepredicateName ) ) this_LPAREN_10= RULE_LPAREN ( (lv_arity_11_0= RULE_INTEGER ) ) this_RPAREN_12= RULE_RPAREN this_COLON_13= RULE_COLON ( (lv_dataSource_14_0= ruleDataSource ) ) this_DOT_15= RULE_DOT this_E_16= RULE_E ) ) ;
    public final EObject ruleSource() throws RecognitionException {
        EObject current = null;

        Token this_SRC_0=null;
        Token this_LPAREN_2=null;
        Token lv_arity_3_0=null;
        Token this_RPAREN_4=null;
        Token this_COLON_5=null;
        Token this_DOT_7=null;
        Token this_SRC_8=null;
        Token this_LPAREN_10=null;
        Token lv_arity_11_0=null;
        Token this_RPAREN_12=null;
        Token this_COLON_13=null;
        Token this_DOT_15=null;
        Token this_E_16=null;
        EObject lv_predicatename_1_0 = null;

        EObject lv_dataSource_6_0 = null;

        EObject lv_predicatename_9_0 = null;

        EObject lv_dataSource_14_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1578:2: ( ( (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arity_3_0= RULE_INTEGER ) ) this_RPAREN_4= RULE_RPAREN this_COLON_5= RULE_COLON ( (lv_dataSource_6_0= ruleDataSource ) ) this_DOT_7= RULE_DOT ) | (this_SRC_8= RULE_SRC ( (lv_predicatename_9_0= rulepredicateName ) ) this_LPAREN_10= RULE_LPAREN ( (lv_arity_11_0= RULE_INTEGER ) ) this_RPAREN_12= RULE_RPAREN this_COLON_13= RULE_COLON ( (lv_dataSource_14_0= ruleDataSource ) ) this_DOT_15= RULE_DOT this_E_16= RULE_E ) ) )
            // InternalMyDsl.g:1579:2: ( (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arity_3_0= RULE_INTEGER ) ) this_RPAREN_4= RULE_RPAREN this_COLON_5= RULE_COLON ( (lv_dataSource_6_0= ruleDataSource ) ) this_DOT_7= RULE_DOT ) | (this_SRC_8= RULE_SRC ( (lv_predicatename_9_0= rulepredicateName ) ) this_LPAREN_10= RULE_LPAREN ( (lv_arity_11_0= RULE_INTEGER ) ) this_RPAREN_12= RULE_RPAREN this_COLON_13= RULE_COLON ( (lv_dataSource_14_0= ruleDataSource ) ) this_DOT_15= RULE_DOT this_E_16= RULE_E ) )
            {
            // InternalMyDsl.g:1579:2: ( (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arity_3_0= RULE_INTEGER ) ) this_RPAREN_4= RULE_RPAREN this_COLON_5= RULE_COLON ( (lv_dataSource_6_0= ruleDataSource ) ) this_DOT_7= RULE_DOT ) | (this_SRC_8= RULE_SRC ( (lv_predicatename_9_0= rulepredicateName ) ) this_LPAREN_10= RULE_LPAREN ( (lv_arity_11_0= RULE_INTEGER ) ) this_RPAREN_12= RULE_RPAREN this_COLON_13= RULE_COLON ( (lv_dataSource_14_0= ruleDataSource ) ) this_DOT_15= RULE_DOT this_E_16= RULE_E ) )
            int alt17=2;
            alt17 = dfa17.predict(input);
            switch (alt17) {
                case 1 :
                    // InternalMyDsl.g:1580:3: (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arity_3_0= RULE_INTEGER ) ) this_RPAREN_4= RULE_RPAREN this_COLON_5= RULE_COLON ( (lv_dataSource_6_0= ruleDataSource ) ) this_DOT_7= RULE_DOT )
                    {
                    // InternalMyDsl.g:1580:3: (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arity_3_0= RULE_INTEGER ) ) this_RPAREN_4= RULE_RPAREN this_COLON_5= RULE_COLON ( (lv_dataSource_6_0= ruleDataSource ) ) this_DOT_7= RULE_DOT )
                    // InternalMyDsl.g:1581:4: this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arity_3_0= RULE_INTEGER ) ) this_RPAREN_4= RULE_RPAREN this_COLON_5= RULE_COLON ( (lv_dataSource_6_0= ruleDataSource ) ) this_DOT_7= RULE_DOT
                    {
                    this_SRC_0=(Token)match(input,RULE_SRC,FOLLOW_10); 

                    				newLeafNode(this_SRC_0, grammarAccess.getSourceAccess().getSRCTerminalRuleCall_0_0());
                    			
                    // InternalMyDsl.g:1585:4: ( (lv_predicatename_1_0= rulepredicateName ) )
                    // InternalMyDsl.g:1586:5: (lv_predicatename_1_0= rulepredicateName )
                    {
                    // InternalMyDsl.g:1586:5: (lv_predicatename_1_0= rulepredicateName )
                    // InternalMyDsl.g:1587:6: lv_predicatename_1_0= rulepredicateName
                    {

                    						newCompositeNode(grammarAccess.getSourceAccess().getPredicatenamePredicateNameParserRuleCall_0_1_0());
                    					
                    pushFollow(FOLLOW_11);
                    lv_predicatename_1_0=rulepredicateName();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSourceRule());
                    						}
                    						set(
                    							current,
                    							"predicatename",
                    							lv_predicatename_1_0,
                    							"org.xtext.example.mydsl.MyDsl.predicateName");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_LPAREN_2=(Token)match(input,RULE_LPAREN,FOLLOW_19); 

                    				newLeafNode(this_LPAREN_2, grammarAccess.getSourceAccess().getLPARENTerminalRuleCall_0_2());
                    			
                    // InternalMyDsl.g:1608:4: ( (lv_arity_3_0= RULE_INTEGER ) )
                    // InternalMyDsl.g:1609:5: (lv_arity_3_0= RULE_INTEGER )
                    {
                    // InternalMyDsl.g:1609:5: (lv_arity_3_0= RULE_INTEGER )
                    // InternalMyDsl.g:1610:6: lv_arity_3_0= RULE_INTEGER
                    {
                    lv_arity_3_0=(Token)match(input,RULE_INTEGER,FOLLOW_12); 

                    						newLeafNode(lv_arity_3_0, grammarAccess.getSourceAccess().getArityINTEGERTerminalRuleCall_0_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSourceRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"arity",
                    							lv_arity_3_0,
                    							"org.xtext.example.mydsl.MyDsl.INTEGER");
                    					

                    }


                    }

                    this_RPAREN_4=(Token)match(input,RULE_RPAREN,FOLLOW_20); 

                    				newLeafNode(this_RPAREN_4, grammarAccess.getSourceAccess().getRPARENTerminalRuleCall_0_4());
                    			
                    this_COLON_5=(Token)match(input,RULE_COLON,FOLLOW_21); 

                    				newLeafNode(this_COLON_5, grammarAccess.getSourceAccess().getCOLONTerminalRuleCall_0_5());
                    			
                    // InternalMyDsl.g:1634:4: ( (lv_dataSource_6_0= ruleDataSource ) )
                    // InternalMyDsl.g:1635:5: (lv_dataSource_6_0= ruleDataSource )
                    {
                    // InternalMyDsl.g:1635:5: (lv_dataSource_6_0= ruleDataSource )
                    // InternalMyDsl.g:1636:6: lv_dataSource_6_0= ruleDataSource
                    {

                    						newCompositeNode(grammarAccess.getSourceAccess().getDataSourceDataSourceParserRuleCall_0_6_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_dataSource_6_0=ruleDataSource();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSourceRule());
                    						}
                    						set(
                    							current,
                    							"dataSource",
                    							lv_dataSource_6_0,
                    							"org.xtext.example.mydsl.MyDsl.DataSource");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_7=(Token)match(input,RULE_DOT,FOLLOW_2); 

                    				newLeafNode(this_DOT_7, grammarAccess.getSourceAccess().getDOTTerminalRuleCall_0_7());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1659:3: (this_SRC_8= RULE_SRC ( (lv_predicatename_9_0= rulepredicateName ) ) this_LPAREN_10= RULE_LPAREN ( (lv_arity_11_0= RULE_INTEGER ) ) this_RPAREN_12= RULE_RPAREN this_COLON_13= RULE_COLON ( (lv_dataSource_14_0= ruleDataSource ) ) this_DOT_15= RULE_DOT this_E_16= RULE_E )
                    {
                    // InternalMyDsl.g:1659:3: (this_SRC_8= RULE_SRC ( (lv_predicatename_9_0= rulepredicateName ) ) this_LPAREN_10= RULE_LPAREN ( (lv_arity_11_0= RULE_INTEGER ) ) this_RPAREN_12= RULE_RPAREN this_COLON_13= RULE_COLON ( (lv_dataSource_14_0= ruleDataSource ) ) this_DOT_15= RULE_DOT this_E_16= RULE_E )
                    // InternalMyDsl.g:1660:4: this_SRC_8= RULE_SRC ( (lv_predicatename_9_0= rulepredicateName ) ) this_LPAREN_10= RULE_LPAREN ( (lv_arity_11_0= RULE_INTEGER ) ) this_RPAREN_12= RULE_RPAREN this_COLON_13= RULE_COLON ( (lv_dataSource_14_0= ruleDataSource ) ) this_DOT_15= RULE_DOT this_E_16= RULE_E
                    {
                    this_SRC_8=(Token)match(input,RULE_SRC,FOLLOW_10); 

                    				newLeafNode(this_SRC_8, grammarAccess.getSourceAccess().getSRCTerminalRuleCall_1_0());
                    			
                    // InternalMyDsl.g:1664:4: ( (lv_predicatename_9_0= rulepredicateName ) )
                    // InternalMyDsl.g:1665:5: (lv_predicatename_9_0= rulepredicateName )
                    {
                    // InternalMyDsl.g:1665:5: (lv_predicatename_9_0= rulepredicateName )
                    // InternalMyDsl.g:1666:6: lv_predicatename_9_0= rulepredicateName
                    {

                    						newCompositeNode(grammarAccess.getSourceAccess().getPredicatenamePredicateNameParserRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_11);
                    lv_predicatename_9_0=rulepredicateName();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSourceRule());
                    						}
                    						set(
                    							current,
                    							"predicatename",
                    							lv_predicatename_9_0,
                    							"org.xtext.example.mydsl.MyDsl.predicateName");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_LPAREN_10=(Token)match(input,RULE_LPAREN,FOLLOW_19); 

                    				newLeafNode(this_LPAREN_10, grammarAccess.getSourceAccess().getLPARENTerminalRuleCall_1_2());
                    			
                    // InternalMyDsl.g:1687:4: ( (lv_arity_11_0= RULE_INTEGER ) )
                    // InternalMyDsl.g:1688:5: (lv_arity_11_0= RULE_INTEGER )
                    {
                    // InternalMyDsl.g:1688:5: (lv_arity_11_0= RULE_INTEGER )
                    // InternalMyDsl.g:1689:6: lv_arity_11_0= RULE_INTEGER
                    {
                    lv_arity_11_0=(Token)match(input,RULE_INTEGER,FOLLOW_12); 

                    						newLeafNode(lv_arity_11_0, grammarAccess.getSourceAccess().getArityINTEGERTerminalRuleCall_1_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSourceRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"arity",
                    							lv_arity_11_0,
                    							"org.xtext.example.mydsl.MyDsl.INTEGER");
                    					

                    }


                    }

                    this_RPAREN_12=(Token)match(input,RULE_RPAREN,FOLLOW_20); 

                    				newLeafNode(this_RPAREN_12, grammarAccess.getSourceAccess().getRPARENTerminalRuleCall_1_4());
                    			
                    this_COLON_13=(Token)match(input,RULE_COLON,FOLLOW_21); 

                    				newLeafNode(this_COLON_13, grammarAccess.getSourceAccess().getCOLONTerminalRuleCall_1_5());
                    			
                    // InternalMyDsl.g:1713:4: ( (lv_dataSource_14_0= ruleDataSource ) )
                    // InternalMyDsl.g:1714:5: (lv_dataSource_14_0= ruleDataSource )
                    {
                    // InternalMyDsl.g:1714:5: (lv_dataSource_14_0= ruleDataSource )
                    // InternalMyDsl.g:1715:6: lv_dataSource_14_0= ruleDataSource
                    {

                    						newCompositeNode(grammarAccess.getSourceAccess().getDataSourceDataSourceParserRuleCall_1_6_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_dataSource_14_0=ruleDataSource();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSourceRule());
                    						}
                    						set(
                    							current,
                    							"dataSource",
                    							lv_dataSource_14_0,
                    							"org.xtext.example.mydsl.MyDsl.DataSource");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_15=(Token)match(input,RULE_DOT,FOLLOW_16); 

                    				newLeafNode(this_DOT_15, grammarAccess.getSourceAccess().getDOTTerminalRuleCall_1_7());
                    			
                    this_E_16=(Token)match(input,RULE_E,FOLLOW_2); 

                    				newLeafNode(this_E_16, grammarAccess.getSourceAccess().getETerminalRuleCall_1_8());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSource"


    // $ANTLR start "entryRulePrefix"
    // InternalMyDsl.g:1745:1: entryRulePrefix returns [EObject current=null] : iv_rulePrefix= rulePrefix EOF ;
    public final EObject entryRulePrefix() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrefix = null;


        try {
            // InternalMyDsl.g:1745:47: (iv_rulePrefix= rulePrefix EOF )
            // InternalMyDsl.g:1746:2: iv_rulePrefix= rulePrefix EOF
            {
             newCompositeNode(grammarAccess.getPrefixRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrefix=rulePrefix();

            state._fsp--;

             current =iv_rulePrefix; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrefix"


    // $ANTLR start "rulePrefix"
    // InternalMyDsl.g:1752:1: rulePrefix returns [EObject current=null] : ( (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT ) | (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT ) | (this_PRFX_8= RULE_PRFX ( (lv_t_9_0= RULE_COLON ) ) ( (lv_iriString_10_0= ruleIRIREF ) ) this_DOT_11= RULE_DOT this_E_12= RULE_E ) | (this_PRFX_13= RULE_PRFX ( (lv_t_14_0= RULE_PNAME_NS ) ) ( (lv_iriString_15_0= ruleIRIREF ) ) this_DOT_16= RULE_DOT this_E_17= RULE_E ) ) ;
    public final EObject rulePrefix() throws RecognitionException {
        EObject current = null;

        Token this_PRFX_0=null;
        Token lv_t_1_0=null;
        Token this_DOT_3=null;
        Token this_PRFX_4=null;
        Token lv_t_5_0=null;
        Token this_DOT_7=null;
        Token this_PRFX_8=null;
        Token lv_t_9_0=null;
        Token this_DOT_11=null;
        Token this_E_12=null;
        Token this_PRFX_13=null;
        Token lv_t_14_0=null;
        Token this_DOT_16=null;
        Token this_E_17=null;
        EObject lv_iriString_2_0 = null;

        EObject lv_iriString_6_0 = null;

        EObject lv_iriString_10_0 = null;

        EObject lv_iriString_15_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1758:2: ( ( (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT ) | (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT ) | (this_PRFX_8= RULE_PRFX ( (lv_t_9_0= RULE_COLON ) ) ( (lv_iriString_10_0= ruleIRIREF ) ) this_DOT_11= RULE_DOT this_E_12= RULE_E ) | (this_PRFX_13= RULE_PRFX ( (lv_t_14_0= RULE_PNAME_NS ) ) ( (lv_iriString_15_0= ruleIRIREF ) ) this_DOT_16= RULE_DOT this_E_17= RULE_E ) ) )
            // InternalMyDsl.g:1759:2: ( (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT ) | (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT ) | (this_PRFX_8= RULE_PRFX ( (lv_t_9_0= RULE_COLON ) ) ( (lv_iriString_10_0= ruleIRIREF ) ) this_DOT_11= RULE_DOT this_E_12= RULE_E ) | (this_PRFX_13= RULE_PRFX ( (lv_t_14_0= RULE_PNAME_NS ) ) ( (lv_iriString_15_0= ruleIRIREF ) ) this_DOT_16= RULE_DOT this_E_17= RULE_E ) )
            {
            // InternalMyDsl.g:1759:2: ( (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT ) | (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT ) | (this_PRFX_8= RULE_PRFX ( (lv_t_9_0= RULE_COLON ) ) ( (lv_iriString_10_0= ruleIRIREF ) ) this_DOT_11= RULE_DOT this_E_12= RULE_E ) | (this_PRFX_13= RULE_PRFX ( (lv_t_14_0= RULE_PNAME_NS ) ) ( (lv_iriString_15_0= ruleIRIREF ) ) this_DOT_16= RULE_DOT this_E_17= RULE_E ) )
            int alt18=4;
            alt18 = dfa18.predict(input);
            switch (alt18) {
                case 1 :
                    // InternalMyDsl.g:1760:3: (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT )
                    {
                    // InternalMyDsl.g:1760:3: (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT )
                    // InternalMyDsl.g:1761:4: this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT
                    {
                    this_PRFX_0=(Token)match(input,RULE_PRFX,FOLLOW_20); 

                    				newLeafNode(this_PRFX_0, grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_0_0());
                    			
                    // InternalMyDsl.g:1765:4: ( (lv_t_1_0= RULE_COLON ) )
                    // InternalMyDsl.g:1766:5: (lv_t_1_0= RULE_COLON )
                    {
                    // InternalMyDsl.g:1766:5: (lv_t_1_0= RULE_COLON )
                    // InternalMyDsl.g:1767:6: lv_t_1_0= RULE_COLON
                    {
                    lv_t_1_0=(Token)match(input,RULE_COLON,FOLLOW_22); 

                    						newLeafNode(lv_t_1_0, grammarAccess.getPrefixAccess().getTCOLONTerminalRuleCall_0_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPrefixRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"t",
                    							lv_t_1_0,
                    							"org.xtext.example.mydsl.MyDsl.COLON");
                    					

                    }


                    }

                    // InternalMyDsl.g:1783:4: ( (lv_iriString_2_0= ruleIRIREF ) )
                    // InternalMyDsl.g:1784:5: (lv_iriString_2_0= ruleIRIREF )
                    {
                    // InternalMyDsl.g:1784:5: (lv_iriString_2_0= ruleIRIREF )
                    // InternalMyDsl.g:1785:6: lv_iriString_2_0= ruleIRIREF
                    {

                    						newCompositeNode(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_0_2_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_iriString_2_0=ruleIRIREF();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPrefixRule());
                    						}
                    						set(
                    							current,
                    							"iriString",
                    							lv_iriString_2_0,
                    							"org.xtext.example.mydsl.MyDsl.IRIREF");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_3=(Token)match(input,RULE_DOT,FOLLOW_2); 

                    				newLeafNode(this_DOT_3, grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_0_3());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1808:3: (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT )
                    {
                    // InternalMyDsl.g:1808:3: (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT )
                    // InternalMyDsl.g:1809:4: this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT
                    {
                    this_PRFX_4=(Token)match(input,RULE_PRFX,FOLLOW_23); 

                    				newLeafNode(this_PRFX_4, grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_1_0());
                    			
                    // InternalMyDsl.g:1813:4: ( (lv_t_5_0= RULE_PNAME_NS ) )
                    // InternalMyDsl.g:1814:5: (lv_t_5_0= RULE_PNAME_NS )
                    {
                    // InternalMyDsl.g:1814:5: (lv_t_5_0= RULE_PNAME_NS )
                    // InternalMyDsl.g:1815:6: lv_t_5_0= RULE_PNAME_NS
                    {
                    lv_t_5_0=(Token)match(input,RULE_PNAME_NS,FOLLOW_22); 

                    						newLeafNode(lv_t_5_0, grammarAccess.getPrefixAccess().getTPNAME_NSTerminalRuleCall_1_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPrefixRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"t",
                    							lv_t_5_0,
                    							"org.xtext.example.mydsl.MyDsl.PNAME_NS");
                    					

                    }


                    }

                    // InternalMyDsl.g:1831:4: ( (lv_iriString_6_0= ruleIRIREF ) )
                    // InternalMyDsl.g:1832:5: (lv_iriString_6_0= ruleIRIREF )
                    {
                    // InternalMyDsl.g:1832:5: (lv_iriString_6_0= ruleIRIREF )
                    // InternalMyDsl.g:1833:6: lv_iriString_6_0= ruleIRIREF
                    {

                    						newCompositeNode(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_1_2_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_iriString_6_0=ruleIRIREF();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPrefixRule());
                    						}
                    						set(
                    							current,
                    							"iriString",
                    							lv_iriString_6_0,
                    							"org.xtext.example.mydsl.MyDsl.IRIREF");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_7=(Token)match(input,RULE_DOT,FOLLOW_2); 

                    				newLeafNode(this_DOT_7, grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_1_3());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1856:3: (this_PRFX_8= RULE_PRFX ( (lv_t_9_0= RULE_COLON ) ) ( (lv_iriString_10_0= ruleIRIREF ) ) this_DOT_11= RULE_DOT this_E_12= RULE_E )
                    {
                    // InternalMyDsl.g:1856:3: (this_PRFX_8= RULE_PRFX ( (lv_t_9_0= RULE_COLON ) ) ( (lv_iriString_10_0= ruleIRIREF ) ) this_DOT_11= RULE_DOT this_E_12= RULE_E )
                    // InternalMyDsl.g:1857:4: this_PRFX_8= RULE_PRFX ( (lv_t_9_0= RULE_COLON ) ) ( (lv_iriString_10_0= ruleIRIREF ) ) this_DOT_11= RULE_DOT this_E_12= RULE_E
                    {
                    this_PRFX_8=(Token)match(input,RULE_PRFX,FOLLOW_20); 

                    				newLeafNode(this_PRFX_8, grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_2_0());
                    			
                    // InternalMyDsl.g:1861:4: ( (lv_t_9_0= RULE_COLON ) )
                    // InternalMyDsl.g:1862:5: (lv_t_9_0= RULE_COLON )
                    {
                    // InternalMyDsl.g:1862:5: (lv_t_9_0= RULE_COLON )
                    // InternalMyDsl.g:1863:6: lv_t_9_0= RULE_COLON
                    {
                    lv_t_9_0=(Token)match(input,RULE_COLON,FOLLOW_22); 

                    						newLeafNode(lv_t_9_0, grammarAccess.getPrefixAccess().getTCOLONTerminalRuleCall_2_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPrefixRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"t",
                    							lv_t_9_0,
                    							"org.xtext.example.mydsl.MyDsl.COLON");
                    					

                    }


                    }

                    // InternalMyDsl.g:1879:4: ( (lv_iriString_10_0= ruleIRIREF ) )
                    // InternalMyDsl.g:1880:5: (lv_iriString_10_0= ruleIRIREF )
                    {
                    // InternalMyDsl.g:1880:5: (lv_iriString_10_0= ruleIRIREF )
                    // InternalMyDsl.g:1881:6: lv_iriString_10_0= ruleIRIREF
                    {

                    						newCompositeNode(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_iriString_10_0=ruleIRIREF();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPrefixRule());
                    						}
                    						set(
                    							current,
                    							"iriString",
                    							lv_iriString_10_0,
                    							"org.xtext.example.mydsl.MyDsl.IRIREF");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_11=(Token)match(input,RULE_DOT,FOLLOW_16); 

                    				newLeafNode(this_DOT_11, grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_2_3());
                    			
                    this_E_12=(Token)match(input,RULE_E,FOLLOW_2); 

                    				newLeafNode(this_E_12, grammarAccess.getPrefixAccess().getETerminalRuleCall_2_4());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:1908:3: (this_PRFX_13= RULE_PRFX ( (lv_t_14_0= RULE_PNAME_NS ) ) ( (lv_iriString_15_0= ruleIRIREF ) ) this_DOT_16= RULE_DOT this_E_17= RULE_E )
                    {
                    // InternalMyDsl.g:1908:3: (this_PRFX_13= RULE_PRFX ( (lv_t_14_0= RULE_PNAME_NS ) ) ( (lv_iriString_15_0= ruleIRIREF ) ) this_DOT_16= RULE_DOT this_E_17= RULE_E )
                    // InternalMyDsl.g:1909:4: this_PRFX_13= RULE_PRFX ( (lv_t_14_0= RULE_PNAME_NS ) ) ( (lv_iriString_15_0= ruleIRIREF ) ) this_DOT_16= RULE_DOT this_E_17= RULE_E
                    {
                    this_PRFX_13=(Token)match(input,RULE_PRFX,FOLLOW_23); 

                    				newLeafNode(this_PRFX_13, grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_3_0());
                    			
                    // InternalMyDsl.g:1913:4: ( (lv_t_14_0= RULE_PNAME_NS ) )
                    // InternalMyDsl.g:1914:5: (lv_t_14_0= RULE_PNAME_NS )
                    {
                    // InternalMyDsl.g:1914:5: (lv_t_14_0= RULE_PNAME_NS )
                    // InternalMyDsl.g:1915:6: lv_t_14_0= RULE_PNAME_NS
                    {
                    lv_t_14_0=(Token)match(input,RULE_PNAME_NS,FOLLOW_22); 

                    						newLeafNode(lv_t_14_0, grammarAccess.getPrefixAccess().getTPNAME_NSTerminalRuleCall_3_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPrefixRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"t",
                    							lv_t_14_0,
                    							"org.xtext.example.mydsl.MyDsl.PNAME_NS");
                    					

                    }


                    }

                    // InternalMyDsl.g:1931:4: ( (lv_iriString_15_0= ruleIRIREF ) )
                    // InternalMyDsl.g:1932:5: (lv_iriString_15_0= ruleIRIREF )
                    {
                    // InternalMyDsl.g:1932:5: (lv_iriString_15_0= ruleIRIREF )
                    // InternalMyDsl.g:1933:6: lv_iriString_15_0= ruleIRIREF
                    {

                    						newCompositeNode(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_iriString_15_0=ruleIRIREF();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPrefixRule());
                    						}
                    						set(
                    							current,
                    							"iriString",
                    							lv_iriString_15_0,
                    							"org.xtext.example.mydsl.MyDsl.IRIREF");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_16=(Token)match(input,RULE_DOT,FOLLOW_16); 

                    				newLeafNode(this_DOT_16, grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_3_3());
                    			
                    this_E_17=(Token)match(input,RULE_E,FOLLOW_2); 

                    				newLeafNode(this_E_17, grammarAccess.getPrefixAccess().getETerminalRuleCall_3_4());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrefix"


    // $ANTLR start "entryRuleBase"
    // InternalMyDsl.g:1963:1: entryRuleBase returns [EObject current=null] : iv_ruleBase= ruleBase EOF ;
    public final EObject entryRuleBase() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBase = null;


        try {
            // InternalMyDsl.g:1963:45: (iv_ruleBase= ruleBase EOF )
            // InternalMyDsl.g:1964:2: iv_ruleBase= ruleBase EOF
            {
             newCompositeNode(grammarAccess.getBaseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBase=ruleBase();

            state._fsp--;

             current =iv_ruleBase; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBase"


    // $ANTLR start "ruleBase"
    // InternalMyDsl.g:1970:1: ruleBase returns [EObject current=null] : ( (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT ) | (this_BS_3= RULE_BS ( (lv_iriString_4_0= ruleIRIREF ) ) this_DOT_5= RULE_DOT this_E_6= RULE_E ) ) ;
    public final EObject ruleBase() throws RecognitionException {
        EObject current = null;

        Token this_BS_0=null;
        Token this_DOT_2=null;
        Token this_BS_3=null;
        Token this_DOT_5=null;
        Token this_E_6=null;
        EObject lv_iriString_1_0 = null;

        EObject lv_iriString_4_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1976:2: ( ( (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT ) | (this_BS_3= RULE_BS ( (lv_iriString_4_0= ruleIRIREF ) ) this_DOT_5= RULE_DOT this_E_6= RULE_E ) ) )
            // InternalMyDsl.g:1977:2: ( (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT ) | (this_BS_3= RULE_BS ( (lv_iriString_4_0= ruleIRIREF ) ) this_DOT_5= RULE_DOT this_E_6= RULE_E ) )
            {
            // InternalMyDsl.g:1977:2: ( (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT ) | (this_BS_3= RULE_BS ( (lv_iriString_4_0= ruleIRIREF ) ) this_DOT_5= RULE_DOT this_E_6= RULE_E ) )
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==RULE_BS) ) {
                int LA19_1 = input.LA(2);

                if ( (LA19_1==RULE_IRI) ) {
                    int LA19_2 = input.LA(3);

                    if ( (LA19_2==RULE_DOT) ) {
                        int LA19_3 = input.LA(4);

                        if ( (LA19_3==RULE_E) ) {
                            alt19=2;
                        }
                        else if ( (LA19_3==EOF||(LA19_3>=RULE_PNAME_LN && LA19_3<=RULE_IRI)||LA19_3==RULE_VARORPREDNAME||LA19_3==RULE_SRC||LA19_3==RULE_PRFX) ) {
                            alt19=1;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 19, 3, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 19, 2, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 19, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }
            switch (alt19) {
                case 1 :
                    // InternalMyDsl.g:1978:3: (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT )
                    {
                    // InternalMyDsl.g:1978:3: (this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT )
                    // InternalMyDsl.g:1979:4: this_BS_0= RULE_BS ( (lv_iriString_1_0= ruleIRIREF ) ) this_DOT_2= RULE_DOT
                    {
                    this_BS_0=(Token)match(input,RULE_BS,FOLLOW_22); 

                    				newLeafNode(this_BS_0, grammarAccess.getBaseAccess().getBSTerminalRuleCall_0_0());
                    			
                    // InternalMyDsl.g:1983:4: ( (lv_iriString_1_0= ruleIRIREF ) )
                    // InternalMyDsl.g:1984:5: (lv_iriString_1_0= ruleIRIREF )
                    {
                    // InternalMyDsl.g:1984:5: (lv_iriString_1_0= ruleIRIREF )
                    // InternalMyDsl.g:1985:6: lv_iriString_1_0= ruleIRIREF
                    {

                    						newCompositeNode(grammarAccess.getBaseAccess().getIriStringIRIREFParserRuleCall_0_1_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_iriString_1_0=ruleIRIREF();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBaseRule());
                    						}
                    						set(
                    							current,
                    							"iriString",
                    							lv_iriString_1_0,
                    							"org.xtext.example.mydsl.MyDsl.IRIREF");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_2=(Token)match(input,RULE_DOT,FOLLOW_2); 

                    				newLeafNode(this_DOT_2, grammarAccess.getBaseAccess().getDOTTerminalRuleCall_0_2());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:2008:3: (this_BS_3= RULE_BS ( (lv_iriString_4_0= ruleIRIREF ) ) this_DOT_5= RULE_DOT this_E_6= RULE_E )
                    {
                    // InternalMyDsl.g:2008:3: (this_BS_3= RULE_BS ( (lv_iriString_4_0= ruleIRIREF ) ) this_DOT_5= RULE_DOT this_E_6= RULE_E )
                    // InternalMyDsl.g:2009:4: this_BS_3= RULE_BS ( (lv_iriString_4_0= ruleIRIREF ) ) this_DOT_5= RULE_DOT this_E_6= RULE_E
                    {
                    this_BS_3=(Token)match(input,RULE_BS,FOLLOW_22); 

                    				newLeafNode(this_BS_3, grammarAccess.getBaseAccess().getBSTerminalRuleCall_1_0());
                    			
                    // InternalMyDsl.g:2013:4: ( (lv_iriString_4_0= ruleIRIREF ) )
                    // InternalMyDsl.g:2014:5: (lv_iriString_4_0= ruleIRIREF )
                    {
                    // InternalMyDsl.g:2014:5: (lv_iriString_4_0= ruleIRIREF )
                    // InternalMyDsl.g:2015:6: lv_iriString_4_0= ruleIRIREF
                    {

                    						newCompositeNode(grammarAccess.getBaseAccess().getIriStringIRIREFParserRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_15);
                    lv_iriString_4_0=ruleIRIREF();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBaseRule());
                    						}
                    						set(
                    							current,
                    							"iriString",
                    							lv_iriString_4_0,
                    							"org.xtext.example.mydsl.MyDsl.IRIREF");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    this_DOT_5=(Token)match(input,RULE_DOT,FOLLOW_16); 

                    				newLeafNode(this_DOT_5, grammarAccess.getBaseAccess().getDOTTerminalRuleCall_1_2());
                    			
                    this_E_6=(Token)match(input,RULE_E,FOLLOW_2); 

                    				newLeafNode(this_E_6, grammarAccess.getBaseAccess().getETerminalRuleCall_1_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBase"

    // Delegated rules


    protected DFA15 dfa15 = new DFA15(this);
    protected DFA17 dfa17 = new DFA17(this);
    protected DFA18 dfa18 = new DFA18(this);
    static final String dfa_1s = "\u00f0\uffff";
    static final String dfa_2s = "\41\uffff\1\51\136\uffff\1\u0090\157\uffff";
    static final String dfa_3s = "\1\4\3\24\1\4\5\22\4\12\3\22\1\4\2\22\1\4\5\22\4\12\3\22\3\4\3\22\1\4\2\uffff\6\24\1\4\2\22\2\4\3\24\5\22\4\12\10\22\4\12\3\22\2\4\2\22\2\4\2\22\1\4\5\22\4\12\10\22\4\12\12\22\4\12\3\22\2\4\2\22\1\4\2\22\1\4\1\22\1\4\1\22\1\4\3\24\1\4\2\uffff\5\22\4\12\11\22\1\4\3\24\1\22\1\4\5\22\4\12\3\22\1\4\2\22\1\4\2\22\1\4\5\22\4\12\10\22\4\12\5\22\1\4\2\22\1\4\1\22\1\4\5\22\4\12\10\22\1\4\2\22";
    static final String dfa_4s = "\1\21\3\24\1\21\14\25\1\21\1\27\1\25\1\5\14\25\1\30\1\21\1\23\3\25\1\5\2\uffff\6\24\1\21\2\25\2\21\3\24\30\25\2\21\1\26\1\25\1\5\1\21\1\27\1\25\1\5\46\25\1\23\1\30\2\25\1\21\1\27\1\25\1\5\1\25\1\5\1\25\1\5\3\24\1\21\2\uffff\22\25\1\21\3\24\1\25\1\5\14\25\1\21\2\25\1\21\1\27\1\25\1\5\32\25\1\21\1\27\1\25\1\5\1\25\1\5\21\25\1\5\2\25";
    static final String dfa_5s = "\50\uffff\1\4\1\2\145\uffff\1\3\1\1\137\uffff";
    static final String dfa_6s = "\u00f0\uffff}>";
    static final String[] dfa_7s = {
            "\1\2\1\1\13\uffff\1\3",
            "\1\4",
            "\1\4",
            "\1\4",
            "\1\6\1\5\1\12\1\13\1\14\1\15\2\uffff\1\7\1\10\1\11\1\16\1\17\1\20",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\23\1\24\6\uffff\1\21\2\uffff\1\22",
            "\1\23\1\24\6\uffff\1\21\2\uffff\1\22",
            "\1\23\1\24\6\uffff\1\21\2\uffff\1\22",
            "\1\23\1\24\6\uffff\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\26\1\25\1\32\1\33\1\34\1\35\2\uffff\1\27\1\30\1\31\1\36\1\37\1\40",
            "\1\42\3\uffff\1\43\1\41",
            "\1\21\2\uffff\1\22",
            "\1\45\1\44",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\46\1\47\6\uffff\1\21\2\uffff\1\22",
            "\1\46\1\47\6\uffff\1\21\2\uffff\1\22",
            "\1\46\1\47\6\uffff\1\21\2\uffff\1\22",
            "\1\46\1\47\6\uffff\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\2\51\13\uffff\1\51\6\uffff\1\50",
            "\1\53\1\52\13\uffff\1\54",
            "\1\56\1\55\13\uffff\1\57\1\uffff\1\60",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\62\1\61",
            "",
            "",
            "\1\63",
            "\1\63",
            "\1\63",
            "\1\64",
            "\1\64",
            "\1\64",
            "\1\66\1\65\13\uffff\1\67",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\71\1\70\1\75\1\76\1\77\1\100\2\uffff\1\72\1\73\1\74\1\101\1\102\1\103",
            "\1\105\1\104\1\111\1\112\1\113\1\114\2\uffff\1\106\1\107\1\110\1\115\1\116\1\117",
            "\1\120",
            "\1\120",
            "\1\120",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\123\1\124\6\uffff\1\121\2\uffff\1\122",
            "\1\123\1\124\6\uffff\1\121\2\uffff\1\122",
            "\1\123\1\124\6\uffff\1\121\2\uffff\1\122",
            "\1\123\1\124\6\uffff\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\127\1\130\6\uffff\1\125\2\uffff\1\126",
            "\1\127\1\130\6\uffff\1\125\2\uffff\1\126",
            "\1\127\1\130\6\uffff\1\125\2\uffff\1\126",
            "\1\127\1\130\6\uffff\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\132\1\131\1\136\1\137\1\140\1\141\2\uffff\1\133\1\134\1\135\1\142\1\143\1\144",
            "\1\146\1\145\1\152\1\153\1\154\1\155\2\uffff\1\147\1\150\1\151\1\156\1\157\1\160",
            "\1\42\3\uffff\1\43",
            "\1\121\2\uffff\1\122",
            "\1\162\1\161",
            "\1\164\1\163\1\170\1\171\1\172\1\173\2\uffff\1\165\1\166\1\167\1\174\1\175\1\176",
            "\1\177\4\uffff\1\u0080",
            "\1\125\2\uffff\1\126",
            "\1\u0082\1\u0081",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0085\1\u0086\6\uffff\1\u0083\2\uffff\1\u0084",
            "\1\u0085\1\u0086\6\uffff\1\u0083\2\uffff\1\u0084",
            "\1\u0085\1\u0086\6\uffff\1\u0083\2\uffff\1\u0084",
            "\1\u0085\1\u0086\6\uffff\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\u0087\1\u0088\6\uffff\1\121\2\uffff\1\122",
            "\1\u0087\1\u0088\6\uffff\1\121\2\uffff\1\122",
            "\1\u0087\1\u0088\6\uffff\1\121\2\uffff\1\122",
            "\1\u0087\1\u0088\6\uffff\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\u0089\1\u008a\6\uffff\1\125\2\uffff\1\126",
            "\1\u0089\1\u008a\6\uffff\1\125\2\uffff\1\126",
            "\1\u0089\1\u008a\6\uffff\1\125\2\uffff\1\126",
            "\1\u0089\1\u008a\6\uffff\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\u008c\1\u008b\13\uffff\1\u008d\1\uffff\1\u008e",
            "\2\u0090\13\uffff\1\u0090\6\uffff\1\u008f",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\u0092\1\u0091\1\u0096\1\u0097\1\u0098\1\u0099\2\uffff\1\u0093\1\u0094\1\u0095\1\u009a\1\u009b\1\u009c",
            "\1\177\4\uffff\1\u0080",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u009e\1\u009d",
            "\1\121\2\uffff\1\122",
            "\1\u00a0\1\u009f",
            "\1\125\2\uffff\1\126",
            "\1\u00a2\1\u00a1",
            "\1\u00a3",
            "\1\u00a3",
            "\1\u00a3",
            "\1\u00a5\1\u00a4\13\uffff\1\u00a6",
            "",
            "",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u00a7\1\u00a8\6\uffff\1\u0083\2\uffff\1\u0084",
            "\1\u00a7\1\u00a8\6\uffff\1\u0083\2\uffff\1\u0084",
            "\1\u00a7\1\u00a8\6\uffff\1\u0083\2\uffff\1\u0084",
            "\1\u00a7\1\u00a8\6\uffff\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\u00aa\1\u00a9\1\u00ae\1\u00af\1\u00b0\1\u00b1\2\uffff\1\u00ab\1\u00ac\1\u00ad\1\u00b2\1\u00b3\1\u00b4",
            "\1\u00b5",
            "\1\u00b5",
            "\1\u00b5",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u00b7\1\u00b6",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00ba\1\u00bb\6\uffff\1\u00b8\2\uffff\1\u00b9",
            "\1\u00ba\1\u00bb\6\uffff\1\u00b8\2\uffff\1\u00b9",
            "\1\u00ba\1\u00bb\6\uffff\1\u00b8\2\uffff\1\u00b9",
            "\1\u00ba\1\u00bb\6\uffff\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00bd\1\u00bc\1\u00c1\1\u00c2\1\u00c3\1\u00c4\2\uffff\1\u00be\1\u00bf\1\u00c0\1\u00c5\1\u00c6\1\u00c7",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u00c9\1\u00c8\1\u00cd\1\u00ce\1\u00cf\1\u00d0\2\uffff\1\u00ca\1\u00cb\1\u00cc\1\u00d1\1\u00d2\1\u00d3",
            "\1\177\4\uffff\1\u0080",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00d5\1\u00d4",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d8\1\u00d9\6\uffff\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d8\1\u00d9\6\uffff\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d8\1\u00d9\6\uffff\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d8\1\u00d9\6\uffff\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00da\1\u00db\6\uffff\1\u00b8\2\uffff\1\u00b9",
            "\1\u00da\1\u00db\6\uffff\1\u00b8\2\uffff\1\u00b9",
            "\1\u00da\1\u00db\6\uffff\1\u00b8\2\uffff\1\u00b9",
            "\1\u00da\1\u00db\6\uffff\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00dd\1\u00dc\1\u00e1\1\u00e2\1\u00e3\1\u00e4\2\uffff\1\u00de\1\u00df\1\u00e0\1\u00e5\1\u00e6\1\u00e7",
            "\1\177\4\uffff\1\u0080",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00e9\1\u00e8",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00eb\1\u00ea",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00ec\1\u00ed\6\uffff\1\u00d6\2\uffff\1\u00d7",
            "\1\u00ec\1\u00ed\6\uffff\1\u00d6\2\uffff\1\u00d7",
            "\1\u00ec\1\u00ed\6\uffff\1\u00d6\2\uffff\1\u00d7",
            "\1\u00ec\1\u00ed\6\uffff\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00ef\1\u00ee",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA15 extends DFA {

        public DFA15(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 15;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "1293:2: ( ( (lv_statement_0_0= ruleRule ) ) | ( ( (lv_statement_1_0= ruleFact ) ) this_DOT_2= RULE_DOT ) | ( ( (lv_statement_3_0= ruleRule ) ) this_E_4= RULE_E ) | ( ( (lv_statement_5_0= ruleFact ) ) this_DOT_6= RULE_DOT this_E_7= RULE_E ) )";
        }
    }
    static final String dfa_8s = "\51\uffff";
    static final String dfa_9s = "\34\uffff\1\41\14\uffff";
    static final String dfa_10s = "\1\34\1\4\3\24\1\14\1\25\1\35\1\31\3\24\2\6\1\4\10\25\2\22\2\27\1\6\1\4\4\22\2\uffff\1\6\4\25\1\27";
    static final String dfa_11s = "\1\34\1\21\3\24\1\14\1\25\1\35\1\33\3\24\2\11\1\5\10\25\2\22\2\27\1\11\1\34\4\22\2\uffff\1\11\4\25\1\27";
    static final String dfa_12s = "\41\uffff\1\1\1\2\6\uffff";
    static final String dfa_13s = "\51\uffff}>";
    static final String[] dfa_14s = {
            "\1\1",
            "\1\3\1\2\13\uffff\1\4",
            "\1\5",
            "\1\5",
            "\1\5",
            "\1\6",
            "\1\7",
            "\1\10",
            "\1\11\1\12\1\13",
            "\1\14",
            "\1\15",
            "\1\16",
            "\1\17\1\20\1\21\1\22",
            "\1\23\1\24\1\25\1\26",
            "\1\30\1\27",
            "\1\31",
            "\1\31",
            "\1\31",
            "\1\31",
            "\1\32",
            "\1\32",
            "\1\32",
            "\1\32",
            "\1\33",
            "\1\33",
            "\1\34",
            "\1\34",
            "\1\35\1\36\1\37\1\40",
            "\2\41\13\uffff\1\41\6\uffff\1\42\3\uffff\1\41",
            "\1\43",
            "\1\43",
            "\1\43",
            "\1\43",
            "",
            "",
            "\1\44\1\45\1\46\1\47",
            "\1\50",
            "\1\50",
            "\1\50",
            "\1\50",
            "\1\34"
    };

    static final short[] dfa_8 = DFA.unpackEncodedString(dfa_8s);
    static final short[] dfa_9 = DFA.unpackEncodedString(dfa_9s);
    static final char[] dfa_10 = DFA.unpackEncodedStringToUnsignedChars(dfa_10s);
    static final char[] dfa_11 = DFA.unpackEncodedStringToUnsignedChars(dfa_11s);
    static final short[] dfa_12 = DFA.unpackEncodedString(dfa_12s);
    static final short[] dfa_13 = DFA.unpackEncodedString(dfa_13s);
    static final short[][] dfa_14 = unpackEncodedStringArray(dfa_14s);

    class DFA17 extends DFA {

        public DFA17(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 17;
            this.eot = dfa_8;
            this.eof = dfa_9;
            this.min = dfa_10;
            this.max = dfa_11;
            this.accept = dfa_12;
            this.special = dfa_13;
            this.transition = dfa_14;
        }
        public String getDescription() {
            return "1579:2: ( (this_SRC_0= RULE_SRC ( (lv_predicatename_1_0= rulepredicateName ) ) this_LPAREN_2= RULE_LPAREN ( (lv_arity_3_0= RULE_INTEGER ) ) this_RPAREN_4= RULE_RPAREN this_COLON_5= RULE_COLON ( (lv_dataSource_6_0= ruleDataSource ) ) this_DOT_7= RULE_DOT ) | (this_SRC_8= RULE_SRC ( (lv_predicatename_9_0= rulepredicateName ) ) this_LPAREN_10= RULE_LPAREN ( (lv_arity_11_0= RULE_INTEGER ) ) this_RPAREN_12= RULE_RPAREN this_COLON_13= RULE_COLON ( (lv_dataSource_14_0= ruleDataSource ) ) this_DOT_15= RULE_DOT this_E_16= RULE_E ) )";
        }
    }
    static final String dfa_15s = "\14\uffff";
    static final String dfa_16s = "\6\uffff\1\10\1\12\4\uffff";
    static final String dfa_17s = "\1\36\1\35\2\5\2\27\2\4\4\uffff";
    static final String dfa_18s = "\1\36\1\37\2\5\2\27\2\36\4\uffff";
    static final String dfa_19s = "\10\uffff\1\1\1\3\1\2\1\4";
    static final String dfa_20s = "\14\uffff}>";
    static final String[] dfa_21s = {
            "\1\1",
            "\1\2\1\uffff\1\3",
            "\1\4",
            "\1\5",
            "\1\6",
            "\1\7",
            "\2\10\13\uffff\1\10\6\uffff\1\11\3\uffff\1\10\1\uffff\1\10",
            "\2\12\13\uffff\1\12\6\uffff\1\13\3\uffff\1\12\1\uffff\1\12",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_15 = DFA.unpackEncodedString(dfa_15s);
    static final short[] dfa_16 = DFA.unpackEncodedString(dfa_16s);
    static final char[] dfa_17 = DFA.unpackEncodedStringToUnsignedChars(dfa_17s);
    static final char[] dfa_18 = DFA.unpackEncodedStringToUnsignedChars(dfa_18s);
    static final short[] dfa_19 = DFA.unpackEncodedString(dfa_19s);
    static final short[] dfa_20 = DFA.unpackEncodedString(dfa_20s);
    static final short[][] dfa_21 = unpackEncodedStringArray(dfa_21s);

    class DFA18 extends DFA {

        public DFA18(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 18;
            this.eot = dfa_15;
            this.eof = dfa_16;
            this.min = dfa_17;
            this.max = dfa_18;
            this.accept = dfa_19;
            this.special = dfa_20;
            this.transition = dfa_21;
        }
        public String getDescription() {
            return "1759:2: ( (this_PRFX_0= RULE_PRFX ( (lv_t_1_0= RULE_COLON ) ) ( (lv_iriString_2_0= ruleIRIREF ) ) this_DOT_3= RULE_DOT ) | (this_PRFX_4= RULE_PRFX ( (lv_t_5_0= RULE_PNAME_NS ) ) ( (lv_iriString_6_0= ruleIRIREF ) ) this_DOT_7= RULE_DOT ) | (this_PRFX_8= RULE_PRFX ( (lv_t_9_0= RULE_COLON ) ) ( (lv_iriString_10_0= ruleIRIREF ) ) this_DOT_11= RULE_DOT this_E_12= RULE_E ) | (this_PRFX_13= RULE_PRFX ( (lv_t_14_0= RULE_PNAME_NS ) ) ( (lv_iriString_15_0= ruleIRIREF ) ) this_DOT_16= RULE_DOT this_E_17= RULE_E ) )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000050020032L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000010020032L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000020032L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000C02L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x000000000003F3F0L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000020030L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x00000000000A0030L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x00000000000003C0L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x000000000E000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000080000000L});

}