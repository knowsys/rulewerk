package org.xtext.example.mydsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.example.mydsl.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_DATATYPE", "RULE_COMMA", "RULE_TILDE", "RULE_LPAREN", "RULE_RPAREN", "RULE_ARROW", "RULE_DOT", "RULE_E", "RULE_LOADCSV", "RULE_LOADRDF", "RULE_SPARQL", "RULE_SRC", "RULE_COLON", "RULE_PRFX", "RULE_BS", "RULE_PNAME_LN", "RULE_IRI", "RULE_STRING_LITERAL1", "RULE_STRING_LITERAL2", "RULE_STRING_LITERAL_LONG1", "RULE_STRING_LITERAL_LONG2", "RULE_LANGTAG", "RULE_INTEGER", "RULE_DECIMAL", "RULE_DOUBLE", "RULE_UNIVAR", "RULE_EXIVAR", "RULE_VARORPREDNAME", "RULE_PNAME_NS", "RULE_DIGITS", "RULE_EXPONENT", "RULE_SKIP", "RULE_ECHAR", "RULE_PN_PREFIX", "RULE_PN_LOCAL", "RULE_QMARK", "RULE_EMARK", "RULE_AT", "RULE_A2Z", "RULE_A2ZN", "RULE_A2ZNX", "RULE_DIRECTIVENAME", "RULE_LBRACK", "RULE_RBRACK", "RULE_PN_CHARS_BASE", "RULE_PN_CHARS_U", "RULE_PN_CHARS"
    };
    public static final int RULE_LPAREN=7;
    public static final int RULE_PRFX=17;
    public static final int RULE_ARROW=9;
    public static final int RULE_A2Z=42;
    public static final int RULE_A2ZNX=44;
    public static final int RULE_PNAME_LN=19;
    public static final int RULE_COMMA=5;
    public static final int RULE_DATATYPE=4;
    public static final int RULE_COLON=16;
    public static final int RULE_DECIMAL=27;
    public static final int RULE_DIRECTIVENAME=45;
    public static final int RULE_TILDE=6;
    public static final int RULE_SPARQL=14;
    public static final int RULE_PN_PREFIX=37;
    public static final int RULE_ECHAR=36;
    public static final int RULE_SRC=15;
    public static final int RULE_EXIVAR=30;
    public static final int RULE_EMARK=40;
    public static final int RULE_PN_CHARS_BASE=48;
    public static final int RULE_STRING_LITERAL1=21;
    public static final int RULE_STRING_LITERAL2=22;
    public static final int RULE_IRI=20;
    public static final int RULE_VARORPREDNAME=31;
    public static final int RULE_QMARK=39;
    public static final int RULE_A2ZN=43;
    public static final int RULE_STRING_LITERAL_LONG1=23;
    public static final int RULE_STRING_LITERAL_LONG2=24;
    public static final int RULE_SKIP=35;
    public static final int RULE_DIGITS=33;
    public static final int RULE_AT=41;
    public static final int RULE_PN_LOCAL=38;
    public static final int RULE_DOUBLE=28;
    public static final int RULE_UNIVAR=29;
    public static final int RULE_PNAME_NS=32;
    public static final int RULE_DOT=10;
    public static final int EOF=-1;
    public static final int RULE_LANGTAG=25;
    public static final int RULE_RBRACK=47;
    public static final int RULE_PN_CHARS=50;
    public static final int RULE_LOADRDF=13;
    public static final int RULE_BS=18;
    public static final int RULE_RPAREN=8;
    public static final int RULE_EXPONENT=34;
    public static final int RULE_PN_CHARS_U=49;
    public static final int RULE_E=11;
    public static final int RULE_LOADCSV=12;
    public static final int RULE_INTEGER=26;
    public static final int RULE_LBRACK=46;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }


    	private MyDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(MyDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalMyDsl.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalMyDsl.g:54:1: ( ruleModel EOF )
            // InternalMyDsl.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalMyDsl.g:62:1: ruleModel : ( ( rule__Model__Group__0 ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:66:2: ( ( ( rule__Model__Group__0 ) ) )
            // InternalMyDsl.g:67:2: ( ( rule__Model__Group__0 ) )
            {
            // InternalMyDsl.g:67:2: ( ( rule__Model__Group__0 ) )
            // InternalMyDsl.g:68:3: ( rule__Model__Group__0 )
            {
             before(grammarAccess.getModelAccess().getGroup()); 
            // InternalMyDsl.g:69:3: ( rule__Model__Group__0 )
            // InternalMyDsl.g:69:4: rule__Model__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRulePrefixedName"
    // InternalMyDsl.g:78:1: entryRulePrefixedName : rulePrefixedName EOF ;
    public final void entryRulePrefixedName() throws RecognitionException {
        try {
            // InternalMyDsl.g:79:1: ( rulePrefixedName EOF )
            // InternalMyDsl.g:80:1: rulePrefixedName EOF
            {
             before(grammarAccess.getPrefixedNameRule()); 
            pushFollow(FOLLOW_1);
            rulePrefixedName();

            state._fsp--;

             after(grammarAccess.getPrefixedNameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrefixedName"


    // $ANTLR start "rulePrefixedName"
    // InternalMyDsl.g:87:1: rulePrefixedName : ( ( rule__PrefixedName__TAssignment ) ) ;
    public final void rulePrefixedName() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:91:2: ( ( ( rule__PrefixedName__TAssignment ) ) )
            // InternalMyDsl.g:92:2: ( ( rule__PrefixedName__TAssignment ) )
            {
            // InternalMyDsl.g:92:2: ( ( rule__PrefixedName__TAssignment ) )
            // InternalMyDsl.g:93:3: ( rule__PrefixedName__TAssignment )
            {
             before(grammarAccess.getPrefixedNameAccess().getTAssignment()); 
            // InternalMyDsl.g:94:3: ( rule__PrefixedName__TAssignment )
            // InternalMyDsl.g:94:4: rule__PrefixedName__TAssignment
            {
            pushFollow(FOLLOW_2);
            rule__PrefixedName__TAssignment();

            state._fsp--;


            }

             after(grammarAccess.getPrefixedNameAccess().getTAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrefixedName"


    // $ANTLR start "entryRuleIRIREF"
    // InternalMyDsl.g:103:1: entryRuleIRIREF : ruleIRIREF EOF ;
    public final void entryRuleIRIREF() throws RecognitionException {
        try {
            // InternalMyDsl.g:104:1: ( ruleIRIREF EOF )
            // InternalMyDsl.g:105:1: ruleIRIREF EOF
            {
             before(grammarAccess.getIRIREFRule()); 
            pushFollow(FOLLOW_1);
            ruleIRIREF();

            state._fsp--;

             after(grammarAccess.getIRIREFRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleIRIREF"


    // $ANTLR start "ruleIRIREF"
    // InternalMyDsl.g:112:1: ruleIRIREF : ( ( rule__IRIREF__TAssignment ) ) ;
    public final void ruleIRIREF() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:116:2: ( ( ( rule__IRIREF__TAssignment ) ) )
            // InternalMyDsl.g:117:2: ( ( rule__IRIREF__TAssignment ) )
            {
            // InternalMyDsl.g:117:2: ( ( rule__IRIREF__TAssignment ) )
            // InternalMyDsl.g:118:3: ( rule__IRIREF__TAssignment )
            {
             before(grammarAccess.getIRIREFAccess().getTAssignment()); 
            // InternalMyDsl.g:119:3: ( rule__IRIREF__TAssignment )
            // InternalMyDsl.g:119:4: rule__IRIREF__TAssignment
            {
            pushFollow(FOLLOW_2);
            rule__IRIREF__TAssignment();

            state._fsp--;


            }

             after(grammarAccess.getIRIREFAccess().getTAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleIRIREF"


    // $ANTLR start "entryRuleIRIBOL"
    // InternalMyDsl.g:128:1: entryRuleIRIBOL : ruleIRIBOL EOF ;
    public final void entryRuleIRIBOL() throws RecognitionException {
        try {
            // InternalMyDsl.g:129:1: ( ruleIRIBOL EOF )
            // InternalMyDsl.g:130:1: ruleIRIBOL EOF
            {
             before(grammarAccess.getIRIBOLRule()); 
            pushFollow(FOLLOW_1);
            ruleIRIBOL();

            state._fsp--;

             after(grammarAccess.getIRIBOLRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleIRIBOL"


    // $ANTLR start "ruleIRIBOL"
    // InternalMyDsl.g:137:1: ruleIRIBOL : ( ( rule__IRIBOL__Alternatives ) ) ;
    public final void ruleIRIBOL() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:141:2: ( ( ( rule__IRIBOL__Alternatives ) ) )
            // InternalMyDsl.g:142:2: ( ( rule__IRIBOL__Alternatives ) )
            {
            // InternalMyDsl.g:142:2: ( ( rule__IRIBOL__Alternatives ) )
            // InternalMyDsl.g:143:3: ( rule__IRIBOL__Alternatives )
            {
             before(grammarAccess.getIRIBOLAccess().getAlternatives()); 
            // InternalMyDsl.g:144:3: ( rule__IRIBOL__Alternatives )
            // InternalMyDsl.g:144:4: rule__IRIBOL__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__IRIBOL__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getIRIBOLAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleIRIBOL"


    // $ANTLR start "entryRuleStriing"
    // InternalMyDsl.g:153:1: entryRuleStriing : ruleStriing EOF ;
    public final void entryRuleStriing() throws RecognitionException {
        try {
            // InternalMyDsl.g:154:1: ( ruleStriing EOF )
            // InternalMyDsl.g:155:1: ruleStriing EOF
            {
             before(grammarAccess.getStriingRule()); 
            pushFollow(FOLLOW_1);
            ruleStriing();

            state._fsp--;

             after(grammarAccess.getStriingRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStriing"


    // $ANTLR start "ruleStriing"
    // InternalMyDsl.g:162:1: ruleStriing : ( ( rule__Striing__Alternatives ) ) ;
    public final void ruleStriing() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:166:2: ( ( ( rule__Striing__Alternatives ) ) )
            // InternalMyDsl.g:167:2: ( ( rule__Striing__Alternatives ) )
            {
            // InternalMyDsl.g:167:2: ( ( rule__Striing__Alternatives ) )
            // InternalMyDsl.g:168:3: ( rule__Striing__Alternatives )
            {
             before(grammarAccess.getStriingAccess().getAlternatives()); 
            // InternalMyDsl.g:169:3: ( rule__Striing__Alternatives )
            // InternalMyDsl.g:169:4: rule__Striing__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Striing__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getStriingAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStriing"


    // $ANTLR start "entryRuleLangtagg"
    // InternalMyDsl.g:178:1: entryRuleLangtagg : ruleLangtagg EOF ;
    public final void entryRuleLangtagg() throws RecognitionException {
        try {
            // InternalMyDsl.g:179:1: ( ruleLangtagg EOF )
            // InternalMyDsl.g:180:1: ruleLangtagg EOF
            {
             before(grammarAccess.getLangtaggRule()); 
            pushFollow(FOLLOW_1);
            ruleLangtagg();

            state._fsp--;

             after(grammarAccess.getLangtaggRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLangtagg"


    // $ANTLR start "ruleLangtagg"
    // InternalMyDsl.g:187:1: ruleLangtagg : ( ( rule__Langtagg__TAssignment ) ) ;
    public final void ruleLangtagg() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:191:2: ( ( ( rule__Langtagg__TAssignment ) ) )
            // InternalMyDsl.g:192:2: ( ( rule__Langtagg__TAssignment ) )
            {
            // InternalMyDsl.g:192:2: ( ( rule__Langtagg__TAssignment ) )
            // InternalMyDsl.g:193:3: ( rule__Langtagg__TAssignment )
            {
             before(grammarAccess.getLangtaggAccess().getTAssignment()); 
            // InternalMyDsl.g:194:3: ( rule__Langtagg__TAssignment )
            // InternalMyDsl.g:194:4: rule__Langtagg__TAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Langtagg__TAssignment();

            state._fsp--;


            }

             after(grammarAccess.getLangtaggAccess().getTAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLangtagg"


    // $ANTLR start "entryRuleRDFLiteral"
    // InternalMyDsl.g:203:1: entryRuleRDFLiteral : ruleRDFLiteral EOF ;
    public final void entryRuleRDFLiteral() throws RecognitionException {
        try {
            // InternalMyDsl.g:204:1: ( ruleRDFLiteral EOF )
            // InternalMyDsl.g:205:1: ruleRDFLiteral EOF
            {
             before(grammarAccess.getRDFLiteralRule()); 
            pushFollow(FOLLOW_1);
            ruleRDFLiteral();

            state._fsp--;

             after(grammarAccess.getRDFLiteralRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRDFLiteral"


    // $ANTLR start "ruleRDFLiteral"
    // InternalMyDsl.g:212:1: ruleRDFLiteral : ( ( rule__RDFLiteral__Group__0 ) ) ;
    public final void ruleRDFLiteral() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:216:2: ( ( ( rule__RDFLiteral__Group__0 ) ) )
            // InternalMyDsl.g:217:2: ( ( rule__RDFLiteral__Group__0 ) )
            {
            // InternalMyDsl.g:217:2: ( ( rule__RDFLiteral__Group__0 ) )
            // InternalMyDsl.g:218:3: ( rule__RDFLiteral__Group__0 )
            {
             before(grammarAccess.getRDFLiteralAccess().getGroup()); 
            // InternalMyDsl.g:219:3: ( rule__RDFLiteral__Group__0 )
            // InternalMyDsl.g:219:4: rule__RDFLiteral__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RDFLiteral__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRDFLiteralAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRDFLiteral"


    // $ANTLR start "entryRuleNumericLiteral"
    // InternalMyDsl.g:228:1: entryRuleNumericLiteral : ruleNumericLiteral EOF ;
    public final void entryRuleNumericLiteral() throws RecognitionException {
        try {
            // InternalMyDsl.g:229:1: ( ruleNumericLiteral EOF )
            // InternalMyDsl.g:230:1: ruleNumericLiteral EOF
            {
             before(grammarAccess.getNumericLiteralRule()); 
            pushFollow(FOLLOW_1);
            ruleNumericLiteral();

            state._fsp--;

             after(grammarAccess.getNumericLiteralRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNumericLiteral"


    // $ANTLR start "ruleNumericLiteral"
    // InternalMyDsl.g:237:1: ruleNumericLiteral : ( ( rule__NumericLiteral__Alternatives ) ) ;
    public final void ruleNumericLiteral() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:241:2: ( ( ( rule__NumericLiteral__Alternatives ) ) )
            // InternalMyDsl.g:242:2: ( ( rule__NumericLiteral__Alternatives ) )
            {
            // InternalMyDsl.g:242:2: ( ( rule__NumericLiteral__Alternatives ) )
            // InternalMyDsl.g:243:3: ( rule__NumericLiteral__Alternatives )
            {
             before(grammarAccess.getNumericLiteralAccess().getAlternatives()); 
            // InternalMyDsl.g:244:3: ( rule__NumericLiteral__Alternatives )
            // InternalMyDsl.g:244:4: rule__NumericLiteral__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__NumericLiteral__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getNumericLiteralAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNumericLiteral"


    // $ANTLR start "entryRuleTerm"
    // InternalMyDsl.g:253:1: entryRuleTerm : ruleTerm EOF ;
    public final void entryRuleTerm() throws RecognitionException {
        try {
            // InternalMyDsl.g:254:1: ( ruleTerm EOF )
            // InternalMyDsl.g:255:1: ruleTerm EOF
            {
             before(grammarAccess.getTermRule()); 
            pushFollow(FOLLOW_1);
            ruleTerm();

            state._fsp--;

             after(grammarAccess.getTermRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleTerm"


    // $ANTLR start "ruleTerm"
    // InternalMyDsl.g:262:1: ruleTerm : ( ( rule__Term__Alternatives ) ) ;
    public final void ruleTerm() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:266:2: ( ( ( rule__Term__Alternatives ) ) )
            // InternalMyDsl.g:267:2: ( ( rule__Term__Alternatives ) )
            {
            // InternalMyDsl.g:267:2: ( ( rule__Term__Alternatives ) )
            // InternalMyDsl.g:268:3: ( rule__Term__Alternatives )
            {
             before(grammarAccess.getTermAccess().getAlternatives()); 
            // InternalMyDsl.g:269:3: ( rule__Term__Alternatives )
            // InternalMyDsl.g:269:4: rule__Term__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Term__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getTermAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleTerm"


    // $ANTLR start "entryRulepredicateName"
    // InternalMyDsl.g:278:1: entryRulepredicateName : rulepredicateName EOF ;
    public final void entryRulepredicateName() throws RecognitionException {
        try {
            // InternalMyDsl.g:279:1: ( rulepredicateName EOF )
            // InternalMyDsl.g:280:1: rulepredicateName EOF
            {
             before(grammarAccess.getPredicateNameRule()); 
            pushFollow(FOLLOW_1);
            rulepredicateName();

            state._fsp--;

             after(grammarAccess.getPredicateNameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulepredicateName"


    // $ANTLR start "rulepredicateName"
    // InternalMyDsl.g:287:1: rulepredicateName : ( ( rule__PredicateName__Alternatives ) ) ;
    public final void rulepredicateName() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:291:2: ( ( ( rule__PredicateName__Alternatives ) ) )
            // InternalMyDsl.g:292:2: ( ( rule__PredicateName__Alternatives ) )
            {
            // InternalMyDsl.g:292:2: ( ( rule__PredicateName__Alternatives ) )
            // InternalMyDsl.g:293:3: ( rule__PredicateName__Alternatives )
            {
             before(grammarAccess.getPredicateNameAccess().getAlternatives()); 
            // InternalMyDsl.g:294:3: ( rule__PredicateName__Alternatives )
            // InternalMyDsl.g:294:4: rule__PredicateName__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__PredicateName__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getPredicateNameAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulepredicateName"


    // $ANTLR start "entryRulelistOfTerms"
    // InternalMyDsl.g:303:1: entryRulelistOfTerms : rulelistOfTerms EOF ;
    public final void entryRulelistOfTerms() throws RecognitionException {
        try {
            // InternalMyDsl.g:304:1: ( rulelistOfTerms EOF )
            // InternalMyDsl.g:305:1: rulelistOfTerms EOF
            {
             before(grammarAccess.getListOfTermsRule()); 
            pushFollow(FOLLOW_1);
            rulelistOfTerms();

            state._fsp--;

             after(grammarAccess.getListOfTermsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulelistOfTerms"


    // $ANTLR start "rulelistOfTerms"
    // InternalMyDsl.g:312:1: rulelistOfTerms : ( ( rule__ListOfTerms__Group__0 ) ) ;
    public final void rulelistOfTerms() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:316:2: ( ( ( rule__ListOfTerms__Group__0 ) ) )
            // InternalMyDsl.g:317:2: ( ( rule__ListOfTerms__Group__0 ) )
            {
            // InternalMyDsl.g:317:2: ( ( rule__ListOfTerms__Group__0 ) )
            // InternalMyDsl.g:318:3: ( rule__ListOfTerms__Group__0 )
            {
             before(grammarAccess.getListOfTermsAccess().getGroup()); 
            // InternalMyDsl.g:319:3: ( rule__ListOfTerms__Group__0 )
            // InternalMyDsl.g:319:4: rule__ListOfTerms__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ListOfTerms__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getListOfTermsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulelistOfTerms"


    // $ANTLR start "entryRuleNegativeLiteral"
    // InternalMyDsl.g:328:1: entryRuleNegativeLiteral : ruleNegativeLiteral EOF ;
    public final void entryRuleNegativeLiteral() throws RecognitionException {
        try {
            // InternalMyDsl.g:329:1: ( ruleNegativeLiteral EOF )
            // InternalMyDsl.g:330:1: ruleNegativeLiteral EOF
            {
             before(grammarAccess.getNegativeLiteralRule()); 
            pushFollow(FOLLOW_1);
            ruleNegativeLiteral();

            state._fsp--;

             after(grammarAccess.getNegativeLiteralRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleNegativeLiteral"


    // $ANTLR start "ruleNegativeLiteral"
    // InternalMyDsl.g:337:1: ruleNegativeLiteral : ( ( rule__NegativeLiteral__Group__0 ) ) ;
    public final void ruleNegativeLiteral() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:341:2: ( ( ( rule__NegativeLiteral__Group__0 ) ) )
            // InternalMyDsl.g:342:2: ( ( rule__NegativeLiteral__Group__0 ) )
            {
            // InternalMyDsl.g:342:2: ( ( rule__NegativeLiteral__Group__0 ) )
            // InternalMyDsl.g:343:3: ( rule__NegativeLiteral__Group__0 )
            {
             before(grammarAccess.getNegativeLiteralAccess().getGroup()); 
            // InternalMyDsl.g:344:3: ( rule__NegativeLiteral__Group__0 )
            // InternalMyDsl.g:344:4: rule__NegativeLiteral__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__NegativeLiteral__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getNegativeLiteralAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleNegativeLiteral"


    // $ANTLR start "entryRuleFact"
    // InternalMyDsl.g:353:1: entryRuleFact : ruleFact EOF ;
    public final void entryRuleFact() throws RecognitionException {
        try {
            // InternalMyDsl.g:354:1: ( ruleFact EOF )
            // InternalMyDsl.g:355:1: ruleFact EOF
            {
             before(grammarAccess.getFactRule()); 
            pushFollow(FOLLOW_1);
            ruleFact();

            state._fsp--;

             after(grammarAccess.getFactRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFact"


    // $ANTLR start "ruleFact"
    // InternalMyDsl.g:362:1: ruleFact : ( ( rule__Fact__Group__0 ) ) ;
    public final void ruleFact() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:366:2: ( ( ( rule__Fact__Group__0 ) ) )
            // InternalMyDsl.g:367:2: ( ( rule__Fact__Group__0 ) )
            {
            // InternalMyDsl.g:367:2: ( ( rule__Fact__Group__0 ) )
            // InternalMyDsl.g:368:3: ( rule__Fact__Group__0 )
            {
             before(grammarAccess.getFactAccess().getGroup()); 
            // InternalMyDsl.g:369:3: ( rule__Fact__Group__0 )
            // InternalMyDsl.g:369:4: rule__Fact__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Fact__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFactAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFact"


    // $ANTLR start "entryRulePositiveLiteral"
    // InternalMyDsl.g:378:1: entryRulePositiveLiteral : rulePositiveLiteral EOF ;
    public final void entryRulePositiveLiteral() throws RecognitionException {
        try {
            // InternalMyDsl.g:379:1: ( rulePositiveLiteral EOF )
            // InternalMyDsl.g:380:1: rulePositiveLiteral EOF
            {
             before(grammarAccess.getPositiveLiteralRule()); 
            pushFollow(FOLLOW_1);
            rulePositiveLiteral();

            state._fsp--;

             after(grammarAccess.getPositiveLiteralRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePositiveLiteral"


    // $ANTLR start "rulePositiveLiteral"
    // InternalMyDsl.g:387:1: rulePositiveLiteral : ( ( rule__PositiveLiteral__Group__0 ) ) ;
    public final void rulePositiveLiteral() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:391:2: ( ( ( rule__PositiveLiteral__Group__0 ) ) )
            // InternalMyDsl.g:392:2: ( ( rule__PositiveLiteral__Group__0 ) )
            {
            // InternalMyDsl.g:392:2: ( ( rule__PositiveLiteral__Group__0 ) )
            // InternalMyDsl.g:393:3: ( rule__PositiveLiteral__Group__0 )
            {
             before(grammarAccess.getPositiveLiteralAccess().getGroup()); 
            // InternalMyDsl.g:394:3: ( rule__PositiveLiteral__Group__0 )
            // InternalMyDsl.g:394:4: rule__PositiveLiteral__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__PositiveLiteral__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPositiveLiteralAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePositiveLiteral"


    // $ANTLR start "entryRuleLiteral"
    // InternalMyDsl.g:403:1: entryRuleLiteral : ruleLiteral EOF ;
    public final void entryRuleLiteral() throws RecognitionException {
        try {
            // InternalMyDsl.g:404:1: ( ruleLiteral EOF )
            // InternalMyDsl.g:405:1: ruleLiteral EOF
            {
             before(grammarAccess.getLiteralRule()); 
            pushFollow(FOLLOW_1);
            ruleLiteral();

            state._fsp--;

             after(grammarAccess.getLiteralRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLiteral"


    // $ANTLR start "ruleLiteral"
    // InternalMyDsl.g:412:1: ruleLiteral : ( ( rule__Literal__Alternatives ) ) ;
    public final void ruleLiteral() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:416:2: ( ( ( rule__Literal__Alternatives ) ) )
            // InternalMyDsl.g:417:2: ( ( rule__Literal__Alternatives ) )
            {
            // InternalMyDsl.g:417:2: ( ( rule__Literal__Alternatives ) )
            // InternalMyDsl.g:418:3: ( rule__Literal__Alternatives )
            {
             before(grammarAccess.getLiteralAccess().getAlternatives()); 
            // InternalMyDsl.g:419:3: ( rule__Literal__Alternatives )
            // InternalMyDsl.g:419:4: rule__Literal__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Literal__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getLiteralAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLiteral"


    // $ANTLR start "entryRulelistOfLiterals"
    // InternalMyDsl.g:428:1: entryRulelistOfLiterals : rulelistOfLiterals EOF ;
    public final void entryRulelistOfLiterals() throws RecognitionException {
        try {
            // InternalMyDsl.g:429:1: ( rulelistOfLiterals EOF )
            // InternalMyDsl.g:430:1: rulelistOfLiterals EOF
            {
             before(grammarAccess.getListOfLiteralsRule()); 
            pushFollow(FOLLOW_1);
            rulelistOfLiterals();

            state._fsp--;

             after(grammarAccess.getListOfLiteralsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulelistOfLiterals"


    // $ANTLR start "rulelistOfLiterals"
    // InternalMyDsl.g:437:1: rulelistOfLiterals : ( ( rule__ListOfLiterals__Group__0 ) ) ;
    public final void rulelistOfLiterals() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:441:2: ( ( ( rule__ListOfLiterals__Group__0 ) ) )
            // InternalMyDsl.g:442:2: ( ( rule__ListOfLiterals__Group__0 ) )
            {
            // InternalMyDsl.g:442:2: ( ( rule__ListOfLiterals__Group__0 ) )
            // InternalMyDsl.g:443:3: ( rule__ListOfLiterals__Group__0 )
            {
             before(grammarAccess.getListOfLiteralsAccess().getGroup()); 
            // InternalMyDsl.g:444:3: ( rule__ListOfLiterals__Group__0 )
            // InternalMyDsl.g:444:4: rule__ListOfLiterals__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ListOfLiterals__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getListOfLiteralsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulelistOfLiterals"


    // $ANTLR start "entryRulelistOfPositiveLiterals"
    // InternalMyDsl.g:453:1: entryRulelistOfPositiveLiterals : rulelistOfPositiveLiterals EOF ;
    public final void entryRulelistOfPositiveLiterals() throws RecognitionException {
        try {
            // InternalMyDsl.g:454:1: ( rulelistOfPositiveLiterals EOF )
            // InternalMyDsl.g:455:1: rulelistOfPositiveLiterals EOF
            {
             before(grammarAccess.getListOfPositiveLiteralsRule()); 
            pushFollow(FOLLOW_1);
            rulelistOfPositiveLiterals();

            state._fsp--;

             after(grammarAccess.getListOfPositiveLiteralsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulelistOfPositiveLiterals"


    // $ANTLR start "rulelistOfPositiveLiterals"
    // InternalMyDsl.g:462:1: rulelistOfPositiveLiterals : ( ( rule__ListOfPositiveLiterals__Group__0 ) ) ;
    public final void rulelistOfPositiveLiterals() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:466:2: ( ( ( rule__ListOfPositiveLiterals__Group__0 ) ) )
            // InternalMyDsl.g:467:2: ( ( rule__ListOfPositiveLiterals__Group__0 ) )
            {
            // InternalMyDsl.g:467:2: ( ( rule__ListOfPositiveLiterals__Group__0 ) )
            // InternalMyDsl.g:468:3: ( rule__ListOfPositiveLiterals__Group__0 )
            {
             before(grammarAccess.getListOfPositiveLiteralsAccess().getGroup()); 
            // InternalMyDsl.g:469:3: ( rule__ListOfPositiveLiterals__Group__0 )
            // InternalMyDsl.g:469:4: rule__ListOfPositiveLiterals__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ListOfPositiveLiterals__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getListOfPositiveLiteralsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulelistOfPositiveLiterals"


    // $ANTLR start "entryRuleRule"
    // InternalMyDsl.g:478:1: entryRuleRule : ruleRule EOF ;
    public final void entryRuleRule() throws RecognitionException {
        try {
            // InternalMyDsl.g:479:1: ( ruleRule EOF )
            // InternalMyDsl.g:480:1: ruleRule EOF
            {
             before(grammarAccess.getRuleRule()); 
            pushFollow(FOLLOW_1);
            ruleRule();

            state._fsp--;

             after(grammarAccess.getRuleRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRule"


    // $ANTLR start "ruleRule"
    // InternalMyDsl.g:487:1: ruleRule : ( ( rule__Rule__Group__0 ) ) ;
    public final void ruleRule() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:491:2: ( ( ( rule__Rule__Group__0 ) ) )
            // InternalMyDsl.g:492:2: ( ( rule__Rule__Group__0 ) )
            {
            // InternalMyDsl.g:492:2: ( ( rule__Rule__Group__0 ) )
            // InternalMyDsl.g:493:3: ( rule__Rule__Group__0 )
            {
             before(grammarAccess.getRuleAccess().getGroup()); 
            // InternalMyDsl.g:494:3: ( rule__Rule__Group__0 )
            // InternalMyDsl.g:494:4: rule__Rule__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Rule__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRuleAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRule"


    // $ANTLR start "entryRuleStatement"
    // InternalMyDsl.g:503:1: entryRuleStatement : ruleStatement EOF ;
    public final void entryRuleStatement() throws RecognitionException {
        try {
            // InternalMyDsl.g:504:1: ( ruleStatement EOF )
            // InternalMyDsl.g:505:1: ruleStatement EOF
            {
             before(grammarAccess.getStatementRule()); 
            pushFollow(FOLLOW_1);
            ruleStatement();

            state._fsp--;

             after(grammarAccess.getStatementRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStatement"


    // $ANTLR start "ruleStatement"
    // InternalMyDsl.g:512:1: ruleStatement : ( ( rule__Statement__Alternatives ) ) ;
    public final void ruleStatement() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:516:2: ( ( ( rule__Statement__Alternatives ) ) )
            // InternalMyDsl.g:517:2: ( ( rule__Statement__Alternatives ) )
            {
            // InternalMyDsl.g:517:2: ( ( rule__Statement__Alternatives ) )
            // InternalMyDsl.g:518:3: ( rule__Statement__Alternatives )
            {
             before(grammarAccess.getStatementAccess().getAlternatives()); 
            // InternalMyDsl.g:519:3: ( rule__Statement__Alternatives )
            // InternalMyDsl.g:519:4: rule__Statement__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Statement__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getStatementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStatement"


    // $ANTLR start "entryRuleDataSource"
    // InternalMyDsl.g:528:1: entryRuleDataSource : ruleDataSource EOF ;
    public final void entryRuleDataSource() throws RecognitionException {
        try {
            // InternalMyDsl.g:529:1: ( ruleDataSource EOF )
            // InternalMyDsl.g:530:1: ruleDataSource EOF
            {
             before(grammarAccess.getDataSourceRule()); 
            pushFollow(FOLLOW_1);
            ruleDataSource();

            state._fsp--;

             after(grammarAccess.getDataSourceRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataSource"


    // $ANTLR start "ruleDataSource"
    // InternalMyDsl.g:537:1: ruleDataSource : ( ( rule__DataSource__Alternatives ) ) ;
    public final void ruleDataSource() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:541:2: ( ( ( rule__DataSource__Alternatives ) ) )
            // InternalMyDsl.g:542:2: ( ( rule__DataSource__Alternatives ) )
            {
            // InternalMyDsl.g:542:2: ( ( rule__DataSource__Alternatives ) )
            // InternalMyDsl.g:543:3: ( rule__DataSource__Alternatives )
            {
             before(grammarAccess.getDataSourceAccess().getAlternatives()); 
            // InternalMyDsl.g:544:3: ( rule__DataSource__Alternatives )
            // InternalMyDsl.g:544:4: rule__DataSource__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DataSource__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDataSourceAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataSource"


    // $ANTLR start "entryRuleSource"
    // InternalMyDsl.g:553:1: entryRuleSource : ruleSource EOF ;
    public final void entryRuleSource() throws RecognitionException {
        try {
            // InternalMyDsl.g:554:1: ( ruleSource EOF )
            // InternalMyDsl.g:555:1: ruleSource EOF
            {
             before(grammarAccess.getSourceRule()); 
            pushFollow(FOLLOW_1);
            ruleSource();

            state._fsp--;

             after(grammarAccess.getSourceRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSource"


    // $ANTLR start "ruleSource"
    // InternalMyDsl.g:562:1: ruleSource : ( ( rule__Source__Alternatives ) ) ;
    public final void ruleSource() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:566:2: ( ( ( rule__Source__Alternatives ) ) )
            // InternalMyDsl.g:567:2: ( ( rule__Source__Alternatives ) )
            {
            // InternalMyDsl.g:567:2: ( ( rule__Source__Alternatives ) )
            // InternalMyDsl.g:568:3: ( rule__Source__Alternatives )
            {
             before(grammarAccess.getSourceAccess().getAlternatives()); 
            // InternalMyDsl.g:569:3: ( rule__Source__Alternatives )
            // InternalMyDsl.g:569:4: rule__Source__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Source__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSourceAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSource"


    // $ANTLR start "entryRulePrefix"
    // InternalMyDsl.g:578:1: entryRulePrefix : rulePrefix EOF ;
    public final void entryRulePrefix() throws RecognitionException {
        try {
            // InternalMyDsl.g:579:1: ( rulePrefix EOF )
            // InternalMyDsl.g:580:1: rulePrefix EOF
            {
             before(grammarAccess.getPrefixRule()); 
            pushFollow(FOLLOW_1);
            rulePrefix();

            state._fsp--;

             after(grammarAccess.getPrefixRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrefix"


    // $ANTLR start "rulePrefix"
    // InternalMyDsl.g:587:1: rulePrefix : ( ( rule__Prefix__Alternatives ) ) ;
    public final void rulePrefix() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:591:2: ( ( ( rule__Prefix__Alternatives ) ) )
            // InternalMyDsl.g:592:2: ( ( rule__Prefix__Alternatives ) )
            {
            // InternalMyDsl.g:592:2: ( ( rule__Prefix__Alternatives ) )
            // InternalMyDsl.g:593:3: ( rule__Prefix__Alternatives )
            {
             before(grammarAccess.getPrefixAccess().getAlternatives()); 
            // InternalMyDsl.g:594:3: ( rule__Prefix__Alternatives )
            // InternalMyDsl.g:594:4: rule__Prefix__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getPrefixAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrefix"


    // $ANTLR start "entryRuleBase"
    // InternalMyDsl.g:603:1: entryRuleBase : ruleBase EOF ;
    public final void entryRuleBase() throws RecognitionException {
        try {
            // InternalMyDsl.g:604:1: ( ruleBase EOF )
            // InternalMyDsl.g:605:1: ruleBase EOF
            {
             before(grammarAccess.getBaseRule()); 
            pushFollow(FOLLOW_1);
            ruleBase();

            state._fsp--;

             after(grammarAccess.getBaseRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleBase"


    // $ANTLR start "ruleBase"
    // InternalMyDsl.g:612:1: ruleBase : ( ( rule__Base__Alternatives ) ) ;
    public final void ruleBase() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:616:2: ( ( ( rule__Base__Alternatives ) ) )
            // InternalMyDsl.g:617:2: ( ( rule__Base__Alternatives ) )
            {
            // InternalMyDsl.g:617:2: ( ( rule__Base__Alternatives ) )
            // InternalMyDsl.g:618:3: ( rule__Base__Alternatives )
            {
             before(grammarAccess.getBaseAccess().getAlternatives()); 
            // InternalMyDsl.g:619:3: ( rule__Base__Alternatives )
            // InternalMyDsl.g:619:4: rule__Base__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Base__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getBaseAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleBase"


    // $ANTLR start "rule__IRIBOL__Alternatives"
    // InternalMyDsl.g:627:1: rule__IRIBOL__Alternatives : ( ( ( rule__IRIBOL__TAssignment_0 ) ) | ( ( rule__IRIBOL__TAssignment_1 ) ) );
    public final void rule__IRIBOL__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:631:1: ( ( ( rule__IRIBOL__TAssignment_0 ) ) | ( ( rule__IRIBOL__TAssignment_1 ) ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_IRI) ) {
                alt1=1;
            }
            else if ( (LA1_0==RULE_PNAME_LN) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyDsl.g:632:2: ( ( rule__IRIBOL__TAssignment_0 ) )
                    {
                    // InternalMyDsl.g:632:2: ( ( rule__IRIBOL__TAssignment_0 ) )
                    // InternalMyDsl.g:633:3: ( rule__IRIBOL__TAssignment_0 )
                    {
                     before(grammarAccess.getIRIBOLAccess().getTAssignment_0()); 
                    // InternalMyDsl.g:634:3: ( rule__IRIBOL__TAssignment_0 )
                    // InternalMyDsl.g:634:4: rule__IRIBOL__TAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__IRIBOL__TAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getIRIBOLAccess().getTAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:638:2: ( ( rule__IRIBOL__TAssignment_1 ) )
                    {
                    // InternalMyDsl.g:638:2: ( ( rule__IRIBOL__TAssignment_1 ) )
                    // InternalMyDsl.g:639:3: ( rule__IRIBOL__TAssignment_1 )
                    {
                     before(grammarAccess.getIRIBOLAccess().getTAssignment_1()); 
                    // InternalMyDsl.g:640:3: ( rule__IRIBOL__TAssignment_1 )
                    // InternalMyDsl.g:640:4: rule__IRIBOL__TAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__IRIBOL__TAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getIRIBOLAccess().getTAssignment_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IRIBOL__Alternatives"


    // $ANTLR start "rule__Striing__Alternatives"
    // InternalMyDsl.g:648:1: rule__Striing__Alternatives : ( ( ( rule__Striing__TAssignment_0 ) ) | ( ( rule__Striing__TAssignment_1 ) ) | ( ( rule__Striing__TAssignment_2 ) ) | ( ( rule__Striing__TAssignment_3 ) ) );
    public final void rule__Striing__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:652:1: ( ( ( rule__Striing__TAssignment_0 ) ) | ( ( rule__Striing__TAssignment_1 ) ) | ( ( rule__Striing__TAssignment_2 ) ) | ( ( rule__Striing__TAssignment_3 ) ) )
            int alt2=4;
            switch ( input.LA(1) ) {
            case RULE_STRING_LITERAL1:
                {
                alt2=1;
                }
                break;
            case RULE_STRING_LITERAL2:
                {
                alt2=2;
                }
                break;
            case RULE_STRING_LITERAL_LONG1:
                {
                alt2=3;
                }
                break;
            case RULE_STRING_LITERAL_LONG2:
                {
                alt2=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:653:2: ( ( rule__Striing__TAssignment_0 ) )
                    {
                    // InternalMyDsl.g:653:2: ( ( rule__Striing__TAssignment_0 ) )
                    // InternalMyDsl.g:654:3: ( rule__Striing__TAssignment_0 )
                    {
                     before(grammarAccess.getStriingAccess().getTAssignment_0()); 
                    // InternalMyDsl.g:655:3: ( rule__Striing__TAssignment_0 )
                    // InternalMyDsl.g:655:4: rule__Striing__TAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Striing__TAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getStriingAccess().getTAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:659:2: ( ( rule__Striing__TAssignment_1 ) )
                    {
                    // InternalMyDsl.g:659:2: ( ( rule__Striing__TAssignment_1 ) )
                    // InternalMyDsl.g:660:3: ( rule__Striing__TAssignment_1 )
                    {
                     before(grammarAccess.getStriingAccess().getTAssignment_1()); 
                    // InternalMyDsl.g:661:3: ( rule__Striing__TAssignment_1 )
                    // InternalMyDsl.g:661:4: rule__Striing__TAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Striing__TAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getStriingAccess().getTAssignment_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:665:2: ( ( rule__Striing__TAssignment_2 ) )
                    {
                    // InternalMyDsl.g:665:2: ( ( rule__Striing__TAssignment_2 ) )
                    // InternalMyDsl.g:666:3: ( rule__Striing__TAssignment_2 )
                    {
                     before(grammarAccess.getStriingAccess().getTAssignment_2()); 
                    // InternalMyDsl.g:667:3: ( rule__Striing__TAssignment_2 )
                    // InternalMyDsl.g:667:4: rule__Striing__TAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__Striing__TAssignment_2();

                    state._fsp--;


                    }

                     after(grammarAccess.getStriingAccess().getTAssignment_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:671:2: ( ( rule__Striing__TAssignment_3 ) )
                    {
                    // InternalMyDsl.g:671:2: ( ( rule__Striing__TAssignment_3 ) )
                    // InternalMyDsl.g:672:3: ( rule__Striing__TAssignment_3 )
                    {
                     before(grammarAccess.getStriingAccess().getTAssignment_3()); 
                    // InternalMyDsl.g:673:3: ( rule__Striing__TAssignment_3 )
                    // InternalMyDsl.g:673:4: rule__Striing__TAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__Striing__TAssignment_3();

                    state._fsp--;


                    }

                     after(grammarAccess.getStriingAccess().getTAssignment_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Striing__Alternatives"


    // $ANTLR start "rule__RDFLiteral__Alternatives_1"
    // InternalMyDsl.g:681:1: rule__RDFLiteral__Alternatives_1 : ( ( ( rule__RDFLiteral__LAssignment_1_0 ) ) | ( ( rule__RDFLiteral__Group_1_1__0 ) ) );
    public final void rule__RDFLiteral__Alternatives_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:685:1: ( ( ( rule__RDFLiteral__LAssignment_1_0 ) ) | ( ( rule__RDFLiteral__Group_1_1__0 ) ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==RULE_LANGTAG) ) {
                alt3=1;
            }
            else if ( (LA3_0==RULE_DATATYPE) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalMyDsl.g:686:2: ( ( rule__RDFLiteral__LAssignment_1_0 ) )
                    {
                    // InternalMyDsl.g:686:2: ( ( rule__RDFLiteral__LAssignment_1_0 ) )
                    // InternalMyDsl.g:687:3: ( rule__RDFLiteral__LAssignment_1_0 )
                    {
                     before(grammarAccess.getRDFLiteralAccess().getLAssignment_1_0()); 
                    // InternalMyDsl.g:688:3: ( rule__RDFLiteral__LAssignment_1_0 )
                    // InternalMyDsl.g:688:4: rule__RDFLiteral__LAssignment_1_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__RDFLiteral__LAssignment_1_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getRDFLiteralAccess().getLAssignment_1_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:692:2: ( ( rule__RDFLiteral__Group_1_1__0 ) )
                    {
                    // InternalMyDsl.g:692:2: ( ( rule__RDFLiteral__Group_1_1__0 ) )
                    // InternalMyDsl.g:693:3: ( rule__RDFLiteral__Group_1_1__0 )
                    {
                     before(grammarAccess.getRDFLiteralAccess().getGroup_1_1()); 
                    // InternalMyDsl.g:694:3: ( rule__RDFLiteral__Group_1_1__0 )
                    // InternalMyDsl.g:694:4: rule__RDFLiteral__Group_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__RDFLiteral__Group_1_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getRDFLiteralAccess().getGroup_1_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__Alternatives_1"


    // $ANTLR start "rule__NumericLiteral__Alternatives"
    // InternalMyDsl.g:702:1: rule__NumericLiteral__Alternatives : ( ( ( rule__NumericLiteral__TAssignment_0 ) ) | ( ( rule__NumericLiteral__TAssignment_1 ) ) | ( ( rule__NumericLiteral__TAssignment_2 ) ) );
    public final void rule__NumericLiteral__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:706:1: ( ( ( rule__NumericLiteral__TAssignment_0 ) ) | ( ( rule__NumericLiteral__TAssignment_1 ) ) | ( ( rule__NumericLiteral__TAssignment_2 ) ) )
            int alt4=3;
            switch ( input.LA(1) ) {
            case RULE_INTEGER:
                {
                alt4=1;
                }
                break;
            case RULE_DECIMAL:
                {
                alt4=2;
                }
                break;
            case RULE_DOUBLE:
                {
                alt4=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalMyDsl.g:707:2: ( ( rule__NumericLiteral__TAssignment_0 ) )
                    {
                    // InternalMyDsl.g:707:2: ( ( rule__NumericLiteral__TAssignment_0 ) )
                    // InternalMyDsl.g:708:3: ( rule__NumericLiteral__TAssignment_0 )
                    {
                     before(grammarAccess.getNumericLiteralAccess().getTAssignment_0()); 
                    // InternalMyDsl.g:709:3: ( rule__NumericLiteral__TAssignment_0 )
                    // InternalMyDsl.g:709:4: rule__NumericLiteral__TAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__NumericLiteral__TAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getNumericLiteralAccess().getTAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:713:2: ( ( rule__NumericLiteral__TAssignment_1 ) )
                    {
                    // InternalMyDsl.g:713:2: ( ( rule__NumericLiteral__TAssignment_1 ) )
                    // InternalMyDsl.g:714:3: ( rule__NumericLiteral__TAssignment_1 )
                    {
                     before(grammarAccess.getNumericLiteralAccess().getTAssignment_1()); 
                    // InternalMyDsl.g:715:3: ( rule__NumericLiteral__TAssignment_1 )
                    // InternalMyDsl.g:715:4: rule__NumericLiteral__TAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__NumericLiteral__TAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getNumericLiteralAccess().getTAssignment_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:719:2: ( ( rule__NumericLiteral__TAssignment_2 ) )
                    {
                    // InternalMyDsl.g:719:2: ( ( rule__NumericLiteral__TAssignment_2 ) )
                    // InternalMyDsl.g:720:3: ( rule__NumericLiteral__TAssignment_2 )
                    {
                     before(grammarAccess.getNumericLiteralAccess().getTAssignment_2()); 
                    // InternalMyDsl.g:721:3: ( rule__NumericLiteral__TAssignment_2 )
                    // InternalMyDsl.g:721:4: rule__NumericLiteral__TAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__NumericLiteral__TAssignment_2();

                    state._fsp--;


                    }

                     after(grammarAccess.getNumericLiteralAccess().getTAssignment_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NumericLiteral__Alternatives"


    // $ANTLR start "rule__Term__Alternatives"
    // InternalMyDsl.g:729:1: rule__Term__Alternatives : ( ( ( rule__Term__SAssignment_0 ) ) | ( ( rule__Term__CAssignment_1 ) ) | ( ( rule__Term__SAssignment_2 ) ) | ( ( rule__Term__TAssignment_3 ) ) | ( ( rule__Term__TAssignment_4 ) ) | ( ( rule__Term__TAssignment_5 ) ) );
    public final void rule__Term__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:733:1: ( ( ( rule__Term__SAssignment_0 ) ) | ( ( rule__Term__CAssignment_1 ) ) | ( ( rule__Term__SAssignment_2 ) ) | ( ( rule__Term__TAssignment_3 ) ) | ( ( rule__Term__TAssignment_4 ) ) | ( ( rule__Term__TAssignment_5 ) ) )
            int alt5=6;
            switch ( input.LA(1) ) {
            case RULE_PNAME_LN:
            case RULE_IRI:
                {
                alt5=1;
                }
                break;
            case RULE_INTEGER:
            case RULE_DECIMAL:
            case RULE_DOUBLE:
                {
                alt5=2;
                }
                break;
            case RULE_STRING_LITERAL1:
            case RULE_STRING_LITERAL2:
            case RULE_STRING_LITERAL_LONG1:
            case RULE_STRING_LITERAL_LONG2:
                {
                alt5=3;
                }
                break;
            case RULE_UNIVAR:
                {
                alt5=4;
                }
                break;
            case RULE_EXIVAR:
                {
                alt5=5;
                }
                break;
            case RULE_VARORPREDNAME:
                {
                alt5=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalMyDsl.g:734:2: ( ( rule__Term__SAssignment_0 ) )
                    {
                    // InternalMyDsl.g:734:2: ( ( rule__Term__SAssignment_0 ) )
                    // InternalMyDsl.g:735:3: ( rule__Term__SAssignment_0 )
                    {
                     before(grammarAccess.getTermAccess().getSAssignment_0()); 
                    // InternalMyDsl.g:736:3: ( rule__Term__SAssignment_0 )
                    // InternalMyDsl.g:736:4: rule__Term__SAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Term__SAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getTermAccess().getSAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:740:2: ( ( rule__Term__CAssignment_1 ) )
                    {
                    // InternalMyDsl.g:740:2: ( ( rule__Term__CAssignment_1 ) )
                    // InternalMyDsl.g:741:3: ( rule__Term__CAssignment_1 )
                    {
                     before(grammarAccess.getTermAccess().getCAssignment_1()); 
                    // InternalMyDsl.g:742:3: ( rule__Term__CAssignment_1 )
                    // InternalMyDsl.g:742:4: rule__Term__CAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Term__CAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getTermAccess().getCAssignment_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:746:2: ( ( rule__Term__SAssignment_2 ) )
                    {
                    // InternalMyDsl.g:746:2: ( ( rule__Term__SAssignment_2 ) )
                    // InternalMyDsl.g:747:3: ( rule__Term__SAssignment_2 )
                    {
                     before(grammarAccess.getTermAccess().getSAssignment_2()); 
                    // InternalMyDsl.g:748:3: ( rule__Term__SAssignment_2 )
                    // InternalMyDsl.g:748:4: rule__Term__SAssignment_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__Term__SAssignment_2();

                    state._fsp--;


                    }

                     after(grammarAccess.getTermAccess().getSAssignment_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:752:2: ( ( rule__Term__TAssignment_3 ) )
                    {
                    // InternalMyDsl.g:752:2: ( ( rule__Term__TAssignment_3 ) )
                    // InternalMyDsl.g:753:3: ( rule__Term__TAssignment_3 )
                    {
                     before(grammarAccess.getTermAccess().getTAssignment_3()); 
                    // InternalMyDsl.g:754:3: ( rule__Term__TAssignment_3 )
                    // InternalMyDsl.g:754:4: rule__Term__TAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__Term__TAssignment_3();

                    state._fsp--;


                    }

                     after(grammarAccess.getTermAccess().getTAssignment_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalMyDsl.g:758:2: ( ( rule__Term__TAssignment_4 ) )
                    {
                    // InternalMyDsl.g:758:2: ( ( rule__Term__TAssignment_4 ) )
                    // InternalMyDsl.g:759:3: ( rule__Term__TAssignment_4 )
                    {
                     before(grammarAccess.getTermAccess().getTAssignment_4()); 
                    // InternalMyDsl.g:760:3: ( rule__Term__TAssignment_4 )
                    // InternalMyDsl.g:760:4: rule__Term__TAssignment_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__Term__TAssignment_4();

                    state._fsp--;


                    }

                     after(grammarAccess.getTermAccess().getTAssignment_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalMyDsl.g:764:2: ( ( rule__Term__TAssignment_5 ) )
                    {
                    // InternalMyDsl.g:764:2: ( ( rule__Term__TAssignment_5 ) )
                    // InternalMyDsl.g:765:3: ( rule__Term__TAssignment_5 )
                    {
                     before(grammarAccess.getTermAccess().getTAssignment_5()); 
                    // InternalMyDsl.g:766:3: ( rule__Term__TAssignment_5 )
                    // InternalMyDsl.g:766:4: rule__Term__TAssignment_5
                    {
                    pushFollow(FOLLOW_2);
                    rule__Term__TAssignment_5();

                    state._fsp--;


                    }

                     after(grammarAccess.getTermAccess().getTAssignment_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Term__Alternatives"


    // $ANTLR start "rule__PredicateName__Alternatives"
    // InternalMyDsl.g:774:1: rule__PredicateName__Alternatives : ( ( ( rule__PredicateName__SAssignment_0 ) ) | ( ( rule__PredicateName__TAssignment_1 ) ) );
    public final void rule__PredicateName__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:778:1: ( ( ( rule__PredicateName__SAssignment_0 ) ) | ( ( rule__PredicateName__TAssignment_1 ) ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( ((LA6_0>=RULE_PNAME_LN && LA6_0<=RULE_IRI)) ) {
                alt6=1;
            }
            else if ( (LA6_0==RULE_VARORPREDNAME) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:779:2: ( ( rule__PredicateName__SAssignment_0 ) )
                    {
                    // InternalMyDsl.g:779:2: ( ( rule__PredicateName__SAssignment_0 ) )
                    // InternalMyDsl.g:780:3: ( rule__PredicateName__SAssignment_0 )
                    {
                     before(grammarAccess.getPredicateNameAccess().getSAssignment_0()); 
                    // InternalMyDsl.g:781:3: ( rule__PredicateName__SAssignment_0 )
                    // InternalMyDsl.g:781:4: rule__PredicateName__SAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__PredicateName__SAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPredicateNameAccess().getSAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:785:2: ( ( rule__PredicateName__TAssignment_1 ) )
                    {
                    // InternalMyDsl.g:785:2: ( ( rule__PredicateName__TAssignment_1 ) )
                    // InternalMyDsl.g:786:3: ( rule__PredicateName__TAssignment_1 )
                    {
                     before(grammarAccess.getPredicateNameAccess().getTAssignment_1()); 
                    // InternalMyDsl.g:787:3: ( rule__PredicateName__TAssignment_1 )
                    // InternalMyDsl.g:787:4: rule__PredicateName__TAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__PredicateName__TAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getPredicateNameAccess().getTAssignment_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PredicateName__Alternatives"


    // $ANTLR start "rule__Literal__Alternatives"
    // InternalMyDsl.g:795:1: rule__Literal__Alternatives : ( ( ( rule__Literal__LAssignment_0 ) ) | ( ( rule__Literal__LAssignment_1 ) ) );
    public final void rule__Literal__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:799:1: ( ( ( rule__Literal__LAssignment_0 ) ) | ( ( rule__Literal__LAssignment_1 ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( ((LA7_0>=RULE_PNAME_LN && LA7_0<=RULE_IRI)||LA7_0==RULE_VARORPREDNAME) ) {
                alt7=1;
            }
            else if ( (LA7_0==RULE_TILDE) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyDsl.g:800:2: ( ( rule__Literal__LAssignment_0 ) )
                    {
                    // InternalMyDsl.g:800:2: ( ( rule__Literal__LAssignment_0 ) )
                    // InternalMyDsl.g:801:3: ( rule__Literal__LAssignment_0 )
                    {
                     before(grammarAccess.getLiteralAccess().getLAssignment_0()); 
                    // InternalMyDsl.g:802:3: ( rule__Literal__LAssignment_0 )
                    // InternalMyDsl.g:802:4: rule__Literal__LAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Literal__LAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getLiteralAccess().getLAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:806:2: ( ( rule__Literal__LAssignment_1 ) )
                    {
                    // InternalMyDsl.g:806:2: ( ( rule__Literal__LAssignment_1 ) )
                    // InternalMyDsl.g:807:3: ( rule__Literal__LAssignment_1 )
                    {
                     before(grammarAccess.getLiteralAccess().getLAssignment_1()); 
                    // InternalMyDsl.g:808:3: ( rule__Literal__LAssignment_1 )
                    // InternalMyDsl.g:808:4: rule__Literal__LAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Literal__LAssignment_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getLiteralAccess().getLAssignment_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Literal__Alternatives"


    // $ANTLR start "rule__Statement__Alternatives"
    // InternalMyDsl.g:816:1: rule__Statement__Alternatives : ( ( ( rule__Statement__StatementAssignment_0 ) ) | ( ( rule__Statement__Group_1__0 ) ) | ( ( rule__Statement__Group_2__0 ) ) | ( ( rule__Statement__Group_3__0 ) ) );
    public final void rule__Statement__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:820:1: ( ( ( rule__Statement__StatementAssignment_0 ) ) | ( ( rule__Statement__Group_1__0 ) ) | ( ( rule__Statement__Group_2__0 ) ) | ( ( rule__Statement__Group_3__0 ) ) )
            int alt8=4;
            alt8 = dfa8.predict(input);
            switch (alt8) {
                case 1 :
                    // InternalMyDsl.g:821:2: ( ( rule__Statement__StatementAssignment_0 ) )
                    {
                    // InternalMyDsl.g:821:2: ( ( rule__Statement__StatementAssignment_0 ) )
                    // InternalMyDsl.g:822:3: ( rule__Statement__StatementAssignment_0 )
                    {
                     before(grammarAccess.getStatementAccess().getStatementAssignment_0()); 
                    // InternalMyDsl.g:823:3: ( rule__Statement__StatementAssignment_0 )
                    // InternalMyDsl.g:823:4: rule__Statement__StatementAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Statement__StatementAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getStatementAccess().getStatementAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:827:2: ( ( rule__Statement__Group_1__0 ) )
                    {
                    // InternalMyDsl.g:827:2: ( ( rule__Statement__Group_1__0 ) )
                    // InternalMyDsl.g:828:3: ( rule__Statement__Group_1__0 )
                    {
                     before(grammarAccess.getStatementAccess().getGroup_1()); 
                    // InternalMyDsl.g:829:3: ( rule__Statement__Group_1__0 )
                    // InternalMyDsl.g:829:4: rule__Statement__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Statement__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getStatementAccess().getGroup_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:833:2: ( ( rule__Statement__Group_2__0 ) )
                    {
                    // InternalMyDsl.g:833:2: ( ( rule__Statement__Group_2__0 ) )
                    // InternalMyDsl.g:834:3: ( rule__Statement__Group_2__0 )
                    {
                     before(grammarAccess.getStatementAccess().getGroup_2()); 
                    // InternalMyDsl.g:835:3: ( rule__Statement__Group_2__0 )
                    // InternalMyDsl.g:835:4: rule__Statement__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Statement__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getStatementAccess().getGroup_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:839:2: ( ( rule__Statement__Group_3__0 ) )
                    {
                    // InternalMyDsl.g:839:2: ( ( rule__Statement__Group_3__0 ) )
                    // InternalMyDsl.g:840:3: ( rule__Statement__Group_3__0 )
                    {
                     before(grammarAccess.getStatementAccess().getGroup_3()); 
                    // InternalMyDsl.g:841:3: ( rule__Statement__Group_3__0 )
                    // InternalMyDsl.g:841:4: rule__Statement__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Statement__Group_3__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getStatementAccess().getGroup_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Alternatives"


    // $ANTLR start "rule__DataSource__Alternatives"
    // InternalMyDsl.g:849:1: rule__DataSource__Alternatives : ( ( ( rule__DataSource__Group_0__0 ) ) | ( ( rule__DataSource__Group_1__0 ) ) | ( ( rule__DataSource__Group_2__0 ) ) );
    public final void rule__DataSource__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:853:1: ( ( ( rule__DataSource__Group_0__0 ) ) | ( ( rule__DataSource__Group_1__0 ) ) | ( ( rule__DataSource__Group_2__0 ) ) )
            int alt9=3;
            switch ( input.LA(1) ) {
            case RULE_LOADCSV:
                {
                alt9=1;
                }
                break;
            case RULE_LOADRDF:
                {
                alt9=2;
                }
                break;
            case RULE_SPARQL:
                {
                alt9=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:854:2: ( ( rule__DataSource__Group_0__0 ) )
                    {
                    // InternalMyDsl.g:854:2: ( ( rule__DataSource__Group_0__0 ) )
                    // InternalMyDsl.g:855:3: ( rule__DataSource__Group_0__0 )
                    {
                     before(grammarAccess.getDataSourceAccess().getGroup_0()); 
                    // InternalMyDsl.g:856:3: ( rule__DataSource__Group_0__0 )
                    // InternalMyDsl.g:856:4: rule__DataSource__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DataSource__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getDataSourceAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:860:2: ( ( rule__DataSource__Group_1__0 ) )
                    {
                    // InternalMyDsl.g:860:2: ( ( rule__DataSource__Group_1__0 ) )
                    // InternalMyDsl.g:861:3: ( rule__DataSource__Group_1__0 )
                    {
                     before(grammarAccess.getDataSourceAccess().getGroup_1()); 
                    // InternalMyDsl.g:862:3: ( rule__DataSource__Group_1__0 )
                    // InternalMyDsl.g:862:4: rule__DataSource__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DataSource__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getDataSourceAccess().getGroup_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:866:2: ( ( rule__DataSource__Group_2__0 ) )
                    {
                    // InternalMyDsl.g:866:2: ( ( rule__DataSource__Group_2__0 ) )
                    // InternalMyDsl.g:867:3: ( rule__DataSource__Group_2__0 )
                    {
                     before(grammarAccess.getDataSourceAccess().getGroup_2()); 
                    // InternalMyDsl.g:868:3: ( rule__DataSource__Group_2__0 )
                    // InternalMyDsl.g:868:4: rule__DataSource__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__DataSource__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getDataSourceAccess().getGroup_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Alternatives"


    // $ANTLR start "rule__Source__Alternatives"
    // InternalMyDsl.g:876:1: rule__Source__Alternatives : ( ( ( rule__Source__Group_0__0 ) ) | ( ( rule__Source__Group_1__0 ) ) );
    public final void rule__Source__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:880:1: ( ( ( rule__Source__Group_0__0 ) ) | ( ( rule__Source__Group_1__0 ) ) )
            int alt10=2;
            alt10 = dfa10.predict(input);
            switch (alt10) {
                case 1 :
                    // InternalMyDsl.g:881:2: ( ( rule__Source__Group_0__0 ) )
                    {
                    // InternalMyDsl.g:881:2: ( ( rule__Source__Group_0__0 ) )
                    // InternalMyDsl.g:882:3: ( rule__Source__Group_0__0 )
                    {
                     before(grammarAccess.getSourceAccess().getGroup_0()); 
                    // InternalMyDsl.g:883:3: ( rule__Source__Group_0__0 )
                    // InternalMyDsl.g:883:4: rule__Source__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Source__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSourceAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:887:2: ( ( rule__Source__Group_1__0 ) )
                    {
                    // InternalMyDsl.g:887:2: ( ( rule__Source__Group_1__0 ) )
                    // InternalMyDsl.g:888:3: ( rule__Source__Group_1__0 )
                    {
                     before(grammarAccess.getSourceAccess().getGroup_1()); 
                    // InternalMyDsl.g:889:3: ( rule__Source__Group_1__0 )
                    // InternalMyDsl.g:889:4: rule__Source__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Source__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSourceAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Alternatives"


    // $ANTLR start "rule__Prefix__Alternatives"
    // InternalMyDsl.g:897:1: rule__Prefix__Alternatives : ( ( ( rule__Prefix__Group_0__0 ) ) | ( ( rule__Prefix__Group_1__0 ) ) | ( ( rule__Prefix__Group_2__0 ) ) | ( ( rule__Prefix__Group_3__0 ) ) );
    public final void rule__Prefix__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:901:1: ( ( ( rule__Prefix__Group_0__0 ) ) | ( ( rule__Prefix__Group_1__0 ) ) | ( ( rule__Prefix__Group_2__0 ) ) | ( ( rule__Prefix__Group_3__0 ) ) )
            int alt11=4;
            alt11 = dfa11.predict(input);
            switch (alt11) {
                case 1 :
                    // InternalMyDsl.g:902:2: ( ( rule__Prefix__Group_0__0 ) )
                    {
                    // InternalMyDsl.g:902:2: ( ( rule__Prefix__Group_0__0 ) )
                    // InternalMyDsl.g:903:3: ( rule__Prefix__Group_0__0 )
                    {
                     before(grammarAccess.getPrefixAccess().getGroup_0()); 
                    // InternalMyDsl.g:904:3: ( rule__Prefix__Group_0__0 )
                    // InternalMyDsl.g:904:4: rule__Prefix__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Prefix__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPrefixAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:908:2: ( ( rule__Prefix__Group_1__0 ) )
                    {
                    // InternalMyDsl.g:908:2: ( ( rule__Prefix__Group_1__0 ) )
                    // InternalMyDsl.g:909:3: ( rule__Prefix__Group_1__0 )
                    {
                     before(grammarAccess.getPrefixAccess().getGroup_1()); 
                    // InternalMyDsl.g:910:3: ( rule__Prefix__Group_1__0 )
                    // InternalMyDsl.g:910:4: rule__Prefix__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Prefix__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPrefixAccess().getGroup_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:914:2: ( ( rule__Prefix__Group_2__0 ) )
                    {
                    // InternalMyDsl.g:914:2: ( ( rule__Prefix__Group_2__0 ) )
                    // InternalMyDsl.g:915:3: ( rule__Prefix__Group_2__0 )
                    {
                     before(grammarAccess.getPrefixAccess().getGroup_2()); 
                    // InternalMyDsl.g:916:3: ( rule__Prefix__Group_2__0 )
                    // InternalMyDsl.g:916:4: rule__Prefix__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Prefix__Group_2__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPrefixAccess().getGroup_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:920:2: ( ( rule__Prefix__Group_3__0 ) )
                    {
                    // InternalMyDsl.g:920:2: ( ( rule__Prefix__Group_3__0 ) )
                    // InternalMyDsl.g:921:3: ( rule__Prefix__Group_3__0 )
                    {
                     before(grammarAccess.getPrefixAccess().getGroup_3()); 
                    // InternalMyDsl.g:922:3: ( rule__Prefix__Group_3__0 )
                    // InternalMyDsl.g:922:4: rule__Prefix__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Prefix__Group_3__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPrefixAccess().getGroup_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Alternatives"


    // $ANTLR start "rule__Base__Alternatives"
    // InternalMyDsl.g:930:1: rule__Base__Alternatives : ( ( ( rule__Base__Group_0__0 ) ) | ( ( rule__Base__Group_1__0 ) ) );
    public final void rule__Base__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:934:1: ( ( ( rule__Base__Group_0__0 ) ) | ( ( rule__Base__Group_1__0 ) ) )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==RULE_BS) ) {
                int LA12_1 = input.LA(2);

                if ( (LA12_1==RULE_IRI) ) {
                    int LA12_2 = input.LA(3);

                    if ( (LA12_2==RULE_DOT) ) {
                        int LA12_3 = input.LA(4);

                        if ( (LA12_3==EOF||LA12_3==RULE_SRC||LA12_3==RULE_PRFX||(LA12_3>=RULE_PNAME_LN && LA12_3<=RULE_IRI)||LA12_3==RULE_VARORPREDNAME) ) {
                            alt12=1;
                        }
                        else if ( (LA12_3==RULE_E) ) {
                            alt12=2;
                        }
                        else {
                            NoViableAltException nvae =
                                new NoViableAltException("", 12, 3, input);

                            throw nvae;
                        }
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 12, 2, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 12, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyDsl.g:935:2: ( ( rule__Base__Group_0__0 ) )
                    {
                    // InternalMyDsl.g:935:2: ( ( rule__Base__Group_0__0 ) )
                    // InternalMyDsl.g:936:3: ( rule__Base__Group_0__0 )
                    {
                     before(grammarAccess.getBaseAccess().getGroup_0()); 
                    // InternalMyDsl.g:937:3: ( rule__Base__Group_0__0 )
                    // InternalMyDsl.g:937:4: rule__Base__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Base__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getBaseAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:941:2: ( ( rule__Base__Group_1__0 ) )
                    {
                    // InternalMyDsl.g:941:2: ( ( rule__Base__Group_1__0 ) )
                    // InternalMyDsl.g:942:3: ( rule__Base__Group_1__0 )
                    {
                     before(grammarAccess.getBaseAccess().getGroup_1()); 
                    // InternalMyDsl.g:943:3: ( rule__Base__Group_1__0 )
                    // InternalMyDsl.g:943:4: rule__Base__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Base__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getBaseAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Alternatives"


    // $ANTLR start "rule__Model__Group__0"
    // InternalMyDsl.g:951:1: rule__Model__Group__0 : rule__Model__Group__0__Impl rule__Model__Group__1 ;
    public final void rule__Model__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:955:1: ( rule__Model__Group__0__Impl rule__Model__Group__1 )
            // InternalMyDsl.g:956:2: rule__Model__Group__0__Impl rule__Model__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Model__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0"


    // $ANTLR start "rule__Model__Group__0__Impl"
    // InternalMyDsl.g:963:1: rule__Model__Group__0__Impl : ( ( rule__Model__BAssignment_0 )? ) ;
    public final void rule__Model__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:967:1: ( ( ( rule__Model__BAssignment_0 )? ) )
            // InternalMyDsl.g:968:1: ( ( rule__Model__BAssignment_0 )? )
            {
            // InternalMyDsl.g:968:1: ( ( rule__Model__BAssignment_0 )? )
            // InternalMyDsl.g:969:2: ( rule__Model__BAssignment_0 )?
            {
             before(grammarAccess.getModelAccess().getBAssignment_0()); 
            // InternalMyDsl.g:970:2: ( rule__Model__BAssignment_0 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==RULE_BS) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyDsl.g:970:3: rule__Model__BAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Model__BAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getModelAccess().getBAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0__Impl"


    // $ANTLR start "rule__Model__Group__1"
    // InternalMyDsl.g:978:1: rule__Model__Group__1 : rule__Model__Group__1__Impl rule__Model__Group__2 ;
    public final void rule__Model__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:982:1: ( rule__Model__Group__1__Impl rule__Model__Group__2 )
            // InternalMyDsl.g:983:2: rule__Model__Group__1__Impl rule__Model__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__Model__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1"


    // $ANTLR start "rule__Model__Group__1__Impl"
    // InternalMyDsl.g:990:1: rule__Model__Group__1__Impl : ( ( rule__Model__PAssignment_1 )* ) ;
    public final void rule__Model__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:994:1: ( ( ( rule__Model__PAssignment_1 )* ) )
            // InternalMyDsl.g:995:1: ( ( rule__Model__PAssignment_1 )* )
            {
            // InternalMyDsl.g:995:1: ( ( rule__Model__PAssignment_1 )* )
            // InternalMyDsl.g:996:2: ( rule__Model__PAssignment_1 )*
            {
             before(grammarAccess.getModelAccess().getPAssignment_1()); 
            // InternalMyDsl.g:997:2: ( rule__Model__PAssignment_1 )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==RULE_PRFX) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // InternalMyDsl.g:997:3: rule__Model__PAssignment_1
            	    {
            	    pushFollow(FOLLOW_4);
            	    rule__Model__PAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getPAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1__Impl"


    // $ANTLR start "rule__Model__Group__2"
    // InternalMyDsl.g:1005:1: rule__Model__Group__2 : rule__Model__Group__2__Impl rule__Model__Group__3 ;
    public final void rule__Model__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1009:1: ( rule__Model__Group__2__Impl rule__Model__Group__3 )
            // InternalMyDsl.g:1010:2: rule__Model__Group__2__Impl rule__Model__Group__3
            {
            pushFollow(FOLLOW_3);
            rule__Model__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2"


    // $ANTLR start "rule__Model__Group__2__Impl"
    // InternalMyDsl.g:1017:1: rule__Model__Group__2__Impl : ( ( rule__Model__SAssignment_2 )* ) ;
    public final void rule__Model__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1021:1: ( ( ( rule__Model__SAssignment_2 )* ) )
            // InternalMyDsl.g:1022:1: ( ( rule__Model__SAssignment_2 )* )
            {
            // InternalMyDsl.g:1022:1: ( ( rule__Model__SAssignment_2 )* )
            // InternalMyDsl.g:1023:2: ( rule__Model__SAssignment_2 )*
            {
             before(grammarAccess.getModelAccess().getSAssignment_2()); 
            // InternalMyDsl.g:1024:2: ( rule__Model__SAssignment_2 )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==RULE_SRC) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalMyDsl.g:1024:3: rule__Model__SAssignment_2
            	    {
            	    pushFollow(FOLLOW_5);
            	    rule__Model__SAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getSAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2__Impl"


    // $ANTLR start "rule__Model__Group__3"
    // InternalMyDsl.g:1032:1: rule__Model__Group__3 : rule__Model__Group__3__Impl ;
    public final void rule__Model__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1036:1: ( rule__Model__Group__3__Impl )
            // InternalMyDsl.g:1037:2: rule__Model__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3"


    // $ANTLR start "rule__Model__Group__3__Impl"
    // InternalMyDsl.g:1043:1: rule__Model__Group__3__Impl : ( ( rule__Model__StAssignment_3 )* ) ;
    public final void rule__Model__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1047:1: ( ( ( rule__Model__StAssignment_3 )* ) )
            // InternalMyDsl.g:1048:1: ( ( rule__Model__StAssignment_3 )* )
            {
            // InternalMyDsl.g:1048:1: ( ( rule__Model__StAssignment_3 )* )
            // InternalMyDsl.g:1049:2: ( rule__Model__StAssignment_3 )*
            {
             before(grammarAccess.getModelAccess().getStAssignment_3()); 
            // InternalMyDsl.g:1050:2: ( rule__Model__StAssignment_3 )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( ((LA16_0>=RULE_PNAME_LN && LA16_0<=RULE_IRI)||LA16_0==RULE_VARORPREDNAME) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalMyDsl.g:1050:3: rule__Model__StAssignment_3
            	    {
            	    pushFollow(FOLLOW_6);
            	    rule__Model__StAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getStAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3__Impl"


    // $ANTLR start "rule__RDFLiteral__Group__0"
    // InternalMyDsl.g:1059:1: rule__RDFLiteral__Group__0 : rule__RDFLiteral__Group__0__Impl rule__RDFLiteral__Group__1 ;
    public final void rule__RDFLiteral__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1063:1: ( rule__RDFLiteral__Group__0__Impl rule__RDFLiteral__Group__1 )
            // InternalMyDsl.g:1064:2: rule__RDFLiteral__Group__0__Impl rule__RDFLiteral__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__RDFLiteral__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RDFLiteral__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__Group__0"


    // $ANTLR start "rule__RDFLiteral__Group__0__Impl"
    // InternalMyDsl.g:1071:1: rule__RDFLiteral__Group__0__Impl : ( ( rule__RDFLiteral__SAssignment_0 ) ) ;
    public final void rule__RDFLiteral__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1075:1: ( ( ( rule__RDFLiteral__SAssignment_0 ) ) )
            // InternalMyDsl.g:1076:1: ( ( rule__RDFLiteral__SAssignment_0 ) )
            {
            // InternalMyDsl.g:1076:1: ( ( rule__RDFLiteral__SAssignment_0 ) )
            // InternalMyDsl.g:1077:2: ( rule__RDFLiteral__SAssignment_0 )
            {
             before(grammarAccess.getRDFLiteralAccess().getSAssignment_0()); 
            // InternalMyDsl.g:1078:2: ( rule__RDFLiteral__SAssignment_0 )
            // InternalMyDsl.g:1078:3: rule__RDFLiteral__SAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__RDFLiteral__SAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getRDFLiteralAccess().getSAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__Group__0__Impl"


    // $ANTLR start "rule__RDFLiteral__Group__1"
    // InternalMyDsl.g:1086:1: rule__RDFLiteral__Group__1 : rule__RDFLiteral__Group__1__Impl ;
    public final void rule__RDFLiteral__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1090:1: ( rule__RDFLiteral__Group__1__Impl )
            // InternalMyDsl.g:1091:2: rule__RDFLiteral__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RDFLiteral__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__Group__1"


    // $ANTLR start "rule__RDFLiteral__Group__1__Impl"
    // InternalMyDsl.g:1097:1: rule__RDFLiteral__Group__1__Impl : ( ( rule__RDFLiteral__Alternatives_1 )? ) ;
    public final void rule__RDFLiteral__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1101:1: ( ( ( rule__RDFLiteral__Alternatives_1 )? ) )
            // InternalMyDsl.g:1102:1: ( ( rule__RDFLiteral__Alternatives_1 )? )
            {
            // InternalMyDsl.g:1102:1: ( ( rule__RDFLiteral__Alternatives_1 )? )
            // InternalMyDsl.g:1103:2: ( rule__RDFLiteral__Alternatives_1 )?
            {
             before(grammarAccess.getRDFLiteralAccess().getAlternatives_1()); 
            // InternalMyDsl.g:1104:2: ( rule__RDFLiteral__Alternatives_1 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==RULE_DATATYPE||LA17_0==RULE_LANGTAG) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalMyDsl.g:1104:3: rule__RDFLiteral__Alternatives_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__RDFLiteral__Alternatives_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRDFLiteralAccess().getAlternatives_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__Group__1__Impl"


    // $ANTLR start "rule__RDFLiteral__Group_1_1__0"
    // InternalMyDsl.g:1113:1: rule__RDFLiteral__Group_1_1__0 : rule__RDFLiteral__Group_1_1__0__Impl rule__RDFLiteral__Group_1_1__1 ;
    public final void rule__RDFLiteral__Group_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1117:1: ( rule__RDFLiteral__Group_1_1__0__Impl rule__RDFLiteral__Group_1_1__1 )
            // InternalMyDsl.g:1118:2: rule__RDFLiteral__Group_1_1__0__Impl rule__RDFLiteral__Group_1_1__1
            {
            pushFollow(FOLLOW_8);
            rule__RDFLiteral__Group_1_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RDFLiteral__Group_1_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__Group_1_1__0"


    // $ANTLR start "rule__RDFLiteral__Group_1_1__0__Impl"
    // InternalMyDsl.g:1125:1: rule__RDFLiteral__Group_1_1__0__Impl : ( RULE_DATATYPE ) ;
    public final void rule__RDFLiteral__Group_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1129:1: ( ( RULE_DATATYPE ) )
            // InternalMyDsl.g:1130:1: ( RULE_DATATYPE )
            {
            // InternalMyDsl.g:1130:1: ( RULE_DATATYPE )
            // InternalMyDsl.g:1131:2: RULE_DATATYPE
            {
             before(grammarAccess.getRDFLiteralAccess().getDATATYPETerminalRuleCall_1_1_0()); 
            match(input,RULE_DATATYPE,FOLLOW_2); 
             after(grammarAccess.getRDFLiteralAccess().getDATATYPETerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__Group_1_1__0__Impl"


    // $ANTLR start "rule__RDFLiteral__Group_1_1__1"
    // InternalMyDsl.g:1140:1: rule__RDFLiteral__Group_1_1__1 : rule__RDFLiteral__Group_1_1__1__Impl ;
    public final void rule__RDFLiteral__Group_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1144:1: ( rule__RDFLiteral__Group_1_1__1__Impl )
            // InternalMyDsl.g:1145:2: rule__RDFLiteral__Group_1_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RDFLiteral__Group_1_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__Group_1_1__1"


    // $ANTLR start "rule__RDFLiteral__Group_1_1__1__Impl"
    // InternalMyDsl.g:1151:1: rule__RDFLiteral__Group_1_1__1__Impl : ( ( rule__RDFLiteral__DtAssignment_1_1_1 ) ) ;
    public final void rule__RDFLiteral__Group_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1155:1: ( ( ( rule__RDFLiteral__DtAssignment_1_1_1 ) ) )
            // InternalMyDsl.g:1156:1: ( ( rule__RDFLiteral__DtAssignment_1_1_1 ) )
            {
            // InternalMyDsl.g:1156:1: ( ( rule__RDFLiteral__DtAssignment_1_1_1 ) )
            // InternalMyDsl.g:1157:2: ( rule__RDFLiteral__DtAssignment_1_1_1 )
            {
             before(grammarAccess.getRDFLiteralAccess().getDtAssignment_1_1_1()); 
            // InternalMyDsl.g:1158:2: ( rule__RDFLiteral__DtAssignment_1_1_1 )
            // InternalMyDsl.g:1158:3: rule__RDFLiteral__DtAssignment_1_1_1
            {
            pushFollow(FOLLOW_2);
            rule__RDFLiteral__DtAssignment_1_1_1();

            state._fsp--;


            }

             after(grammarAccess.getRDFLiteralAccess().getDtAssignment_1_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__Group_1_1__1__Impl"


    // $ANTLR start "rule__ListOfTerms__Group__0"
    // InternalMyDsl.g:1167:1: rule__ListOfTerms__Group__0 : rule__ListOfTerms__Group__0__Impl rule__ListOfTerms__Group__1 ;
    public final void rule__ListOfTerms__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1171:1: ( rule__ListOfTerms__Group__0__Impl rule__ListOfTerms__Group__1 )
            // InternalMyDsl.g:1172:2: rule__ListOfTerms__Group__0__Impl rule__ListOfTerms__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__ListOfTerms__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListOfTerms__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__Group__0"


    // $ANTLR start "rule__ListOfTerms__Group__0__Impl"
    // InternalMyDsl.g:1179:1: rule__ListOfTerms__Group__0__Impl : ( ( rule__ListOfTerms__TAssignment_0 ) ) ;
    public final void rule__ListOfTerms__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1183:1: ( ( ( rule__ListOfTerms__TAssignment_0 ) ) )
            // InternalMyDsl.g:1184:1: ( ( rule__ListOfTerms__TAssignment_0 ) )
            {
            // InternalMyDsl.g:1184:1: ( ( rule__ListOfTerms__TAssignment_0 ) )
            // InternalMyDsl.g:1185:2: ( rule__ListOfTerms__TAssignment_0 )
            {
             before(grammarAccess.getListOfTermsAccess().getTAssignment_0()); 
            // InternalMyDsl.g:1186:2: ( rule__ListOfTerms__TAssignment_0 )
            // InternalMyDsl.g:1186:3: rule__ListOfTerms__TAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ListOfTerms__TAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getListOfTermsAccess().getTAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__Group__0__Impl"


    // $ANTLR start "rule__ListOfTerms__Group__1"
    // InternalMyDsl.g:1194:1: rule__ListOfTerms__Group__1 : rule__ListOfTerms__Group__1__Impl ;
    public final void rule__ListOfTerms__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1198:1: ( rule__ListOfTerms__Group__1__Impl )
            // InternalMyDsl.g:1199:2: rule__ListOfTerms__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ListOfTerms__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__Group__1"


    // $ANTLR start "rule__ListOfTerms__Group__1__Impl"
    // InternalMyDsl.g:1205:1: rule__ListOfTerms__Group__1__Impl : ( ( rule__ListOfTerms__Group_1__0 )* ) ;
    public final void rule__ListOfTerms__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1209:1: ( ( ( rule__ListOfTerms__Group_1__0 )* ) )
            // InternalMyDsl.g:1210:1: ( ( rule__ListOfTerms__Group_1__0 )* )
            {
            // InternalMyDsl.g:1210:1: ( ( rule__ListOfTerms__Group_1__0 )* )
            // InternalMyDsl.g:1211:2: ( rule__ListOfTerms__Group_1__0 )*
            {
             before(grammarAccess.getListOfTermsAccess().getGroup_1()); 
            // InternalMyDsl.g:1212:2: ( rule__ListOfTerms__Group_1__0 )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==RULE_COMMA) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // InternalMyDsl.g:1212:3: rule__ListOfTerms__Group_1__0
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__ListOfTerms__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

             after(grammarAccess.getListOfTermsAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__Group__1__Impl"


    // $ANTLR start "rule__ListOfTerms__Group_1__0"
    // InternalMyDsl.g:1221:1: rule__ListOfTerms__Group_1__0 : rule__ListOfTerms__Group_1__0__Impl rule__ListOfTerms__Group_1__1 ;
    public final void rule__ListOfTerms__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1225:1: ( rule__ListOfTerms__Group_1__0__Impl rule__ListOfTerms__Group_1__1 )
            // InternalMyDsl.g:1226:2: rule__ListOfTerms__Group_1__0__Impl rule__ListOfTerms__Group_1__1
            {
            pushFollow(FOLLOW_11);
            rule__ListOfTerms__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListOfTerms__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__Group_1__0"


    // $ANTLR start "rule__ListOfTerms__Group_1__0__Impl"
    // InternalMyDsl.g:1233:1: rule__ListOfTerms__Group_1__0__Impl : ( RULE_COMMA ) ;
    public final void rule__ListOfTerms__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1237:1: ( ( RULE_COMMA ) )
            // InternalMyDsl.g:1238:1: ( RULE_COMMA )
            {
            // InternalMyDsl.g:1238:1: ( RULE_COMMA )
            // InternalMyDsl.g:1239:2: RULE_COMMA
            {
             before(grammarAccess.getListOfTermsAccess().getCOMMATerminalRuleCall_1_0()); 
            match(input,RULE_COMMA,FOLLOW_2); 
             after(grammarAccess.getListOfTermsAccess().getCOMMATerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__Group_1__0__Impl"


    // $ANTLR start "rule__ListOfTerms__Group_1__1"
    // InternalMyDsl.g:1248:1: rule__ListOfTerms__Group_1__1 : rule__ListOfTerms__Group_1__1__Impl ;
    public final void rule__ListOfTerms__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1252:1: ( rule__ListOfTerms__Group_1__1__Impl )
            // InternalMyDsl.g:1253:2: rule__ListOfTerms__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ListOfTerms__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__Group_1__1"


    // $ANTLR start "rule__ListOfTerms__Group_1__1__Impl"
    // InternalMyDsl.g:1259:1: rule__ListOfTerms__Group_1__1__Impl : ( ( rule__ListOfTerms__TAssignment_1_1 ) ) ;
    public final void rule__ListOfTerms__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1263:1: ( ( ( rule__ListOfTerms__TAssignment_1_1 ) ) )
            // InternalMyDsl.g:1264:1: ( ( rule__ListOfTerms__TAssignment_1_1 ) )
            {
            // InternalMyDsl.g:1264:1: ( ( rule__ListOfTerms__TAssignment_1_1 ) )
            // InternalMyDsl.g:1265:2: ( rule__ListOfTerms__TAssignment_1_1 )
            {
             before(grammarAccess.getListOfTermsAccess().getTAssignment_1_1()); 
            // InternalMyDsl.g:1266:2: ( rule__ListOfTerms__TAssignment_1_1 )
            // InternalMyDsl.g:1266:3: rule__ListOfTerms__TAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__ListOfTerms__TAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getListOfTermsAccess().getTAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__Group_1__1__Impl"


    // $ANTLR start "rule__NegativeLiteral__Group__0"
    // InternalMyDsl.g:1275:1: rule__NegativeLiteral__Group__0 : rule__NegativeLiteral__Group__0__Impl rule__NegativeLiteral__Group__1 ;
    public final void rule__NegativeLiteral__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1279:1: ( rule__NegativeLiteral__Group__0__Impl rule__NegativeLiteral__Group__1 )
            // InternalMyDsl.g:1280:2: rule__NegativeLiteral__Group__0__Impl rule__NegativeLiteral__Group__1
            {
            pushFollow(FOLLOW_12);
            rule__NegativeLiteral__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NegativeLiteral__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__0"


    // $ANTLR start "rule__NegativeLiteral__Group__0__Impl"
    // InternalMyDsl.g:1287:1: rule__NegativeLiteral__Group__0__Impl : ( RULE_TILDE ) ;
    public final void rule__NegativeLiteral__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1291:1: ( ( RULE_TILDE ) )
            // InternalMyDsl.g:1292:1: ( RULE_TILDE )
            {
            // InternalMyDsl.g:1292:1: ( RULE_TILDE )
            // InternalMyDsl.g:1293:2: RULE_TILDE
            {
             before(grammarAccess.getNegativeLiteralAccess().getTILDETerminalRuleCall_0()); 
            match(input,RULE_TILDE,FOLLOW_2); 
             after(grammarAccess.getNegativeLiteralAccess().getTILDETerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__0__Impl"


    // $ANTLR start "rule__NegativeLiteral__Group__1"
    // InternalMyDsl.g:1302:1: rule__NegativeLiteral__Group__1 : rule__NegativeLiteral__Group__1__Impl rule__NegativeLiteral__Group__2 ;
    public final void rule__NegativeLiteral__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1306:1: ( rule__NegativeLiteral__Group__1__Impl rule__NegativeLiteral__Group__2 )
            // InternalMyDsl.g:1307:2: rule__NegativeLiteral__Group__1__Impl rule__NegativeLiteral__Group__2
            {
            pushFollow(FOLLOW_13);
            rule__NegativeLiteral__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NegativeLiteral__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__1"


    // $ANTLR start "rule__NegativeLiteral__Group__1__Impl"
    // InternalMyDsl.g:1314:1: rule__NegativeLiteral__Group__1__Impl : ( ( rule__NegativeLiteral__PredicatenameAssignment_1 ) ) ;
    public final void rule__NegativeLiteral__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1318:1: ( ( ( rule__NegativeLiteral__PredicatenameAssignment_1 ) ) )
            // InternalMyDsl.g:1319:1: ( ( rule__NegativeLiteral__PredicatenameAssignment_1 ) )
            {
            // InternalMyDsl.g:1319:1: ( ( rule__NegativeLiteral__PredicatenameAssignment_1 ) )
            // InternalMyDsl.g:1320:2: ( rule__NegativeLiteral__PredicatenameAssignment_1 )
            {
             before(grammarAccess.getNegativeLiteralAccess().getPredicatenameAssignment_1()); 
            // InternalMyDsl.g:1321:2: ( rule__NegativeLiteral__PredicatenameAssignment_1 )
            // InternalMyDsl.g:1321:3: rule__NegativeLiteral__PredicatenameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__NegativeLiteral__PredicatenameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getNegativeLiteralAccess().getPredicatenameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__1__Impl"


    // $ANTLR start "rule__NegativeLiteral__Group__2"
    // InternalMyDsl.g:1329:1: rule__NegativeLiteral__Group__2 : rule__NegativeLiteral__Group__2__Impl rule__NegativeLiteral__Group__3 ;
    public final void rule__NegativeLiteral__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1333:1: ( rule__NegativeLiteral__Group__2__Impl rule__NegativeLiteral__Group__3 )
            // InternalMyDsl.g:1334:2: rule__NegativeLiteral__Group__2__Impl rule__NegativeLiteral__Group__3
            {
            pushFollow(FOLLOW_11);
            rule__NegativeLiteral__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NegativeLiteral__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__2"


    // $ANTLR start "rule__NegativeLiteral__Group__2__Impl"
    // InternalMyDsl.g:1341:1: rule__NegativeLiteral__Group__2__Impl : ( RULE_LPAREN ) ;
    public final void rule__NegativeLiteral__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1345:1: ( ( RULE_LPAREN ) )
            // InternalMyDsl.g:1346:1: ( RULE_LPAREN )
            {
            // InternalMyDsl.g:1346:1: ( RULE_LPAREN )
            // InternalMyDsl.g:1347:2: RULE_LPAREN
            {
             before(grammarAccess.getNegativeLiteralAccess().getLPARENTerminalRuleCall_2()); 
            match(input,RULE_LPAREN,FOLLOW_2); 
             after(grammarAccess.getNegativeLiteralAccess().getLPARENTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__2__Impl"


    // $ANTLR start "rule__NegativeLiteral__Group__3"
    // InternalMyDsl.g:1356:1: rule__NegativeLiteral__Group__3 : rule__NegativeLiteral__Group__3__Impl rule__NegativeLiteral__Group__4 ;
    public final void rule__NegativeLiteral__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1360:1: ( rule__NegativeLiteral__Group__3__Impl rule__NegativeLiteral__Group__4 )
            // InternalMyDsl.g:1361:2: rule__NegativeLiteral__Group__3__Impl rule__NegativeLiteral__Group__4
            {
            pushFollow(FOLLOW_14);
            rule__NegativeLiteral__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__NegativeLiteral__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__3"


    // $ANTLR start "rule__NegativeLiteral__Group__3__Impl"
    // InternalMyDsl.g:1368:1: rule__NegativeLiteral__Group__3__Impl : ( ( rule__NegativeLiteral__TermsAssignment_3 ) ) ;
    public final void rule__NegativeLiteral__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1372:1: ( ( ( rule__NegativeLiteral__TermsAssignment_3 ) ) )
            // InternalMyDsl.g:1373:1: ( ( rule__NegativeLiteral__TermsAssignment_3 ) )
            {
            // InternalMyDsl.g:1373:1: ( ( rule__NegativeLiteral__TermsAssignment_3 ) )
            // InternalMyDsl.g:1374:2: ( rule__NegativeLiteral__TermsAssignment_3 )
            {
             before(grammarAccess.getNegativeLiteralAccess().getTermsAssignment_3()); 
            // InternalMyDsl.g:1375:2: ( rule__NegativeLiteral__TermsAssignment_3 )
            // InternalMyDsl.g:1375:3: rule__NegativeLiteral__TermsAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__NegativeLiteral__TermsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getNegativeLiteralAccess().getTermsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__3__Impl"


    // $ANTLR start "rule__NegativeLiteral__Group__4"
    // InternalMyDsl.g:1383:1: rule__NegativeLiteral__Group__4 : rule__NegativeLiteral__Group__4__Impl ;
    public final void rule__NegativeLiteral__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1387:1: ( rule__NegativeLiteral__Group__4__Impl )
            // InternalMyDsl.g:1388:2: rule__NegativeLiteral__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__NegativeLiteral__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__4"


    // $ANTLR start "rule__NegativeLiteral__Group__4__Impl"
    // InternalMyDsl.g:1394:1: rule__NegativeLiteral__Group__4__Impl : ( RULE_RPAREN ) ;
    public final void rule__NegativeLiteral__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1398:1: ( ( RULE_RPAREN ) )
            // InternalMyDsl.g:1399:1: ( RULE_RPAREN )
            {
            // InternalMyDsl.g:1399:1: ( RULE_RPAREN )
            // InternalMyDsl.g:1400:2: RULE_RPAREN
            {
             before(grammarAccess.getNegativeLiteralAccess().getRPARENTerminalRuleCall_4()); 
            match(input,RULE_RPAREN,FOLLOW_2); 
             after(grammarAccess.getNegativeLiteralAccess().getRPARENTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__Group__4__Impl"


    // $ANTLR start "rule__Fact__Group__0"
    // InternalMyDsl.g:1410:1: rule__Fact__Group__0 : rule__Fact__Group__0__Impl rule__Fact__Group__1 ;
    public final void rule__Fact__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1414:1: ( rule__Fact__Group__0__Impl rule__Fact__Group__1 )
            // InternalMyDsl.g:1415:2: rule__Fact__Group__0__Impl rule__Fact__Group__1
            {
            pushFollow(FOLLOW_13);
            rule__Fact__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Fact__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__Group__0"


    // $ANTLR start "rule__Fact__Group__0__Impl"
    // InternalMyDsl.g:1422:1: rule__Fact__Group__0__Impl : ( ( rule__Fact__PredicatenameAssignment_0 ) ) ;
    public final void rule__Fact__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1426:1: ( ( ( rule__Fact__PredicatenameAssignment_0 ) ) )
            // InternalMyDsl.g:1427:1: ( ( rule__Fact__PredicatenameAssignment_0 ) )
            {
            // InternalMyDsl.g:1427:1: ( ( rule__Fact__PredicatenameAssignment_0 ) )
            // InternalMyDsl.g:1428:2: ( rule__Fact__PredicatenameAssignment_0 )
            {
             before(grammarAccess.getFactAccess().getPredicatenameAssignment_0()); 
            // InternalMyDsl.g:1429:2: ( rule__Fact__PredicatenameAssignment_0 )
            // InternalMyDsl.g:1429:3: rule__Fact__PredicatenameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Fact__PredicatenameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getFactAccess().getPredicatenameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__Group__0__Impl"


    // $ANTLR start "rule__Fact__Group__1"
    // InternalMyDsl.g:1437:1: rule__Fact__Group__1 : rule__Fact__Group__1__Impl rule__Fact__Group__2 ;
    public final void rule__Fact__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1441:1: ( rule__Fact__Group__1__Impl rule__Fact__Group__2 )
            // InternalMyDsl.g:1442:2: rule__Fact__Group__1__Impl rule__Fact__Group__2
            {
            pushFollow(FOLLOW_11);
            rule__Fact__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Fact__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__Group__1"


    // $ANTLR start "rule__Fact__Group__1__Impl"
    // InternalMyDsl.g:1449:1: rule__Fact__Group__1__Impl : ( RULE_LPAREN ) ;
    public final void rule__Fact__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1453:1: ( ( RULE_LPAREN ) )
            // InternalMyDsl.g:1454:1: ( RULE_LPAREN )
            {
            // InternalMyDsl.g:1454:1: ( RULE_LPAREN )
            // InternalMyDsl.g:1455:2: RULE_LPAREN
            {
             before(grammarAccess.getFactAccess().getLPARENTerminalRuleCall_1()); 
            match(input,RULE_LPAREN,FOLLOW_2); 
             after(grammarAccess.getFactAccess().getLPARENTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__Group__1__Impl"


    // $ANTLR start "rule__Fact__Group__2"
    // InternalMyDsl.g:1464:1: rule__Fact__Group__2 : rule__Fact__Group__2__Impl rule__Fact__Group__3 ;
    public final void rule__Fact__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1468:1: ( rule__Fact__Group__2__Impl rule__Fact__Group__3 )
            // InternalMyDsl.g:1469:2: rule__Fact__Group__2__Impl rule__Fact__Group__3
            {
            pushFollow(FOLLOW_14);
            rule__Fact__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Fact__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__Group__2"


    // $ANTLR start "rule__Fact__Group__2__Impl"
    // InternalMyDsl.g:1476:1: rule__Fact__Group__2__Impl : ( ( rule__Fact__TermsAssignment_2 ) ) ;
    public final void rule__Fact__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1480:1: ( ( ( rule__Fact__TermsAssignment_2 ) ) )
            // InternalMyDsl.g:1481:1: ( ( rule__Fact__TermsAssignment_2 ) )
            {
            // InternalMyDsl.g:1481:1: ( ( rule__Fact__TermsAssignment_2 ) )
            // InternalMyDsl.g:1482:2: ( rule__Fact__TermsAssignment_2 )
            {
             before(grammarAccess.getFactAccess().getTermsAssignment_2()); 
            // InternalMyDsl.g:1483:2: ( rule__Fact__TermsAssignment_2 )
            // InternalMyDsl.g:1483:3: rule__Fact__TermsAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Fact__TermsAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getFactAccess().getTermsAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__Group__2__Impl"


    // $ANTLR start "rule__Fact__Group__3"
    // InternalMyDsl.g:1491:1: rule__Fact__Group__3 : rule__Fact__Group__3__Impl ;
    public final void rule__Fact__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1495:1: ( rule__Fact__Group__3__Impl )
            // InternalMyDsl.g:1496:2: rule__Fact__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Fact__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__Group__3"


    // $ANTLR start "rule__Fact__Group__3__Impl"
    // InternalMyDsl.g:1502:1: rule__Fact__Group__3__Impl : ( RULE_RPAREN ) ;
    public final void rule__Fact__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1506:1: ( ( RULE_RPAREN ) )
            // InternalMyDsl.g:1507:1: ( RULE_RPAREN )
            {
            // InternalMyDsl.g:1507:1: ( RULE_RPAREN )
            // InternalMyDsl.g:1508:2: RULE_RPAREN
            {
             before(grammarAccess.getFactAccess().getRPARENTerminalRuleCall_3()); 
            match(input,RULE_RPAREN,FOLLOW_2); 
             after(grammarAccess.getFactAccess().getRPARENTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__Group__3__Impl"


    // $ANTLR start "rule__PositiveLiteral__Group__0"
    // InternalMyDsl.g:1518:1: rule__PositiveLiteral__Group__0 : rule__PositiveLiteral__Group__0__Impl rule__PositiveLiteral__Group__1 ;
    public final void rule__PositiveLiteral__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1522:1: ( rule__PositiveLiteral__Group__0__Impl rule__PositiveLiteral__Group__1 )
            // InternalMyDsl.g:1523:2: rule__PositiveLiteral__Group__0__Impl rule__PositiveLiteral__Group__1
            {
            pushFollow(FOLLOW_13);
            rule__PositiveLiteral__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PositiveLiteral__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__Group__0"


    // $ANTLR start "rule__PositiveLiteral__Group__0__Impl"
    // InternalMyDsl.g:1530:1: rule__PositiveLiteral__Group__0__Impl : ( ( rule__PositiveLiteral__PredicatenameAssignment_0 ) ) ;
    public final void rule__PositiveLiteral__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1534:1: ( ( ( rule__PositiveLiteral__PredicatenameAssignment_0 ) ) )
            // InternalMyDsl.g:1535:1: ( ( rule__PositiveLiteral__PredicatenameAssignment_0 ) )
            {
            // InternalMyDsl.g:1535:1: ( ( rule__PositiveLiteral__PredicatenameAssignment_0 ) )
            // InternalMyDsl.g:1536:2: ( rule__PositiveLiteral__PredicatenameAssignment_0 )
            {
             before(grammarAccess.getPositiveLiteralAccess().getPredicatenameAssignment_0()); 
            // InternalMyDsl.g:1537:2: ( rule__PositiveLiteral__PredicatenameAssignment_0 )
            // InternalMyDsl.g:1537:3: rule__PositiveLiteral__PredicatenameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__PositiveLiteral__PredicatenameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getPositiveLiteralAccess().getPredicatenameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__Group__0__Impl"


    // $ANTLR start "rule__PositiveLiteral__Group__1"
    // InternalMyDsl.g:1545:1: rule__PositiveLiteral__Group__1 : rule__PositiveLiteral__Group__1__Impl rule__PositiveLiteral__Group__2 ;
    public final void rule__PositiveLiteral__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1549:1: ( rule__PositiveLiteral__Group__1__Impl rule__PositiveLiteral__Group__2 )
            // InternalMyDsl.g:1550:2: rule__PositiveLiteral__Group__1__Impl rule__PositiveLiteral__Group__2
            {
            pushFollow(FOLLOW_11);
            rule__PositiveLiteral__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PositiveLiteral__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__Group__1"


    // $ANTLR start "rule__PositiveLiteral__Group__1__Impl"
    // InternalMyDsl.g:1557:1: rule__PositiveLiteral__Group__1__Impl : ( RULE_LPAREN ) ;
    public final void rule__PositiveLiteral__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1561:1: ( ( RULE_LPAREN ) )
            // InternalMyDsl.g:1562:1: ( RULE_LPAREN )
            {
            // InternalMyDsl.g:1562:1: ( RULE_LPAREN )
            // InternalMyDsl.g:1563:2: RULE_LPAREN
            {
             before(grammarAccess.getPositiveLiteralAccess().getLPARENTerminalRuleCall_1()); 
            match(input,RULE_LPAREN,FOLLOW_2); 
             after(grammarAccess.getPositiveLiteralAccess().getLPARENTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__Group__1__Impl"


    // $ANTLR start "rule__PositiveLiteral__Group__2"
    // InternalMyDsl.g:1572:1: rule__PositiveLiteral__Group__2 : rule__PositiveLiteral__Group__2__Impl rule__PositiveLiteral__Group__3 ;
    public final void rule__PositiveLiteral__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1576:1: ( rule__PositiveLiteral__Group__2__Impl rule__PositiveLiteral__Group__3 )
            // InternalMyDsl.g:1577:2: rule__PositiveLiteral__Group__2__Impl rule__PositiveLiteral__Group__3
            {
            pushFollow(FOLLOW_14);
            rule__PositiveLiteral__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PositiveLiteral__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__Group__2"


    // $ANTLR start "rule__PositiveLiteral__Group__2__Impl"
    // InternalMyDsl.g:1584:1: rule__PositiveLiteral__Group__2__Impl : ( ( rule__PositiveLiteral__TermsAssignment_2 ) ) ;
    public final void rule__PositiveLiteral__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1588:1: ( ( ( rule__PositiveLiteral__TermsAssignment_2 ) ) )
            // InternalMyDsl.g:1589:1: ( ( rule__PositiveLiteral__TermsAssignment_2 ) )
            {
            // InternalMyDsl.g:1589:1: ( ( rule__PositiveLiteral__TermsAssignment_2 ) )
            // InternalMyDsl.g:1590:2: ( rule__PositiveLiteral__TermsAssignment_2 )
            {
             before(grammarAccess.getPositiveLiteralAccess().getTermsAssignment_2()); 
            // InternalMyDsl.g:1591:2: ( rule__PositiveLiteral__TermsAssignment_2 )
            // InternalMyDsl.g:1591:3: rule__PositiveLiteral__TermsAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__PositiveLiteral__TermsAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getPositiveLiteralAccess().getTermsAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__Group__2__Impl"


    // $ANTLR start "rule__PositiveLiteral__Group__3"
    // InternalMyDsl.g:1599:1: rule__PositiveLiteral__Group__3 : rule__PositiveLiteral__Group__3__Impl ;
    public final void rule__PositiveLiteral__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1603:1: ( rule__PositiveLiteral__Group__3__Impl )
            // InternalMyDsl.g:1604:2: rule__PositiveLiteral__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__PositiveLiteral__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__Group__3"


    // $ANTLR start "rule__PositiveLiteral__Group__3__Impl"
    // InternalMyDsl.g:1610:1: rule__PositiveLiteral__Group__3__Impl : ( RULE_RPAREN ) ;
    public final void rule__PositiveLiteral__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1614:1: ( ( RULE_RPAREN ) )
            // InternalMyDsl.g:1615:1: ( RULE_RPAREN )
            {
            // InternalMyDsl.g:1615:1: ( RULE_RPAREN )
            // InternalMyDsl.g:1616:2: RULE_RPAREN
            {
             before(grammarAccess.getPositiveLiteralAccess().getRPARENTerminalRuleCall_3()); 
            match(input,RULE_RPAREN,FOLLOW_2); 
             after(grammarAccess.getPositiveLiteralAccess().getRPARENTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__Group__3__Impl"


    // $ANTLR start "rule__ListOfLiterals__Group__0"
    // InternalMyDsl.g:1626:1: rule__ListOfLiterals__Group__0 : rule__ListOfLiterals__Group__0__Impl rule__ListOfLiterals__Group__1 ;
    public final void rule__ListOfLiterals__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1630:1: ( rule__ListOfLiterals__Group__0__Impl rule__ListOfLiterals__Group__1 )
            // InternalMyDsl.g:1631:2: rule__ListOfLiterals__Group__0__Impl rule__ListOfLiterals__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__ListOfLiterals__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListOfLiterals__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__Group__0"


    // $ANTLR start "rule__ListOfLiterals__Group__0__Impl"
    // InternalMyDsl.g:1638:1: rule__ListOfLiterals__Group__0__Impl : ( ( rule__ListOfLiterals__LAssignment_0 ) ) ;
    public final void rule__ListOfLiterals__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1642:1: ( ( ( rule__ListOfLiterals__LAssignment_0 ) ) )
            // InternalMyDsl.g:1643:1: ( ( rule__ListOfLiterals__LAssignment_0 ) )
            {
            // InternalMyDsl.g:1643:1: ( ( rule__ListOfLiterals__LAssignment_0 ) )
            // InternalMyDsl.g:1644:2: ( rule__ListOfLiterals__LAssignment_0 )
            {
             before(grammarAccess.getListOfLiteralsAccess().getLAssignment_0()); 
            // InternalMyDsl.g:1645:2: ( rule__ListOfLiterals__LAssignment_0 )
            // InternalMyDsl.g:1645:3: rule__ListOfLiterals__LAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ListOfLiterals__LAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getListOfLiteralsAccess().getLAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__Group__0__Impl"


    // $ANTLR start "rule__ListOfLiterals__Group__1"
    // InternalMyDsl.g:1653:1: rule__ListOfLiterals__Group__1 : rule__ListOfLiterals__Group__1__Impl ;
    public final void rule__ListOfLiterals__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1657:1: ( rule__ListOfLiterals__Group__1__Impl )
            // InternalMyDsl.g:1658:2: rule__ListOfLiterals__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ListOfLiterals__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__Group__1"


    // $ANTLR start "rule__ListOfLiterals__Group__1__Impl"
    // InternalMyDsl.g:1664:1: rule__ListOfLiterals__Group__1__Impl : ( ( rule__ListOfLiterals__Group_1__0 )* ) ;
    public final void rule__ListOfLiterals__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1668:1: ( ( ( rule__ListOfLiterals__Group_1__0 )* ) )
            // InternalMyDsl.g:1669:1: ( ( rule__ListOfLiterals__Group_1__0 )* )
            {
            // InternalMyDsl.g:1669:1: ( ( rule__ListOfLiterals__Group_1__0 )* )
            // InternalMyDsl.g:1670:2: ( rule__ListOfLiterals__Group_1__0 )*
            {
             before(grammarAccess.getListOfLiteralsAccess().getGroup_1()); 
            // InternalMyDsl.g:1671:2: ( rule__ListOfLiterals__Group_1__0 )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==RULE_COMMA) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalMyDsl.g:1671:3: rule__ListOfLiterals__Group_1__0
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__ListOfLiterals__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

             after(grammarAccess.getListOfLiteralsAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__Group__1__Impl"


    // $ANTLR start "rule__ListOfLiterals__Group_1__0"
    // InternalMyDsl.g:1680:1: rule__ListOfLiterals__Group_1__0 : rule__ListOfLiterals__Group_1__0__Impl rule__ListOfLiterals__Group_1__1 ;
    public final void rule__ListOfLiterals__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1684:1: ( rule__ListOfLiterals__Group_1__0__Impl rule__ListOfLiterals__Group_1__1 )
            // InternalMyDsl.g:1685:2: rule__ListOfLiterals__Group_1__0__Impl rule__ListOfLiterals__Group_1__1
            {
            pushFollow(FOLLOW_15);
            rule__ListOfLiterals__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListOfLiterals__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__Group_1__0"


    // $ANTLR start "rule__ListOfLiterals__Group_1__0__Impl"
    // InternalMyDsl.g:1692:1: rule__ListOfLiterals__Group_1__0__Impl : ( RULE_COMMA ) ;
    public final void rule__ListOfLiterals__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1696:1: ( ( RULE_COMMA ) )
            // InternalMyDsl.g:1697:1: ( RULE_COMMA )
            {
            // InternalMyDsl.g:1697:1: ( RULE_COMMA )
            // InternalMyDsl.g:1698:2: RULE_COMMA
            {
             before(grammarAccess.getListOfLiteralsAccess().getCOMMATerminalRuleCall_1_0()); 
            match(input,RULE_COMMA,FOLLOW_2); 
             after(grammarAccess.getListOfLiteralsAccess().getCOMMATerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__Group_1__0__Impl"


    // $ANTLR start "rule__ListOfLiterals__Group_1__1"
    // InternalMyDsl.g:1707:1: rule__ListOfLiterals__Group_1__1 : rule__ListOfLiterals__Group_1__1__Impl ;
    public final void rule__ListOfLiterals__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1711:1: ( rule__ListOfLiterals__Group_1__1__Impl )
            // InternalMyDsl.g:1712:2: rule__ListOfLiterals__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ListOfLiterals__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__Group_1__1"


    // $ANTLR start "rule__ListOfLiterals__Group_1__1__Impl"
    // InternalMyDsl.g:1718:1: rule__ListOfLiterals__Group_1__1__Impl : ( ( rule__ListOfLiterals__LAssignment_1_1 ) ) ;
    public final void rule__ListOfLiterals__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1722:1: ( ( ( rule__ListOfLiterals__LAssignment_1_1 ) ) )
            // InternalMyDsl.g:1723:1: ( ( rule__ListOfLiterals__LAssignment_1_1 ) )
            {
            // InternalMyDsl.g:1723:1: ( ( rule__ListOfLiterals__LAssignment_1_1 ) )
            // InternalMyDsl.g:1724:2: ( rule__ListOfLiterals__LAssignment_1_1 )
            {
             before(grammarAccess.getListOfLiteralsAccess().getLAssignment_1_1()); 
            // InternalMyDsl.g:1725:2: ( rule__ListOfLiterals__LAssignment_1_1 )
            // InternalMyDsl.g:1725:3: rule__ListOfLiterals__LAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__ListOfLiterals__LAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getListOfLiteralsAccess().getLAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__Group_1__1__Impl"


    // $ANTLR start "rule__ListOfPositiveLiterals__Group__0"
    // InternalMyDsl.g:1734:1: rule__ListOfPositiveLiterals__Group__0 : rule__ListOfPositiveLiterals__Group__0__Impl rule__ListOfPositiveLiterals__Group__1 ;
    public final void rule__ListOfPositiveLiterals__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1738:1: ( rule__ListOfPositiveLiterals__Group__0__Impl rule__ListOfPositiveLiterals__Group__1 )
            // InternalMyDsl.g:1739:2: rule__ListOfPositiveLiterals__Group__0__Impl rule__ListOfPositiveLiterals__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__ListOfPositiveLiterals__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListOfPositiveLiterals__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__Group__0"


    // $ANTLR start "rule__ListOfPositiveLiterals__Group__0__Impl"
    // InternalMyDsl.g:1746:1: rule__ListOfPositiveLiterals__Group__0__Impl : ( ( rule__ListOfPositiveLiterals__LAssignment_0 ) ) ;
    public final void rule__ListOfPositiveLiterals__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1750:1: ( ( ( rule__ListOfPositiveLiterals__LAssignment_0 ) ) )
            // InternalMyDsl.g:1751:1: ( ( rule__ListOfPositiveLiterals__LAssignment_0 ) )
            {
            // InternalMyDsl.g:1751:1: ( ( rule__ListOfPositiveLiterals__LAssignment_0 ) )
            // InternalMyDsl.g:1752:2: ( rule__ListOfPositiveLiterals__LAssignment_0 )
            {
             before(grammarAccess.getListOfPositiveLiteralsAccess().getLAssignment_0()); 
            // InternalMyDsl.g:1753:2: ( rule__ListOfPositiveLiterals__LAssignment_0 )
            // InternalMyDsl.g:1753:3: rule__ListOfPositiveLiterals__LAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__ListOfPositiveLiterals__LAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getListOfPositiveLiteralsAccess().getLAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__Group__0__Impl"


    // $ANTLR start "rule__ListOfPositiveLiterals__Group__1"
    // InternalMyDsl.g:1761:1: rule__ListOfPositiveLiterals__Group__1 : rule__ListOfPositiveLiterals__Group__1__Impl ;
    public final void rule__ListOfPositiveLiterals__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1765:1: ( rule__ListOfPositiveLiterals__Group__1__Impl )
            // InternalMyDsl.g:1766:2: rule__ListOfPositiveLiterals__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ListOfPositiveLiterals__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__Group__1"


    // $ANTLR start "rule__ListOfPositiveLiterals__Group__1__Impl"
    // InternalMyDsl.g:1772:1: rule__ListOfPositiveLiterals__Group__1__Impl : ( ( rule__ListOfPositiveLiterals__Group_1__0 )* ) ;
    public final void rule__ListOfPositiveLiterals__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1776:1: ( ( ( rule__ListOfPositiveLiterals__Group_1__0 )* ) )
            // InternalMyDsl.g:1777:1: ( ( rule__ListOfPositiveLiterals__Group_1__0 )* )
            {
            // InternalMyDsl.g:1777:1: ( ( rule__ListOfPositiveLiterals__Group_1__0 )* )
            // InternalMyDsl.g:1778:2: ( rule__ListOfPositiveLiterals__Group_1__0 )*
            {
             before(grammarAccess.getListOfPositiveLiteralsAccess().getGroup_1()); 
            // InternalMyDsl.g:1779:2: ( rule__ListOfPositiveLiterals__Group_1__0 )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==RULE_COMMA) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalMyDsl.g:1779:3: rule__ListOfPositiveLiterals__Group_1__0
            	    {
            	    pushFollow(FOLLOW_10);
            	    rule__ListOfPositiveLiterals__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

             after(grammarAccess.getListOfPositiveLiteralsAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__Group__1__Impl"


    // $ANTLR start "rule__ListOfPositiveLiterals__Group_1__0"
    // InternalMyDsl.g:1788:1: rule__ListOfPositiveLiterals__Group_1__0 : rule__ListOfPositiveLiterals__Group_1__0__Impl rule__ListOfPositiveLiterals__Group_1__1 ;
    public final void rule__ListOfPositiveLiterals__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1792:1: ( rule__ListOfPositiveLiterals__Group_1__0__Impl rule__ListOfPositiveLiterals__Group_1__1 )
            // InternalMyDsl.g:1793:2: rule__ListOfPositiveLiterals__Group_1__0__Impl rule__ListOfPositiveLiterals__Group_1__1
            {
            pushFollow(FOLLOW_12);
            rule__ListOfPositiveLiterals__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListOfPositiveLiterals__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__Group_1__0"


    // $ANTLR start "rule__ListOfPositiveLiterals__Group_1__0__Impl"
    // InternalMyDsl.g:1800:1: rule__ListOfPositiveLiterals__Group_1__0__Impl : ( RULE_COMMA ) ;
    public final void rule__ListOfPositiveLiterals__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1804:1: ( ( RULE_COMMA ) )
            // InternalMyDsl.g:1805:1: ( RULE_COMMA )
            {
            // InternalMyDsl.g:1805:1: ( RULE_COMMA )
            // InternalMyDsl.g:1806:2: RULE_COMMA
            {
             before(grammarAccess.getListOfPositiveLiteralsAccess().getCOMMATerminalRuleCall_1_0()); 
            match(input,RULE_COMMA,FOLLOW_2); 
             after(grammarAccess.getListOfPositiveLiteralsAccess().getCOMMATerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__Group_1__0__Impl"


    // $ANTLR start "rule__ListOfPositiveLiterals__Group_1__1"
    // InternalMyDsl.g:1815:1: rule__ListOfPositiveLiterals__Group_1__1 : rule__ListOfPositiveLiterals__Group_1__1__Impl ;
    public final void rule__ListOfPositiveLiterals__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1819:1: ( rule__ListOfPositiveLiterals__Group_1__1__Impl )
            // InternalMyDsl.g:1820:2: rule__ListOfPositiveLiterals__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ListOfPositiveLiterals__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__Group_1__1"


    // $ANTLR start "rule__ListOfPositiveLiterals__Group_1__1__Impl"
    // InternalMyDsl.g:1826:1: rule__ListOfPositiveLiterals__Group_1__1__Impl : ( ( rule__ListOfPositiveLiterals__LAssignment_1_1 ) ) ;
    public final void rule__ListOfPositiveLiterals__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1830:1: ( ( ( rule__ListOfPositiveLiterals__LAssignment_1_1 ) ) )
            // InternalMyDsl.g:1831:1: ( ( rule__ListOfPositiveLiterals__LAssignment_1_1 ) )
            {
            // InternalMyDsl.g:1831:1: ( ( rule__ListOfPositiveLiterals__LAssignment_1_1 ) )
            // InternalMyDsl.g:1832:2: ( rule__ListOfPositiveLiterals__LAssignment_1_1 )
            {
             before(grammarAccess.getListOfPositiveLiteralsAccess().getLAssignment_1_1()); 
            // InternalMyDsl.g:1833:2: ( rule__ListOfPositiveLiterals__LAssignment_1_1 )
            // InternalMyDsl.g:1833:3: rule__ListOfPositiveLiterals__LAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__ListOfPositiveLiterals__LAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getListOfPositiveLiteralsAccess().getLAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__Group_1__1__Impl"


    // $ANTLR start "rule__Rule__Group__0"
    // InternalMyDsl.g:1842:1: rule__Rule__Group__0 : rule__Rule__Group__0__Impl rule__Rule__Group__1 ;
    public final void rule__Rule__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1846:1: ( rule__Rule__Group__0__Impl rule__Rule__Group__1 )
            // InternalMyDsl.g:1847:2: rule__Rule__Group__0__Impl rule__Rule__Group__1
            {
            pushFollow(FOLLOW_16);
            rule__Rule__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rule__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__0"


    // $ANTLR start "rule__Rule__Group__0__Impl"
    // InternalMyDsl.g:1854:1: rule__Rule__Group__0__Impl : ( ( rule__Rule__HeadAssignment_0 ) ) ;
    public final void rule__Rule__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1858:1: ( ( ( rule__Rule__HeadAssignment_0 ) ) )
            // InternalMyDsl.g:1859:1: ( ( rule__Rule__HeadAssignment_0 ) )
            {
            // InternalMyDsl.g:1859:1: ( ( rule__Rule__HeadAssignment_0 ) )
            // InternalMyDsl.g:1860:2: ( rule__Rule__HeadAssignment_0 )
            {
             before(grammarAccess.getRuleAccess().getHeadAssignment_0()); 
            // InternalMyDsl.g:1861:2: ( rule__Rule__HeadAssignment_0 )
            // InternalMyDsl.g:1861:3: rule__Rule__HeadAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Rule__HeadAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getRuleAccess().getHeadAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__0__Impl"


    // $ANTLR start "rule__Rule__Group__1"
    // InternalMyDsl.g:1869:1: rule__Rule__Group__1 : rule__Rule__Group__1__Impl rule__Rule__Group__2 ;
    public final void rule__Rule__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1873:1: ( rule__Rule__Group__1__Impl rule__Rule__Group__2 )
            // InternalMyDsl.g:1874:2: rule__Rule__Group__1__Impl rule__Rule__Group__2
            {
            pushFollow(FOLLOW_15);
            rule__Rule__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rule__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__1"


    // $ANTLR start "rule__Rule__Group__1__Impl"
    // InternalMyDsl.g:1881:1: rule__Rule__Group__1__Impl : ( RULE_ARROW ) ;
    public final void rule__Rule__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1885:1: ( ( RULE_ARROW ) )
            // InternalMyDsl.g:1886:1: ( RULE_ARROW )
            {
            // InternalMyDsl.g:1886:1: ( RULE_ARROW )
            // InternalMyDsl.g:1887:2: RULE_ARROW
            {
             before(grammarAccess.getRuleAccess().getARROWTerminalRuleCall_1()); 
            match(input,RULE_ARROW,FOLLOW_2); 
             after(grammarAccess.getRuleAccess().getARROWTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__1__Impl"


    // $ANTLR start "rule__Rule__Group__2"
    // InternalMyDsl.g:1896:1: rule__Rule__Group__2 : rule__Rule__Group__2__Impl rule__Rule__Group__3 ;
    public final void rule__Rule__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1900:1: ( rule__Rule__Group__2__Impl rule__Rule__Group__3 )
            // InternalMyDsl.g:1901:2: rule__Rule__Group__2__Impl rule__Rule__Group__3
            {
            pushFollow(FOLLOW_17);
            rule__Rule__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Rule__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__2"


    // $ANTLR start "rule__Rule__Group__2__Impl"
    // InternalMyDsl.g:1908:1: rule__Rule__Group__2__Impl : ( ( rule__Rule__BodyAssignment_2 ) ) ;
    public final void rule__Rule__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1912:1: ( ( ( rule__Rule__BodyAssignment_2 ) ) )
            // InternalMyDsl.g:1913:1: ( ( rule__Rule__BodyAssignment_2 ) )
            {
            // InternalMyDsl.g:1913:1: ( ( rule__Rule__BodyAssignment_2 ) )
            // InternalMyDsl.g:1914:2: ( rule__Rule__BodyAssignment_2 )
            {
             before(grammarAccess.getRuleAccess().getBodyAssignment_2()); 
            // InternalMyDsl.g:1915:2: ( rule__Rule__BodyAssignment_2 )
            // InternalMyDsl.g:1915:3: rule__Rule__BodyAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Rule__BodyAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRuleAccess().getBodyAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__2__Impl"


    // $ANTLR start "rule__Rule__Group__3"
    // InternalMyDsl.g:1923:1: rule__Rule__Group__3 : rule__Rule__Group__3__Impl ;
    public final void rule__Rule__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1927:1: ( rule__Rule__Group__3__Impl )
            // InternalMyDsl.g:1928:2: rule__Rule__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Rule__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__3"


    // $ANTLR start "rule__Rule__Group__3__Impl"
    // InternalMyDsl.g:1934:1: rule__Rule__Group__3__Impl : ( RULE_DOT ) ;
    public final void rule__Rule__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1938:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:1939:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:1939:1: ( RULE_DOT )
            // InternalMyDsl.g:1940:2: RULE_DOT
            {
             before(grammarAccess.getRuleAccess().getDOTTerminalRuleCall_3()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getRuleAccess().getDOTTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__Group__3__Impl"


    // $ANTLR start "rule__Statement__Group_1__0"
    // InternalMyDsl.g:1950:1: rule__Statement__Group_1__0 : rule__Statement__Group_1__0__Impl rule__Statement__Group_1__1 ;
    public final void rule__Statement__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1954:1: ( rule__Statement__Group_1__0__Impl rule__Statement__Group_1__1 )
            // InternalMyDsl.g:1955:2: rule__Statement__Group_1__0__Impl rule__Statement__Group_1__1
            {
            pushFollow(FOLLOW_17);
            rule__Statement__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statement__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_1__0"


    // $ANTLR start "rule__Statement__Group_1__0__Impl"
    // InternalMyDsl.g:1962:1: rule__Statement__Group_1__0__Impl : ( ( rule__Statement__StatementAssignment_1_0 ) ) ;
    public final void rule__Statement__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1966:1: ( ( ( rule__Statement__StatementAssignment_1_0 ) ) )
            // InternalMyDsl.g:1967:1: ( ( rule__Statement__StatementAssignment_1_0 ) )
            {
            // InternalMyDsl.g:1967:1: ( ( rule__Statement__StatementAssignment_1_0 ) )
            // InternalMyDsl.g:1968:2: ( rule__Statement__StatementAssignment_1_0 )
            {
             before(grammarAccess.getStatementAccess().getStatementAssignment_1_0()); 
            // InternalMyDsl.g:1969:2: ( rule__Statement__StatementAssignment_1_0 )
            // InternalMyDsl.g:1969:3: rule__Statement__StatementAssignment_1_0
            {
            pushFollow(FOLLOW_2);
            rule__Statement__StatementAssignment_1_0();

            state._fsp--;


            }

             after(grammarAccess.getStatementAccess().getStatementAssignment_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_1__0__Impl"


    // $ANTLR start "rule__Statement__Group_1__1"
    // InternalMyDsl.g:1977:1: rule__Statement__Group_1__1 : rule__Statement__Group_1__1__Impl ;
    public final void rule__Statement__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1981:1: ( rule__Statement__Group_1__1__Impl )
            // InternalMyDsl.g:1982:2: rule__Statement__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Statement__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_1__1"


    // $ANTLR start "rule__Statement__Group_1__1__Impl"
    // InternalMyDsl.g:1988:1: rule__Statement__Group_1__1__Impl : ( RULE_DOT ) ;
    public final void rule__Statement__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:1992:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:1993:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:1993:1: ( RULE_DOT )
            // InternalMyDsl.g:1994:2: RULE_DOT
            {
             before(grammarAccess.getStatementAccess().getDOTTerminalRuleCall_1_1()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getStatementAccess().getDOTTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_1__1__Impl"


    // $ANTLR start "rule__Statement__Group_2__0"
    // InternalMyDsl.g:2004:1: rule__Statement__Group_2__0 : rule__Statement__Group_2__0__Impl rule__Statement__Group_2__1 ;
    public final void rule__Statement__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2008:1: ( rule__Statement__Group_2__0__Impl rule__Statement__Group_2__1 )
            // InternalMyDsl.g:2009:2: rule__Statement__Group_2__0__Impl rule__Statement__Group_2__1
            {
            pushFollow(FOLLOW_18);
            rule__Statement__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statement__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_2__0"


    // $ANTLR start "rule__Statement__Group_2__0__Impl"
    // InternalMyDsl.g:2016:1: rule__Statement__Group_2__0__Impl : ( ( rule__Statement__StatementAssignment_2_0 ) ) ;
    public final void rule__Statement__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2020:1: ( ( ( rule__Statement__StatementAssignment_2_0 ) ) )
            // InternalMyDsl.g:2021:1: ( ( rule__Statement__StatementAssignment_2_0 ) )
            {
            // InternalMyDsl.g:2021:1: ( ( rule__Statement__StatementAssignment_2_0 ) )
            // InternalMyDsl.g:2022:2: ( rule__Statement__StatementAssignment_2_0 )
            {
             before(grammarAccess.getStatementAccess().getStatementAssignment_2_0()); 
            // InternalMyDsl.g:2023:2: ( rule__Statement__StatementAssignment_2_0 )
            // InternalMyDsl.g:2023:3: rule__Statement__StatementAssignment_2_0
            {
            pushFollow(FOLLOW_2);
            rule__Statement__StatementAssignment_2_0();

            state._fsp--;


            }

             after(grammarAccess.getStatementAccess().getStatementAssignment_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_2__0__Impl"


    // $ANTLR start "rule__Statement__Group_2__1"
    // InternalMyDsl.g:2031:1: rule__Statement__Group_2__1 : rule__Statement__Group_2__1__Impl ;
    public final void rule__Statement__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2035:1: ( rule__Statement__Group_2__1__Impl )
            // InternalMyDsl.g:2036:2: rule__Statement__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Statement__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_2__1"


    // $ANTLR start "rule__Statement__Group_2__1__Impl"
    // InternalMyDsl.g:2042:1: rule__Statement__Group_2__1__Impl : ( RULE_E ) ;
    public final void rule__Statement__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2046:1: ( ( RULE_E ) )
            // InternalMyDsl.g:2047:1: ( RULE_E )
            {
            // InternalMyDsl.g:2047:1: ( RULE_E )
            // InternalMyDsl.g:2048:2: RULE_E
            {
             before(grammarAccess.getStatementAccess().getETerminalRuleCall_2_1()); 
            match(input,RULE_E,FOLLOW_2); 
             after(grammarAccess.getStatementAccess().getETerminalRuleCall_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_2__1__Impl"


    // $ANTLR start "rule__Statement__Group_3__0"
    // InternalMyDsl.g:2058:1: rule__Statement__Group_3__0 : rule__Statement__Group_3__0__Impl rule__Statement__Group_3__1 ;
    public final void rule__Statement__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2062:1: ( rule__Statement__Group_3__0__Impl rule__Statement__Group_3__1 )
            // InternalMyDsl.g:2063:2: rule__Statement__Group_3__0__Impl rule__Statement__Group_3__1
            {
            pushFollow(FOLLOW_17);
            rule__Statement__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statement__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_3__0"


    // $ANTLR start "rule__Statement__Group_3__0__Impl"
    // InternalMyDsl.g:2070:1: rule__Statement__Group_3__0__Impl : ( ( rule__Statement__StatementAssignment_3_0 ) ) ;
    public final void rule__Statement__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2074:1: ( ( ( rule__Statement__StatementAssignment_3_0 ) ) )
            // InternalMyDsl.g:2075:1: ( ( rule__Statement__StatementAssignment_3_0 ) )
            {
            // InternalMyDsl.g:2075:1: ( ( rule__Statement__StatementAssignment_3_0 ) )
            // InternalMyDsl.g:2076:2: ( rule__Statement__StatementAssignment_3_0 )
            {
             before(grammarAccess.getStatementAccess().getStatementAssignment_3_0()); 
            // InternalMyDsl.g:2077:2: ( rule__Statement__StatementAssignment_3_0 )
            // InternalMyDsl.g:2077:3: rule__Statement__StatementAssignment_3_0
            {
            pushFollow(FOLLOW_2);
            rule__Statement__StatementAssignment_3_0();

            state._fsp--;


            }

             after(grammarAccess.getStatementAccess().getStatementAssignment_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_3__0__Impl"


    // $ANTLR start "rule__Statement__Group_3__1"
    // InternalMyDsl.g:2085:1: rule__Statement__Group_3__1 : rule__Statement__Group_3__1__Impl rule__Statement__Group_3__2 ;
    public final void rule__Statement__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2089:1: ( rule__Statement__Group_3__1__Impl rule__Statement__Group_3__2 )
            // InternalMyDsl.g:2090:2: rule__Statement__Group_3__1__Impl rule__Statement__Group_3__2
            {
            pushFollow(FOLLOW_18);
            rule__Statement__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Statement__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_3__1"


    // $ANTLR start "rule__Statement__Group_3__1__Impl"
    // InternalMyDsl.g:2097:1: rule__Statement__Group_3__1__Impl : ( RULE_DOT ) ;
    public final void rule__Statement__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2101:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:2102:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:2102:1: ( RULE_DOT )
            // InternalMyDsl.g:2103:2: RULE_DOT
            {
             before(grammarAccess.getStatementAccess().getDOTTerminalRuleCall_3_1()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getStatementAccess().getDOTTerminalRuleCall_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_3__1__Impl"


    // $ANTLR start "rule__Statement__Group_3__2"
    // InternalMyDsl.g:2112:1: rule__Statement__Group_3__2 : rule__Statement__Group_3__2__Impl ;
    public final void rule__Statement__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2116:1: ( rule__Statement__Group_3__2__Impl )
            // InternalMyDsl.g:2117:2: rule__Statement__Group_3__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Statement__Group_3__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_3__2"


    // $ANTLR start "rule__Statement__Group_3__2__Impl"
    // InternalMyDsl.g:2123:1: rule__Statement__Group_3__2__Impl : ( RULE_E ) ;
    public final void rule__Statement__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2127:1: ( ( RULE_E ) )
            // InternalMyDsl.g:2128:1: ( RULE_E )
            {
            // InternalMyDsl.g:2128:1: ( RULE_E )
            // InternalMyDsl.g:2129:2: RULE_E
            {
             before(grammarAccess.getStatementAccess().getETerminalRuleCall_3_2()); 
            match(input,RULE_E,FOLLOW_2); 
             after(grammarAccess.getStatementAccess().getETerminalRuleCall_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__Group_3__2__Impl"


    // $ANTLR start "rule__DataSource__Group_0__0"
    // InternalMyDsl.g:2139:1: rule__DataSource__Group_0__0 : rule__DataSource__Group_0__0__Impl rule__DataSource__Group_0__1 ;
    public final void rule__DataSource__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2143:1: ( rule__DataSource__Group_0__0__Impl rule__DataSource__Group_0__1 )
            // InternalMyDsl.g:2144:2: rule__DataSource__Group_0__0__Impl rule__DataSource__Group_0__1
            {
            pushFollow(FOLLOW_13);
            rule__DataSource__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_0__0"


    // $ANTLR start "rule__DataSource__Group_0__0__Impl"
    // InternalMyDsl.g:2151:1: rule__DataSource__Group_0__0__Impl : ( RULE_LOADCSV ) ;
    public final void rule__DataSource__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2155:1: ( ( RULE_LOADCSV ) )
            // InternalMyDsl.g:2156:1: ( RULE_LOADCSV )
            {
            // InternalMyDsl.g:2156:1: ( RULE_LOADCSV )
            // InternalMyDsl.g:2157:2: RULE_LOADCSV
            {
             before(grammarAccess.getDataSourceAccess().getLOADCSVTerminalRuleCall_0_0()); 
            match(input,RULE_LOADCSV,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getLOADCSVTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_0__0__Impl"


    // $ANTLR start "rule__DataSource__Group_0__1"
    // InternalMyDsl.g:2166:1: rule__DataSource__Group_0__1 : rule__DataSource__Group_0__1__Impl rule__DataSource__Group_0__2 ;
    public final void rule__DataSource__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2170:1: ( rule__DataSource__Group_0__1__Impl rule__DataSource__Group_0__2 )
            // InternalMyDsl.g:2171:2: rule__DataSource__Group_0__1__Impl rule__DataSource__Group_0__2
            {
            pushFollow(FOLLOW_19);
            rule__DataSource__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_0__1"


    // $ANTLR start "rule__DataSource__Group_0__1__Impl"
    // InternalMyDsl.g:2178:1: rule__DataSource__Group_0__1__Impl : ( RULE_LPAREN ) ;
    public final void rule__DataSource__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2182:1: ( ( RULE_LPAREN ) )
            // InternalMyDsl.g:2183:1: ( RULE_LPAREN )
            {
            // InternalMyDsl.g:2183:1: ( RULE_LPAREN )
            // InternalMyDsl.g:2184:2: RULE_LPAREN
            {
             before(grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_0_1()); 
            match(input,RULE_LPAREN,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_0__1__Impl"


    // $ANTLR start "rule__DataSource__Group_0__2"
    // InternalMyDsl.g:2193:1: rule__DataSource__Group_0__2 : rule__DataSource__Group_0__2__Impl rule__DataSource__Group_0__3 ;
    public final void rule__DataSource__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2197:1: ( rule__DataSource__Group_0__2__Impl rule__DataSource__Group_0__3 )
            // InternalMyDsl.g:2198:2: rule__DataSource__Group_0__2__Impl rule__DataSource__Group_0__3
            {
            pushFollow(FOLLOW_14);
            rule__DataSource__Group_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_0__2"


    // $ANTLR start "rule__DataSource__Group_0__2__Impl"
    // InternalMyDsl.g:2205:1: rule__DataSource__Group_0__2__Impl : ( ( rule__DataSource__FileNameAssignment_0_2 ) ) ;
    public final void rule__DataSource__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2209:1: ( ( ( rule__DataSource__FileNameAssignment_0_2 ) ) )
            // InternalMyDsl.g:2210:1: ( ( rule__DataSource__FileNameAssignment_0_2 ) )
            {
            // InternalMyDsl.g:2210:1: ( ( rule__DataSource__FileNameAssignment_0_2 ) )
            // InternalMyDsl.g:2211:2: ( rule__DataSource__FileNameAssignment_0_2 )
            {
             before(grammarAccess.getDataSourceAccess().getFileNameAssignment_0_2()); 
            // InternalMyDsl.g:2212:2: ( rule__DataSource__FileNameAssignment_0_2 )
            // InternalMyDsl.g:2212:3: rule__DataSource__FileNameAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__DataSource__FileNameAssignment_0_2();

            state._fsp--;


            }

             after(grammarAccess.getDataSourceAccess().getFileNameAssignment_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_0__2__Impl"


    // $ANTLR start "rule__DataSource__Group_0__3"
    // InternalMyDsl.g:2220:1: rule__DataSource__Group_0__3 : rule__DataSource__Group_0__3__Impl ;
    public final void rule__DataSource__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2224:1: ( rule__DataSource__Group_0__3__Impl )
            // InternalMyDsl.g:2225:2: rule__DataSource__Group_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DataSource__Group_0__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_0__3"


    // $ANTLR start "rule__DataSource__Group_0__3__Impl"
    // InternalMyDsl.g:2231:1: rule__DataSource__Group_0__3__Impl : ( RULE_RPAREN ) ;
    public final void rule__DataSource__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2235:1: ( ( RULE_RPAREN ) )
            // InternalMyDsl.g:2236:1: ( RULE_RPAREN )
            {
            // InternalMyDsl.g:2236:1: ( RULE_RPAREN )
            // InternalMyDsl.g:2237:2: RULE_RPAREN
            {
             before(grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_0_3()); 
            match(input,RULE_RPAREN,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_0__3__Impl"


    // $ANTLR start "rule__DataSource__Group_1__0"
    // InternalMyDsl.g:2247:1: rule__DataSource__Group_1__0 : rule__DataSource__Group_1__0__Impl rule__DataSource__Group_1__1 ;
    public final void rule__DataSource__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2251:1: ( rule__DataSource__Group_1__0__Impl rule__DataSource__Group_1__1 )
            // InternalMyDsl.g:2252:2: rule__DataSource__Group_1__0__Impl rule__DataSource__Group_1__1
            {
            pushFollow(FOLLOW_13);
            rule__DataSource__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_1__0"


    // $ANTLR start "rule__DataSource__Group_1__0__Impl"
    // InternalMyDsl.g:2259:1: rule__DataSource__Group_1__0__Impl : ( RULE_LOADRDF ) ;
    public final void rule__DataSource__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2263:1: ( ( RULE_LOADRDF ) )
            // InternalMyDsl.g:2264:1: ( RULE_LOADRDF )
            {
            // InternalMyDsl.g:2264:1: ( RULE_LOADRDF )
            // InternalMyDsl.g:2265:2: RULE_LOADRDF
            {
             before(grammarAccess.getDataSourceAccess().getLOADRDFTerminalRuleCall_1_0()); 
            match(input,RULE_LOADRDF,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getLOADRDFTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_1__0__Impl"


    // $ANTLR start "rule__DataSource__Group_1__1"
    // InternalMyDsl.g:2274:1: rule__DataSource__Group_1__1 : rule__DataSource__Group_1__1__Impl rule__DataSource__Group_1__2 ;
    public final void rule__DataSource__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2278:1: ( rule__DataSource__Group_1__1__Impl rule__DataSource__Group_1__2 )
            // InternalMyDsl.g:2279:2: rule__DataSource__Group_1__1__Impl rule__DataSource__Group_1__2
            {
            pushFollow(FOLLOW_19);
            rule__DataSource__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_1__1"


    // $ANTLR start "rule__DataSource__Group_1__1__Impl"
    // InternalMyDsl.g:2286:1: rule__DataSource__Group_1__1__Impl : ( RULE_LPAREN ) ;
    public final void rule__DataSource__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2290:1: ( ( RULE_LPAREN ) )
            // InternalMyDsl.g:2291:1: ( RULE_LPAREN )
            {
            // InternalMyDsl.g:2291:1: ( RULE_LPAREN )
            // InternalMyDsl.g:2292:2: RULE_LPAREN
            {
             before(grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_1_1()); 
            match(input,RULE_LPAREN,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_1__1__Impl"


    // $ANTLR start "rule__DataSource__Group_1__2"
    // InternalMyDsl.g:2301:1: rule__DataSource__Group_1__2 : rule__DataSource__Group_1__2__Impl rule__DataSource__Group_1__3 ;
    public final void rule__DataSource__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2305:1: ( rule__DataSource__Group_1__2__Impl rule__DataSource__Group_1__3 )
            // InternalMyDsl.g:2306:2: rule__DataSource__Group_1__2__Impl rule__DataSource__Group_1__3
            {
            pushFollow(FOLLOW_14);
            rule__DataSource__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_1__2"


    // $ANTLR start "rule__DataSource__Group_1__2__Impl"
    // InternalMyDsl.g:2313:1: rule__DataSource__Group_1__2__Impl : ( ( rule__DataSource__FileNameAssignment_1_2 ) ) ;
    public final void rule__DataSource__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2317:1: ( ( ( rule__DataSource__FileNameAssignment_1_2 ) ) )
            // InternalMyDsl.g:2318:1: ( ( rule__DataSource__FileNameAssignment_1_2 ) )
            {
            // InternalMyDsl.g:2318:1: ( ( rule__DataSource__FileNameAssignment_1_2 ) )
            // InternalMyDsl.g:2319:2: ( rule__DataSource__FileNameAssignment_1_2 )
            {
             before(grammarAccess.getDataSourceAccess().getFileNameAssignment_1_2()); 
            // InternalMyDsl.g:2320:2: ( rule__DataSource__FileNameAssignment_1_2 )
            // InternalMyDsl.g:2320:3: rule__DataSource__FileNameAssignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__DataSource__FileNameAssignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getDataSourceAccess().getFileNameAssignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_1__2__Impl"


    // $ANTLR start "rule__DataSource__Group_1__3"
    // InternalMyDsl.g:2328:1: rule__DataSource__Group_1__3 : rule__DataSource__Group_1__3__Impl ;
    public final void rule__DataSource__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2332:1: ( rule__DataSource__Group_1__3__Impl )
            // InternalMyDsl.g:2333:2: rule__DataSource__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DataSource__Group_1__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_1__3"


    // $ANTLR start "rule__DataSource__Group_1__3__Impl"
    // InternalMyDsl.g:2339:1: rule__DataSource__Group_1__3__Impl : ( RULE_RPAREN ) ;
    public final void rule__DataSource__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2343:1: ( ( RULE_RPAREN ) )
            // InternalMyDsl.g:2344:1: ( RULE_RPAREN )
            {
            // InternalMyDsl.g:2344:1: ( RULE_RPAREN )
            // InternalMyDsl.g:2345:2: RULE_RPAREN
            {
             before(grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_1_3()); 
            match(input,RULE_RPAREN,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_1__3__Impl"


    // $ANTLR start "rule__DataSource__Group_2__0"
    // InternalMyDsl.g:2355:1: rule__DataSource__Group_2__0 : rule__DataSource__Group_2__0__Impl rule__DataSource__Group_2__1 ;
    public final void rule__DataSource__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2359:1: ( rule__DataSource__Group_2__0__Impl rule__DataSource__Group_2__1 )
            // InternalMyDsl.g:2360:2: rule__DataSource__Group_2__0__Impl rule__DataSource__Group_2__1
            {
            pushFollow(FOLLOW_13);
            rule__DataSource__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__0"


    // $ANTLR start "rule__DataSource__Group_2__0__Impl"
    // InternalMyDsl.g:2367:1: rule__DataSource__Group_2__0__Impl : ( RULE_SPARQL ) ;
    public final void rule__DataSource__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2371:1: ( ( RULE_SPARQL ) )
            // InternalMyDsl.g:2372:1: ( RULE_SPARQL )
            {
            // InternalMyDsl.g:2372:1: ( RULE_SPARQL )
            // InternalMyDsl.g:2373:2: RULE_SPARQL
            {
             before(grammarAccess.getDataSourceAccess().getSPARQLTerminalRuleCall_2_0()); 
            match(input,RULE_SPARQL,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getSPARQLTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__0__Impl"


    // $ANTLR start "rule__DataSource__Group_2__1"
    // InternalMyDsl.g:2382:1: rule__DataSource__Group_2__1 : rule__DataSource__Group_2__1__Impl rule__DataSource__Group_2__2 ;
    public final void rule__DataSource__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2386:1: ( rule__DataSource__Group_2__1__Impl rule__DataSource__Group_2__2 )
            // InternalMyDsl.g:2387:2: rule__DataSource__Group_2__1__Impl rule__DataSource__Group_2__2
            {
            pushFollow(FOLLOW_8);
            rule__DataSource__Group_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__1"


    // $ANTLR start "rule__DataSource__Group_2__1__Impl"
    // InternalMyDsl.g:2394:1: rule__DataSource__Group_2__1__Impl : ( RULE_LPAREN ) ;
    public final void rule__DataSource__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2398:1: ( ( RULE_LPAREN ) )
            // InternalMyDsl.g:2399:1: ( RULE_LPAREN )
            {
            // InternalMyDsl.g:2399:1: ( RULE_LPAREN )
            // InternalMyDsl.g:2400:2: RULE_LPAREN
            {
             before(grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_2_1()); 
            match(input,RULE_LPAREN,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getLPARENTerminalRuleCall_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__1__Impl"


    // $ANTLR start "rule__DataSource__Group_2__2"
    // InternalMyDsl.g:2409:1: rule__DataSource__Group_2__2 : rule__DataSource__Group_2__2__Impl rule__DataSource__Group_2__3 ;
    public final void rule__DataSource__Group_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2413:1: ( rule__DataSource__Group_2__2__Impl rule__DataSource__Group_2__3 )
            // InternalMyDsl.g:2414:2: rule__DataSource__Group_2__2__Impl rule__DataSource__Group_2__3
            {
            pushFollow(FOLLOW_9);
            rule__DataSource__Group_2__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_2__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__2"


    // $ANTLR start "rule__DataSource__Group_2__2__Impl"
    // InternalMyDsl.g:2421:1: rule__DataSource__Group_2__2__Impl : ( ( rule__DataSource__EndpointAssignment_2_2 ) ) ;
    public final void rule__DataSource__Group_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2425:1: ( ( ( rule__DataSource__EndpointAssignment_2_2 ) ) )
            // InternalMyDsl.g:2426:1: ( ( rule__DataSource__EndpointAssignment_2_2 ) )
            {
            // InternalMyDsl.g:2426:1: ( ( rule__DataSource__EndpointAssignment_2_2 ) )
            // InternalMyDsl.g:2427:2: ( rule__DataSource__EndpointAssignment_2_2 )
            {
             before(grammarAccess.getDataSourceAccess().getEndpointAssignment_2_2()); 
            // InternalMyDsl.g:2428:2: ( rule__DataSource__EndpointAssignment_2_2 )
            // InternalMyDsl.g:2428:3: rule__DataSource__EndpointAssignment_2_2
            {
            pushFollow(FOLLOW_2);
            rule__DataSource__EndpointAssignment_2_2();

            state._fsp--;


            }

             after(grammarAccess.getDataSourceAccess().getEndpointAssignment_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__2__Impl"


    // $ANTLR start "rule__DataSource__Group_2__3"
    // InternalMyDsl.g:2436:1: rule__DataSource__Group_2__3 : rule__DataSource__Group_2__3__Impl rule__DataSource__Group_2__4 ;
    public final void rule__DataSource__Group_2__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2440:1: ( rule__DataSource__Group_2__3__Impl rule__DataSource__Group_2__4 )
            // InternalMyDsl.g:2441:2: rule__DataSource__Group_2__3__Impl rule__DataSource__Group_2__4
            {
            pushFollow(FOLLOW_19);
            rule__DataSource__Group_2__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_2__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__3"


    // $ANTLR start "rule__DataSource__Group_2__3__Impl"
    // InternalMyDsl.g:2448:1: rule__DataSource__Group_2__3__Impl : ( RULE_COMMA ) ;
    public final void rule__DataSource__Group_2__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2452:1: ( ( RULE_COMMA ) )
            // InternalMyDsl.g:2453:1: ( RULE_COMMA )
            {
            // InternalMyDsl.g:2453:1: ( RULE_COMMA )
            // InternalMyDsl.g:2454:2: RULE_COMMA
            {
             before(grammarAccess.getDataSourceAccess().getCOMMATerminalRuleCall_2_3()); 
            match(input,RULE_COMMA,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getCOMMATerminalRuleCall_2_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__3__Impl"


    // $ANTLR start "rule__DataSource__Group_2__4"
    // InternalMyDsl.g:2463:1: rule__DataSource__Group_2__4 : rule__DataSource__Group_2__4__Impl rule__DataSource__Group_2__5 ;
    public final void rule__DataSource__Group_2__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2467:1: ( rule__DataSource__Group_2__4__Impl rule__DataSource__Group_2__5 )
            // InternalMyDsl.g:2468:2: rule__DataSource__Group_2__4__Impl rule__DataSource__Group_2__5
            {
            pushFollow(FOLLOW_9);
            rule__DataSource__Group_2__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_2__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__4"


    // $ANTLR start "rule__DataSource__Group_2__4__Impl"
    // InternalMyDsl.g:2475:1: rule__DataSource__Group_2__4__Impl : ( ( rule__DataSource__VariablesAssignment_2_4 ) ) ;
    public final void rule__DataSource__Group_2__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2479:1: ( ( ( rule__DataSource__VariablesAssignment_2_4 ) ) )
            // InternalMyDsl.g:2480:1: ( ( rule__DataSource__VariablesAssignment_2_4 ) )
            {
            // InternalMyDsl.g:2480:1: ( ( rule__DataSource__VariablesAssignment_2_4 ) )
            // InternalMyDsl.g:2481:2: ( rule__DataSource__VariablesAssignment_2_4 )
            {
             before(grammarAccess.getDataSourceAccess().getVariablesAssignment_2_4()); 
            // InternalMyDsl.g:2482:2: ( rule__DataSource__VariablesAssignment_2_4 )
            // InternalMyDsl.g:2482:3: rule__DataSource__VariablesAssignment_2_4
            {
            pushFollow(FOLLOW_2);
            rule__DataSource__VariablesAssignment_2_4();

            state._fsp--;


            }

             after(grammarAccess.getDataSourceAccess().getVariablesAssignment_2_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__4__Impl"


    // $ANTLR start "rule__DataSource__Group_2__5"
    // InternalMyDsl.g:2490:1: rule__DataSource__Group_2__5 : rule__DataSource__Group_2__5__Impl rule__DataSource__Group_2__6 ;
    public final void rule__DataSource__Group_2__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2494:1: ( rule__DataSource__Group_2__5__Impl rule__DataSource__Group_2__6 )
            // InternalMyDsl.g:2495:2: rule__DataSource__Group_2__5__Impl rule__DataSource__Group_2__6
            {
            pushFollow(FOLLOW_19);
            rule__DataSource__Group_2__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_2__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__5"


    // $ANTLR start "rule__DataSource__Group_2__5__Impl"
    // InternalMyDsl.g:2502:1: rule__DataSource__Group_2__5__Impl : ( RULE_COMMA ) ;
    public final void rule__DataSource__Group_2__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2506:1: ( ( RULE_COMMA ) )
            // InternalMyDsl.g:2507:1: ( RULE_COMMA )
            {
            // InternalMyDsl.g:2507:1: ( RULE_COMMA )
            // InternalMyDsl.g:2508:2: RULE_COMMA
            {
             before(grammarAccess.getDataSourceAccess().getCOMMATerminalRuleCall_2_5()); 
            match(input,RULE_COMMA,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getCOMMATerminalRuleCall_2_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__5__Impl"


    // $ANTLR start "rule__DataSource__Group_2__6"
    // InternalMyDsl.g:2517:1: rule__DataSource__Group_2__6 : rule__DataSource__Group_2__6__Impl rule__DataSource__Group_2__7 ;
    public final void rule__DataSource__Group_2__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2521:1: ( rule__DataSource__Group_2__6__Impl rule__DataSource__Group_2__7 )
            // InternalMyDsl.g:2522:2: rule__DataSource__Group_2__6__Impl rule__DataSource__Group_2__7
            {
            pushFollow(FOLLOW_14);
            rule__DataSource__Group_2__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__DataSource__Group_2__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__6"


    // $ANTLR start "rule__DataSource__Group_2__6__Impl"
    // InternalMyDsl.g:2529:1: rule__DataSource__Group_2__6__Impl : ( ( rule__DataSource__QueryAssignment_2_6 ) ) ;
    public final void rule__DataSource__Group_2__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2533:1: ( ( ( rule__DataSource__QueryAssignment_2_6 ) ) )
            // InternalMyDsl.g:2534:1: ( ( rule__DataSource__QueryAssignment_2_6 ) )
            {
            // InternalMyDsl.g:2534:1: ( ( rule__DataSource__QueryAssignment_2_6 ) )
            // InternalMyDsl.g:2535:2: ( rule__DataSource__QueryAssignment_2_6 )
            {
             before(grammarAccess.getDataSourceAccess().getQueryAssignment_2_6()); 
            // InternalMyDsl.g:2536:2: ( rule__DataSource__QueryAssignment_2_6 )
            // InternalMyDsl.g:2536:3: rule__DataSource__QueryAssignment_2_6
            {
            pushFollow(FOLLOW_2);
            rule__DataSource__QueryAssignment_2_6();

            state._fsp--;


            }

             after(grammarAccess.getDataSourceAccess().getQueryAssignment_2_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__6__Impl"


    // $ANTLR start "rule__DataSource__Group_2__7"
    // InternalMyDsl.g:2544:1: rule__DataSource__Group_2__7 : rule__DataSource__Group_2__7__Impl ;
    public final void rule__DataSource__Group_2__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2548:1: ( rule__DataSource__Group_2__7__Impl )
            // InternalMyDsl.g:2549:2: rule__DataSource__Group_2__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__DataSource__Group_2__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__7"


    // $ANTLR start "rule__DataSource__Group_2__7__Impl"
    // InternalMyDsl.g:2555:1: rule__DataSource__Group_2__7__Impl : ( RULE_RPAREN ) ;
    public final void rule__DataSource__Group_2__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2559:1: ( ( RULE_RPAREN ) )
            // InternalMyDsl.g:2560:1: ( RULE_RPAREN )
            {
            // InternalMyDsl.g:2560:1: ( RULE_RPAREN )
            // InternalMyDsl.g:2561:2: RULE_RPAREN
            {
             before(grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_2_7()); 
            match(input,RULE_RPAREN,FOLLOW_2); 
             after(grammarAccess.getDataSourceAccess().getRPARENTerminalRuleCall_2_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__Group_2__7__Impl"


    // $ANTLR start "rule__Source__Group_0__0"
    // InternalMyDsl.g:2571:1: rule__Source__Group_0__0 : rule__Source__Group_0__0__Impl rule__Source__Group_0__1 ;
    public final void rule__Source__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2575:1: ( rule__Source__Group_0__0__Impl rule__Source__Group_0__1 )
            // InternalMyDsl.g:2576:2: rule__Source__Group_0__0__Impl rule__Source__Group_0__1
            {
            pushFollow(FOLLOW_12);
            rule__Source__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__0"


    // $ANTLR start "rule__Source__Group_0__0__Impl"
    // InternalMyDsl.g:2583:1: rule__Source__Group_0__0__Impl : ( RULE_SRC ) ;
    public final void rule__Source__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2587:1: ( ( RULE_SRC ) )
            // InternalMyDsl.g:2588:1: ( RULE_SRC )
            {
            // InternalMyDsl.g:2588:1: ( RULE_SRC )
            // InternalMyDsl.g:2589:2: RULE_SRC
            {
             before(grammarAccess.getSourceAccess().getSRCTerminalRuleCall_0_0()); 
            match(input,RULE_SRC,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getSRCTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__0__Impl"


    // $ANTLR start "rule__Source__Group_0__1"
    // InternalMyDsl.g:2598:1: rule__Source__Group_0__1 : rule__Source__Group_0__1__Impl rule__Source__Group_0__2 ;
    public final void rule__Source__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2602:1: ( rule__Source__Group_0__1__Impl rule__Source__Group_0__2 )
            // InternalMyDsl.g:2603:2: rule__Source__Group_0__1__Impl rule__Source__Group_0__2
            {
            pushFollow(FOLLOW_13);
            rule__Source__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__1"


    // $ANTLR start "rule__Source__Group_0__1__Impl"
    // InternalMyDsl.g:2610:1: rule__Source__Group_0__1__Impl : ( ( rule__Source__PredicatenameAssignment_0_1 ) ) ;
    public final void rule__Source__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2614:1: ( ( ( rule__Source__PredicatenameAssignment_0_1 ) ) )
            // InternalMyDsl.g:2615:1: ( ( rule__Source__PredicatenameAssignment_0_1 ) )
            {
            // InternalMyDsl.g:2615:1: ( ( rule__Source__PredicatenameAssignment_0_1 ) )
            // InternalMyDsl.g:2616:2: ( rule__Source__PredicatenameAssignment_0_1 )
            {
             before(grammarAccess.getSourceAccess().getPredicatenameAssignment_0_1()); 
            // InternalMyDsl.g:2617:2: ( rule__Source__PredicatenameAssignment_0_1 )
            // InternalMyDsl.g:2617:3: rule__Source__PredicatenameAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Source__PredicatenameAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getSourceAccess().getPredicatenameAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__1__Impl"


    // $ANTLR start "rule__Source__Group_0__2"
    // InternalMyDsl.g:2625:1: rule__Source__Group_0__2 : rule__Source__Group_0__2__Impl rule__Source__Group_0__3 ;
    public final void rule__Source__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2629:1: ( rule__Source__Group_0__2__Impl rule__Source__Group_0__3 )
            // InternalMyDsl.g:2630:2: rule__Source__Group_0__2__Impl rule__Source__Group_0__3
            {
            pushFollow(FOLLOW_20);
            rule__Source__Group_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__2"


    // $ANTLR start "rule__Source__Group_0__2__Impl"
    // InternalMyDsl.g:2637:1: rule__Source__Group_0__2__Impl : ( RULE_LPAREN ) ;
    public final void rule__Source__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2641:1: ( ( RULE_LPAREN ) )
            // InternalMyDsl.g:2642:1: ( RULE_LPAREN )
            {
            // InternalMyDsl.g:2642:1: ( RULE_LPAREN )
            // InternalMyDsl.g:2643:2: RULE_LPAREN
            {
             before(grammarAccess.getSourceAccess().getLPARENTerminalRuleCall_0_2()); 
            match(input,RULE_LPAREN,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getLPARENTerminalRuleCall_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__2__Impl"


    // $ANTLR start "rule__Source__Group_0__3"
    // InternalMyDsl.g:2652:1: rule__Source__Group_0__3 : rule__Source__Group_0__3__Impl rule__Source__Group_0__4 ;
    public final void rule__Source__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2656:1: ( rule__Source__Group_0__3__Impl rule__Source__Group_0__4 )
            // InternalMyDsl.g:2657:2: rule__Source__Group_0__3__Impl rule__Source__Group_0__4
            {
            pushFollow(FOLLOW_14);
            rule__Source__Group_0__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_0__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__3"


    // $ANTLR start "rule__Source__Group_0__3__Impl"
    // InternalMyDsl.g:2664:1: rule__Source__Group_0__3__Impl : ( ( rule__Source__ArityAssignment_0_3 ) ) ;
    public final void rule__Source__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2668:1: ( ( ( rule__Source__ArityAssignment_0_3 ) ) )
            // InternalMyDsl.g:2669:1: ( ( rule__Source__ArityAssignment_0_3 ) )
            {
            // InternalMyDsl.g:2669:1: ( ( rule__Source__ArityAssignment_0_3 ) )
            // InternalMyDsl.g:2670:2: ( rule__Source__ArityAssignment_0_3 )
            {
             before(grammarAccess.getSourceAccess().getArityAssignment_0_3()); 
            // InternalMyDsl.g:2671:2: ( rule__Source__ArityAssignment_0_3 )
            // InternalMyDsl.g:2671:3: rule__Source__ArityAssignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__Source__ArityAssignment_0_3();

            state._fsp--;


            }

             after(grammarAccess.getSourceAccess().getArityAssignment_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__3__Impl"


    // $ANTLR start "rule__Source__Group_0__4"
    // InternalMyDsl.g:2679:1: rule__Source__Group_0__4 : rule__Source__Group_0__4__Impl rule__Source__Group_0__5 ;
    public final void rule__Source__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2683:1: ( rule__Source__Group_0__4__Impl rule__Source__Group_0__5 )
            // InternalMyDsl.g:2684:2: rule__Source__Group_0__4__Impl rule__Source__Group_0__5
            {
            pushFollow(FOLLOW_21);
            rule__Source__Group_0__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_0__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__4"


    // $ANTLR start "rule__Source__Group_0__4__Impl"
    // InternalMyDsl.g:2691:1: rule__Source__Group_0__4__Impl : ( RULE_RPAREN ) ;
    public final void rule__Source__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2695:1: ( ( RULE_RPAREN ) )
            // InternalMyDsl.g:2696:1: ( RULE_RPAREN )
            {
            // InternalMyDsl.g:2696:1: ( RULE_RPAREN )
            // InternalMyDsl.g:2697:2: RULE_RPAREN
            {
             before(grammarAccess.getSourceAccess().getRPARENTerminalRuleCall_0_4()); 
            match(input,RULE_RPAREN,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getRPARENTerminalRuleCall_0_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__4__Impl"


    // $ANTLR start "rule__Source__Group_0__5"
    // InternalMyDsl.g:2706:1: rule__Source__Group_0__5 : rule__Source__Group_0__5__Impl rule__Source__Group_0__6 ;
    public final void rule__Source__Group_0__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2710:1: ( rule__Source__Group_0__5__Impl rule__Source__Group_0__6 )
            // InternalMyDsl.g:2711:2: rule__Source__Group_0__5__Impl rule__Source__Group_0__6
            {
            pushFollow(FOLLOW_22);
            rule__Source__Group_0__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_0__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__5"


    // $ANTLR start "rule__Source__Group_0__5__Impl"
    // InternalMyDsl.g:2718:1: rule__Source__Group_0__5__Impl : ( RULE_COLON ) ;
    public final void rule__Source__Group_0__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2722:1: ( ( RULE_COLON ) )
            // InternalMyDsl.g:2723:1: ( RULE_COLON )
            {
            // InternalMyDsl.g:2723:1: ( RULE_COLON )
            // InternalMyDsl.g:2724:2: RULE_COLON
            {
             before(grammarAccess.getSourceAccess().getCOLONTerminalRuleCall_0_5()); 
            match(input,RULE_COLON,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getCOLONTerminalRuleCall_0_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__5__Impl"


    // $ANTLR start "rule__Source__Group_0__6"
    // InternalMyDsl.g:2733:1: rule__Source__Group_0__6 : rule__Source__Group_0__6__Impl rule__Source__Group_0__7 ;
    public final void rule__Source__Group_0__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2737:1: ( rule__Source__Group_0__6__Impl rule__Source__Group_0__7 )
            // InternalMyDsl.g:2738:2: rule__Source__Group_0__6__Impl rule__Source__Group_0__7
            {
            pushFollow(FOLLOW_17);
            rule__Source__Group_0__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_0__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__6"


    // $ANTLR start "rule__Source__Group_0__6__Impl"
    // InternalMyDsl.g:2745:1: rule__Source__Group_0__6__Impl : ( ( rule__Source__DataSourceAssignment_0_6 ) ) ;
    public final void rule__Source__Group_0__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2749:1: ( ( ( rule__Source__DataSourceAssignment_0_6 ) ) )
            // InternalMyDsl.g:2750:1: ( ( rule__Source__DataSourceAssignment_0_6 ) )
            {
            // InternalMyDsl.g:2750:1: ( ( rule__Source__DataSourceAssignment_0_6 ) )
            // InternalMyDsl.g:2751:2: ( rule__Source__DataSourceAssignment_0_6 )
            {
             before(grammarAccess.getSourceAccess().getDataSourceAssignment_0_6()); 
            // InternalMyDsl.g:2752:2: ( rule__Source__DataSourceAssignment_0_6 )
            // InternalMyDsl.g:2752:3: rule__Source__DataSourceAssignment_0_6
            {
            pushFollow(FOLLOW_2);
            rule__Source__DataSourceAssignment_0_6();

            state._fsp--;


            }

             after(grammarAccess.getSourceAccess().getDataSourceAssignment_0_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__6__Impl"


    // $ANTLR start "rule__Source__Group_0__7"
    // InternalMyDsl.g:2760:1: rule__Source__Group_0__7 : rule__Source__Group_0__7__Impl ;
    public final void rule__Source__Group_0__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2764:1: ( rule__Source__Group_0__7__Impl )
            // InternalMyDsl.g:2765:2: rule__Source__Group_0__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Source__Group_0__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__7"


    // $ANTLR start "rule__Source__Group_0__7__Impl"
    // InternalMyDsl.g:2771:1: rule__Source__Group_0__7__Impl : ( RULE_DOT ) ;
    public final void rule__Source__Group_0__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2775:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:2776:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:2776:1: ( RULE_DOT )
            // InternalMyDsl.g:2777:2: RULE_DOT
            {
             before(grammarAccess.getSourceAccess().getDOTTerminalRuleCall_0_7()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getDOTTerminalRuleCall_0_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_0__7__Impl"


    // $ANTLR start "rule__Source__Group_1__0"
    // InternalMyDsl.g:2787:1: rule__Source__Group_1__0 : rule__Source__Group_1__0__Impl rule__Source__Group_1__1 ;
    public final void rule__Source__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2791:1: ( rule__Source__Group_1__0__Impl rule__Source__Group_1__1 )
            // InternalMyDsl.g:2792:2: rule__Source__Group_1__0__Impl rule__Source__Group_1__1
            {
            pushFollow(FOLLOW_12);
            rule__Source__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__0"


    // $ANTLR start "rule__Source__Group_1__0__Impl"
    // InternalMyDsl.g:2799:1: rule__Source__Group_1__0__Impl : ( RULE_SRC ) ;
    public final void rule__Source__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2803:1: ( ( RULE_SRC ) )
            // InternalMyDsl.g:2804:1: ( RULE_SRC )
            {
            // InternalMyDsl.g:2804:1: ( RULE_SRC )
            // InternalMyDsl.g:2805:2: RULE_SRC
            {
             before(grammarAccess.getSourceAccess().getSRCTerminalRuleCall_1_0()); 
            match(input,RULE_SRC,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getSRCTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__0__Impl"


    // $ANTLR start "rule__Source__Group_1__1"
    // InternalMyDsl.g:2814:1: rule__Source__Group_1__1 : rule__Source__Group_1__1__Impl rule__Source__Group_1__2 ;
    public final void rule__Source__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2818:1: ( rule__Source__Group_1__1__Impl rule__Source__Group_1__2 )
            // InternalMyDsl.g:2819:2: rule__Source__Group_1__1__Impl rule__Source__Group_1__2
            {
            pushFollow(FOLLOW_13);
            rule__Source__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__1"


    // $ANTLR start "rule__Source__Group_1__1__Impl"
    // InternalMyDsl.g:2826:1: rule__Source__Group_1__1__Impl : ( ( rule__Source__PredicatenameAssignment_1_1 ) ) ;
    public final void rule__Source__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2830:1: ( ( ( rule__Source__PredicatenameAssignment_1_1 ) ) )
            // InternalMyDsl.g:2831:1: ( ( rule__Source__PredicatenameAssignment_1_1 ) )
            {
            // InternalMyDsl.g:2831:1: ( ( rule__Source__PredicatenameAssignment_1_1 ) )
            // InternalMyDsl.g:2832:2: ( rule__Source__PredicatenameAssignment_1_1 )
            {
             before(grammarAccess.getSourceAccess().getPredicatenameAssignment_1_1()); 
            // InternalMyDsl.g:2833:2: ( rule__Source__PredicatenameAssignment_1_1 )
            // InternalMyDsl.g:2833:3: rule__Source__PredicatenameAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__Source__PredicatenameAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getSourceAccess().getPredicatenameAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__1__Impl"


    // $ANTLR start "rule__Source__Group_1__2"
    // InternalMyDsl.g:2841:1: rule__Source__Group_1__2 : rule__Source__Group_1__2__Impl rule__Source__Group_1__3 ;
    public final void rule__Source__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2845:1: ( rule__Source__Group_1__2__Impl rule__Source__Group_1__3 )
            // InternalMyDsl.g:2846:2: rule__Source__Group_1__2__Impl rule__Source__Group_1__3
            {
            pushFollow(FOLLOW_20);
            rule__Source__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__2"


    // $ANTLR start "rule__Source__Group_1__2__Impl"
    // InternalMyDsl.g:2853:1: rule__Source__Group_1__2__Impl : ( RULE_LPAREN ) ;
    public final void rule__Source__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2857:1: ( ( RULE_LPAREN ) )
            // InternalMyDsl.g:2858:1: ( RULE_LPAREN )
            {
            // InternalMyDsl.g:2858:1: ( RULE_LPAREN )
            // InternalMyDsl.g:2859:2: RULE_LPAREN
            {
             before(grammarAccess.getSourceAccess().getLPARENTerminalRuleCall_1_2()); 
            match(input,RULE_LPAREN,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getLPARENTerminalRuleCall_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__2__Impl"


    // $ANTLR start "rule__Source__Group_1__3"
    // InternalMyDsl.g:2868:1: rule__Source__Group_1__3 : rule__Source__Group_1__3__Impl rule__Source__Group_1__4 ;
    public final void rule__Source__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2872:1: ( rule__Source__Group_1__3__Impl rule__Source__Group_1__4 )
            // InternalMyDsl.g:2873:2: rule__Source__Group_1__3__Impl rule__Source__Group_1__4
            {
            pushFollow(FOLLOW_14);
            rule__Source__Group_1__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_1__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__3"


    // $ANTLR start "rule__Source__Group_1__3__Impl"
    // InternalMyDsl.g:2880:1: rule__Source__Group_1__3__Impl : ( ( rule__Source__ArityAssignment_1_3 ) ) ;
    public final void rule__Source__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2884:1: ( ( ( rule__Source__ArityAssignment_1_3 ) ) )
            // InternalMyDsl.g:2885:1: ( ( rule__Source__ArityAssignment_1_3 ) )
            {
            // InternalMyDsl.g:2885:1: ( ( rule__Source__ArityAssignment_1_3 ) )
            // InternalMyDsl.g:2886:2: ( rule__Source__ArityAssignment_1_3 )
            {
             before(grammarAccess.getSourceAccess().getArityAssignment_1_3()); 
            // InternalMyDsl.g:2887:2: ( rule__Source__ArityAssignment_1_3 )
            // InternalMyDsl.g:2887:3: rule__Source__ArityAssignment_1_3
            {
            pushFollow(FOLLOW_2);
            rule__Source__ArityAssignment_1_3();

            state._fsp--;


            }

             after(grammarAccess.getSourceAccess().getArityAssignment_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__3__Impl"


    // $ANTLR start "rule__Source__Group_1__4"
    // InternalMyDsl.g:2895:1: rule__Source__Group_1__4 : rule__Source__Group_1__4__Impl rule__Source__Group_1__5 ;
    public final void rule__Source__Group_1__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2899:1: ( rule__Source__Group_1__4__Impl rule__Source__Group_1__5 )
            // InternalMyDsl.g:2900:2: rule__Source__Group_1__4__Impl rule__Source__Group_1__5
            {
            pushFollow(FOLLOW_21);
            rule__Source__Group_1__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_1__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__4"


    // $ANTLR start "rule__Source__Group_1__4__Impl"
    // InternalMyDsl.g:2907:1: rule__Source__Group_1__4__Impl : ( RULE_RPAREN ) ;
    public final void rule__Source__Group_1__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2911:1: ( ( RULE_RPAREN ) )
            // InternalMyDsl.g:2912:1: ( RULE_RPAREN )
            {
            // InternalMyDsl.g:2912:1: ( RULE_RPAREN )
            // InternalMyDsl.g:2913:2: RULE_RPAREN
            {
             before(grammarAccess.getSourceAccess().getRPARENTerminalRuleCall_1_4()); 
            match(input,RULE_RPAREN,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getRPARENTerminalRuleCall_1_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__4__Impl"


    // $ANTLR start "rule__Source__Group_1__5"
    // InternalMyDsl.g:2922:1: rule__Source__Group_1__5 : rule__Source__Group_1__5__Impl rule__Source__Group_1__6 ;
    public final void rule__Source__Group_1__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2926:1: ( rule__Source__Group_1__5__Impl rule__Source__Group_1__6 )
            // InternalMyDsl.g:2927:2: rule__Source__Group_1__5__Impl rule__Source__Group_1__6
            {
            pushFollow(FOLLOW_22);
            rule__Source__Group_1__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_1__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__5"


    // $ANTLR start "rule__Source__Group_1__5__Impl"
    // InternalMyDsl.g:2934:1: rule__Source__Group_1__5__Impl : ( RULE_COLON ) ;
    public final void rule__Source__Group_1__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2938:1: ( ( RULE_COLON ) )
            // InternalMyDsl.g:2939:1: ( RULE_COLON )
            {
            // InternalMyDsl.g:2939:1: ( RULE_COLON )
            // InternalMyDsl.g:2940:2: RULE_COLON
            {
             before(grammarAccess.getSourceAccess().getCOLONTerminalRuleCall_1_5()); 
            match(input,RULE_COLON,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getCOLONTerminalRuleCall_1_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__5__Impl"


    // $ANTLR start "rule__Source__Group_1__6"
    // InternalMyDsl.g:2949:1: rule__Source__Group_1__6 : rule__Source__Group_1__6__Impl rule__Source__Group_1__7 ;
    public final void rule__Source__Group_1__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2953:1: ( rule__Source__Group_1__6__Impl rule__Source__Group_1__7 )
            // InternalMyDsl.g:2954:2: rule__Source__Group_1__6__Impl rule__Source__Group_1__7
            {
            pushFollow(FOLLOW_17);
            rule__Source__Group_1__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_1__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__6"


    // $ANTLR start "rule__Source__Group_1__6__Impl"
    // InternalMyDsl.g:2961:1: rule__Source__Group_1__6__Impl : ( ( rule__Source__DataSourceAssignment_1_6 ) ) ;
    public final void rule__Source__Group_1__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2965:1: ( ( ( rule__Source__DataSourceAssignment_1_6 ) ) )
            // InternalMyDsl.g:2966:1: ( ( rule__Source__DataSourceAssignment_1_6 ) )
            {
            // InternalMyDsl.g:2966:1: ( ( rule__Source__DataSourceAssignment_1_6 ) )
            // InternalMyDsl.g:2967:2: ( rule__Source__DataSourceAssignment_1_6 )
            {
             before(grammarAccess.getSourceAccess().getDataSourceAssignment_1_6()); 
            // InternalMyDsl.g:2968:2: ( rule__Source__DataSourceAssignment_1_6 )
            // InternalMyDsl.g:2968:3: rule__Source__DataSourceAssignment_1_6
            {
            pushFollow(FOLLOW_2);
            rule__Source__DataSourceAssignment_1_6();

            state._fsp--;


            }

             after(grammarAccess.getSourceAccess().getDataSourceAssignment_1_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__6__Impl"


    // $ANTLR start "rule__Source__Group_1__7"
    // InternalMyDsl.g:2976:1: rule__Source__Group_1__7 : rule__Source__Group_1__7__Impl rule__Source__Group_1__8 ;
    public final void rule__Source__Group_1__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2980:1: ( rule__Source__Group_1__7__Impl rule__Source__Group_1__8 )
            // InternalMyDsl.g:2981:2: rule__Source__Group_1__7__Impl rule__Source__Group_1__8
            {
            pushFollow(FOLLOW_18);
            rule__Source__Group_1__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Source__Group_1__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__7"


    // $ANTLR start "rule__Source__Group_1__7__Impl"
    // InternalMyDsl.g:2988:1: rule__Source__Group_1__7__Impl : ( RULE_DOT ) ;
    public final void rule__Source__Group_1__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:2992:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:2993:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:2993:1: ( RULE_DOT )
            // InternalMyDsl.g:2994:2: RULE_DOT
            {
             before(grammarAccess.getSourceAccess().getDOTTerminalRuleCall_1_7()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getDOTTerminalRuleCall_1_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__7__Impl"


    // $ANTLR start "rule__Source__Group_1__8"
    // InternalMyDsl.g:3003:1: rule__Source__Group_1__8 : rule__Source__Group_1__8__Impl ;
    public final void rule__Source__Group_1__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3007:1: ( rule__Source__Group_1__8__Impl )
            // InternalMyDsl.g:3008:2: rule__Source__Group_1__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Source__Group_1__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__8"


    // $ANTLR start "rule__Source__Group_1__8__Impl"
    // InternalMyDsl.g:3014:1: rule__Source__Group_1__8__Impl : ( RULE_E ) ;
    public final void rule__Source__Group_1__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3018:1: ( ( RULE_E ) )
            // InternalMyDsl.g:3019:1: ( RULE_E )
            {
            // InternalMyDsl.g:3019:1: ( RULE_E )
            // InternalMyDsl.g:3020:2: RULE_E
            {
             before(grammarAccess.getSourceAccess().getETerminalRuleCall_1_8()); 
            match(input,RULE_E,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getETerminalRuleCall_1_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__Group_1__8__Impl"


    // $ANTLR start "rule__Prefix__Group_0__0"
    // InternalMyDsl.g:3030:1: rule__Prefix__Group_0__0 : rule__Prefix__Group_0__0__Impl rule__Prefix__Group_0__1 ;
    public final void rule__Prefix__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3034:1: ( rule__Prefix__Group_0__0__Impl rule__Prefix__Group_0__1 )
            // InternalMyDsl.g:3035:2: rule__Prefix__Group_0__0__Impl rule__Prefix__Group_0__1
            {
            pushFollow(FOLLOW_21);
            rule__Prefix__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_0__0"


    // $ANTLR start "rule__Prefix__Group_0__0__Impl"
    // InternalMyDsl.g:3042:1: rule__Prefix__Group_0__0__Impl : ( RULE_PRFX ) ;
    public final void rule__Prefix__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3046:1: ( ( RULE_PRFX ) )
            // InternalMyDsl.g:3047:1: ( RULE_PRFX )
            {
            // InternalMyDsl.g:3047:1: ( RULE_PRFX )
            // InternalMyDsl.g:3048:2: RULE_PRFX
            {
             before(grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_0_0()); 
            match(input,RULE_PRFX,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_0__0__Impl"


    // $ANTLR start "rule__Prefix__Group_0__1"
    // InternalMyDsl.g:3057:1: rule__Prefix__Group_0__1 : rule__Prefix__Group_0__1__Impl rule__Prefix__Group_0__2 ;
    public final void rule__Prefix__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3061:1: ( rule__Prefix__Group_0__1__Impl rule__Prefix__Group_0__2 )
            // InternalMyDsl.g:3062:2: rule__Prefix__Group_0__1__Impl rule__Prefix__Group_0__2
            {
            pushFollow(FOLLOW_23);
            rule__Prefix__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_0__1"


    // $ANTLR start "rule__Prefix__Group_0__1__Impl"
    // InternalMyDsl.g:3069:1: rule__Prefix__Group_0__1__Impl : ( ( rule__Prefix__TAssignment_0_1 ) ) ;
    public final void rule__Prefix__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3073:1: ( ( ( rule__Prefix__TAssignment_0_1 ) ) )
            // InternalMyDsl.g:3074:1: ( ( rule__Prefix__TAssignment_0_1 ) )
            {
            // InternalMyDsl.g:3074:1: ( ( rule__Prefix__TAssignment_0_1 ) )
            // InternalMyDsl.g:3075:2: ( rule__Prefix__TAssignment_0_1 )
            {
             before(grammarAccess.getPrefixAccess().getTAssignment_0_1()); 
            // InternalMyDsl.g:3076:2: ( rule__Prefix__TAssignment_0_1 )
            // InternalMyDsl.g:3076:3: rule__Prefix__TAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__TAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getPrefixAccess().getTAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_0__1__Impl"


    // $ANTLR start "rule__Prefix__Group_0__2"
    // InternalMyDsl.g:3084:1: rule__Prefix__Group_0__2 : rule__Prefix__Group_0__2__Impl rule__Prefix__Group_0__3 ;
    public final void rule__Prefix__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3088:1: ( rule__Prefix__Group_0__2__Impl rule__Prefix__Group_0__3 )
            // InternalMyDsl.g:3089:2: rule__Prefix__Group_0__2__Impl rule__Prefix__Group_0__3
            {
            pushFollow(FOLLOW_17);
            rule__Prefix__Group_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_0__2"


    // $ANTLR start "rule__Prefix__Group_0__2__Impl"
    // InternalMyDsl.g:3096:1: rule__Prefix__Group_0__2__Impl : ( ( rule__Prefix__IriStringAssignment_0_2 ) ) ;
    public final void rule__Prefix__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3100:1: ( ( ( rule__Prefix__IriStringAssignment_0_2 ) ) )
            // InternalMyDsl.g:3101:1: ( ( rule__Prefix__IriStringAssignment_0_2 ) )
            {
            // InternalMyDsl.g:3101:1: ( ( rule__Prefix__IriStringAssignment_0_2 ) )
            // InternalMyDsl.g:3102:2: ( rule__Prefix__IriStringAssignment_0_2 )
            {
             before(grammarAccess.getPrefixAccess().getIriStringAssignment_0_2()); 
            // InternalMyDsl.g:3103:2: ( rule__Prefix__IriStringAssignment_0_2 )
            // InternalMyDsl.g:3103:3: rule__Prefix__IriStringAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__IriStringAssignment_0_2();

            state._fsp--;


            }

             after(grammarAccess.getPrefixAccess().getIriStringAssignment_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_0__2__Impl"


    // $ANTLR start "rule__Prefix__Group_0__3"
    // InternalMyDsl.g:3111:1: rule__Prefix__Group_0__3 : rule__Prefix__Group_0__3__Impl ;
    public final void rule__Prefix__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3115:1: ( rule__Prefix__Group_0__3__Impl )
            // InternalMyDsl.g:3116:2: rule__Prefix__Group_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__Group_0__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_0__3"


    // $ANTLR start "rule__Prefix__Group_0__3__Impl"
    // InternalMyDsl.g:3122:1: rule__Prefix__Group_0__3__Impl : ( RULE_DOT ) ;
    public final void rule__Prefix__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3126:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:3127:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:3127:1: ( RULE_DOT )
            // InternalMyDsl.g:3128:2: RULE_DOT
            {
             before(grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_0_3()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_0__3__Impl"


    // $ANTLR start "rule__Prefix__Group_1__0"
    // InternalMyDsl.g:3138:1: rule__Prefix__Group_1__0 : rule__Prefix__Group_1__0__Impl rule__Prefix__Group_1__1 ;
    public final void rule__Prefix__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3142:1: ( rule__Prefix__Group_1__0__Impl rule__Prefix__Group_1__1 )
            // InternalMyDsl.g:3143:2: rule__Prefix__Group_1__0__Impl rule__Prefix__Group_1__1
            {
            pushFollow(FOLLOW_24);
            rule__Prefix__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_1__0"


    // $ANTLR start "rule__Prefix__Group_1__0__Impl"
    // InternalMyDsl.g:3150:1: rule__Prefix__Group_1__0__Impl : ( RULE_PRFX ) ;
    public final void rule__Prefix__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3154:1: ( ( RULE_PRFX ) )
            // InternalMyDsl.g:3155:1: ( RULE_PRFX )
            {
            // InternalMyDsl.g:3155:1: ( RULE_PRFX )
            // InternalMyDsl.g:3156:2: RULE_PRFX
            {
             before(grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_1_0()); 
            match(input,RULE_PRFX,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_1__0__Impl"


    // $ANTLR start "rule__Prefix__Group_1__1"
    // InternalMyDsl.g:3165:1: rule__Prefix__Group_1__1 : rule__Prefix__Group_1__1__Impl rule__Prefix__Group_1__2 ;
    public final void rule__Prefix__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3169:1: ( rule__Prefix__Group_1__1__Impl rule__Prefix__Group_1__2 )
            // InternalMyDsl.g:3170:2: rule__Prefix__Group_1__1__Impl rule__Prefix__Group_1__2
            {
            pushFollow(FOLLOW_23);
            rule__Prefix__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_1__1"


    // $ANTLR start "rule__Prefix__Group_1__1__Impl"
    // InternalMyDsl.g:3177:1: rule__Prefix__Group_1__1__Impl : ( ( rule__Prefix__TAssignment_1_1 ) ) ;
    public final void rule__Prefix__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3181:1: ( ( ( rule__Prefix__TAssignment_1_1 ) ) )
            // InternalMyDsl.g:3182:1: ( ( rule__Prefix__TAssignment_1_1 ) )
            {
            // InternalMyDsl.g:3182:1: ( ( rule__Prefix__TAssignment_1_1 ) )
            // InternalMyDsl.g:3183:2: ( rule__Prefix__TAssignment_1_1 )
            {
             before(grammarAccess.getPrefixAccess().getTAssignment_1_1()); 
            // InternalMyDsl.g:3184:2: ( rule__Prefix__TAssignment_1_1 )
            // InternalMyDsl.g:3184:3: rule__Prefix__TAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__TAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getPrefixAccess().getTAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_1__1__Impl"


    // $ANTLR start "rule__Prefix__Group_1__2"
    // InternalMyDsl.g:3192:1: rule__Prefix__Group_1__2 : rule__Prefix__Group_1__2__Impl rule__Prefix__Group_1__3 ;
    public final void rule__Prefix__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3196:1: ( rule__Prefix__Group_1__2__Impl rule__Prefix__Group_1__3 )
            // InternalMyDsl.g:3197:2: rule__Prefix__Group_1__2__Impl rule__Prefix__Group_1__3
            {
            pushFollow(FOLLOW_17);
            rule__Prefix__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_1__2"


    // $ANTLR start "rule__Prefix__Group_1__2__Impl"
    // InternalMyDsl.g:3204:1: rule__Prefix__Group_1__2__Impl : ( ( rule__Prefix__IriStringAssignment_1_2 ) ) ;
    public final void rule__Prefix__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3208:1: ( ( ( rule__Prefix__IriStringAssignment_1_2 ) ) )
            // InternalMyDsl.g:3209:1: ( ( rule__Prefix__IriStringAssignment_1_2 ) )
            {
            // InternalMyDsl.g:3209:1: ( ( rule__Prefix__IriStringAssignment_1_2 ) )
            // InternalMyDsl.g:3210:2: ( rule__Prefix__IriStringAssignment_1_2 )
            {
             before(grammarAccess.getPrefixAccess().getIriStringAssignment_1_2()); 
            // InternalMyDsl.g:3211:2: ( rule__Prefix__IriStringAssignment_1_2 )
            // InternalMyDsl.g:3211:3: rule__Prefix__IriStringAssignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__IriStringAssignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getPrefixAccess().getIriStringAssignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_1__2__Impl"


    // $ANTLR start "rule__Prefix__Group_1__3"
    // InternalMyDsl.g:3219:1: rule__Prefix__Group_1__3 : rule__Prefix__Group_1__3__Impl ;
    public final void rule__Prefix__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3223:1: ( rule__Prefix__Group_1__3__Impl )
            // InternalMyDsl.g:3224:2: rule__Prefix__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__Group_1__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_1__3"


    // $ANTLR start "rule__Prefix__Group_1__3__Impl"
    // InternalMyDsl.g:3230:1: rule__Prefix__Group_1__3__Impl : ( RULE_DOT ) ;
    public final void rule__Prefix__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3234:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:3235:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:3235:1: ( RULE_DOT )
            // InternalMyDsl.g:3236:2: RULE_DOT
            {
             before(grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_1_3()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_1__3__Impl"


    // $ANTLR start "rule__Prefix__Group_2__0"
    // InternalMyDsl.g:3246:1: rule__Prefix__Group_2__0 : rule__Prefix__Group_2__0__Impl rule__Prefix__Group_2__1 ;
    public final void rule__Prefix__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3250:1: ( rule__Prefix__Group_2__0__Impl rule__Prefix__Group_2__1 )
            // InternalMyDsl.g:3251:2: rule__Prefix__Group_2__0__Impl rule__Prefix__Group_2__1
            {
            pushFollow(FOLLOW_21);
            rule__Prefix__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__0"


    // $ANTLR start "rule__Prefix__Group_2__0__Impl"
    // InternalMyDsl.g:3258:1: rule__Prefix__Group_2__0__Impl : ( RULE_PRFX ) ;
    public final void rule__Prefix__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3262:1: ( ( RULE_PRFX ) )
            // InternalMyDsl.g:3263:1: ( RULE_PRFX )
            {
            // InternalMyDsl.g:3263:1: ( RULE_PRFX )
            // InternalMyDsl.g:3264:2: RULE_PRFX
            {
             before(grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_2_0()); 
            match(input,RULE_PRFX,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__0__Impl"


    // $ANTLR start "rule__Prefix__Group_2__1"
    // InternalMyDsl.g:3273:1: rule__Prefix__Group_2__1 : rule__Prefix__Group_2__1__Impl rule__Prefix__Group_2__2 ;
    public final void rule__Prefix__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3277:1: ( rule__Prefix__Group_2__1__Impl rule__Prefix__Group_2__2 )
            // InternalMyDsl.g:3278:2: rule__Prefix__Group_2__1__Impl rule__Prefix__Group_2__2
            {
            pushFollow(FOLLOW_23);
            rule__Prefix__Group_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__1"


    // $ANTLR start "rule__Prefix__Group_2__1__Impl"
    // InternalMyDsl.g:3285:1: rule__Prefix__Group_2__1__Impl : ( ( rule__Prefix__TAssignment_2_1 ) ) ;
    public final void rule__Prefix__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3289:1: ( ( ( rule__Prefix__TAssignment_2_1 ) ) )
            // InternalMyDsl.g:3290:1: ( ( rule__Prefix__TAssignment_2_1 ) )
            {
            // InternalMyDsl.g:3290:1: ( ( rule__Prefix__TAssignment_2_1 ) )
            // InternalMyDsl.g:3291:2: ( rule__Prefix__TAssignment_2_1 )
            {
             before(grammarAccess.getPrefixAccess().getTAssignment_2_1()); 
            // InternalMyDsl.g:3292:2: ( rule__Prefix__TAssignment_2_1 )
            // InternalMyDsl.g:3292:3: rule__Prefix__TAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__TAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getPrefixAccess().getTAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__1__Impl"


    // $ANTLR start "rule__Prefix__Group_2__2"
    // InternalMyDsl.g:3300:1: rule__Prefix__Group_2__2 : rule__Prefix__Group_2__2__Impl rule__Prefix__Group_2__3 ;
    public final void rule__Prefix__Group_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3304:1: ( rule__Prefix__Group_2__2__Impl rule__Prefix__Group_2__3 )
            // InternalMyDsl.g:3305:2: rule__Prefix__Group_2__2__Impl rule__Prefix__Group_2__3
            {
            pushFollow(FOLLOW_17);
            rule__Prefix__Group_2__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_2__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__2"


    // $ANTLR start "rule__Prefix__Group_2__2__Impl"
    // InternalMyDsl.g:3312:1: rule__Prefix__Group_2__2__Impl : ( ( rule__Prefix__IriStringAssignment_2_2 ) ) ;
    public final void rule__Prefix__Group_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3316:1: ( ( ( rule__Prefix__IriStringAssignment_2_2 ) ) )
            // InternalMyDsl.g:3317:1: ( ( rule__Prefix__IriStringAssignment_2_2 ) )
            {
            // InternalMyDsl.g:3317:1: ( ( rule__Prefix__IriStringAssignment_2_2 ) )
            // InternalMyDsl.g:3318:2: ( rule__Prefix__IriStringAssignment_2_2 )
            {
             before(grammarAccess.getPrefixAccess().getIriStringAssignment_2_2()); 
            // InternalMyDsl.g:3319:2: ( rule__Prefix__IriStringAssignment_2_2 )
            // InternalMyDsl.g:3319:3: rule__Prefix__IriStringAssignment_2_2
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__IriStringAssignment_2_2();

            state._fsp--;


            }

             after(grammarAccess.getPrefixAccess().getIriStringAssignment_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__2__Impl"


    // $ANTLR start "rule__Prefix__Group_2__3"
    // InternalMyDsl.g:3327:1: rule__Prefix__Group_2__3 : rule__Prefix__Group_2__3__Impl rule__Prefix__Group_2__4 ;
    public final void rule__Prefix__Group_2__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3331:1: ( rule__Prefix__Group_2__3__Impl rule__Prefix__Group_2__4 )
            // InternalMyDsl.g:3332:2: rule__Prefix__Group_2__3__Impl rule__Prefix__Group_2__4
            {
            pushFollow(FOLLOW_18);
            rule__Prefix__Group_2__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_2__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__3"


    // $ANTLR start "rule__Prefix__Group_2__3__Impl"
    // InternalMyDsl.g:3339:1: rule__Prefix__Group_2__3__Impl : ( RULE_DOT ) ;
    public final void rule__Prefix__Group_2__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3343:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:3344:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:3344:1: ( RULE_DOT )
            // InternalMyDsl.g:3345:2: RULE_DOT
            {
             before(grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_2_3()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_2_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__3__Impl"


    // $ANTLR start "rule__Prefix__Group_2__4"
    // InternalMyDsl.g:3354:1: rule__Prefix__Group_2__4 : rule__Prefix__Group_2__4__Impl ;
    public final void rule__Prefix__Group_2__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3358:1: ( rule__Prefix__Group_2__4__Impl )
            // InternalMyDsl.g:3359:2: rule__Prefix__Group_2__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__Group_2__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__4"


    // $ANTLR start "rule__Prefix__Group_2__4__Impl"
    // InternalMyDsl.g:3365:1: rule__Prefix__Group_2__4__Impl : ( RULE_E ) ;
    public final void rule__Prefix__Group_2__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3369:1: ( ( RULE_E ) )
            // InternalMyDsl.g:3370:1: ( RULE_E )
            {
            // InternalMyDsl.g:3370:1: ( RULE_E )
            // InternalMyDsl.g:3371:2: RULE_E
            {
             before(grammarAccess.getPrefixAccess().getETerminalRuleCall_2_4()); 
            match(input,RULE_E,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getETerminalRuleCall_2_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_2__4__Impl"


    // $ANTLR start "rule__Prefix__Group_3__0"
    // InternalMyDsl.g:3381:1: rule__Prefix__Group_3__0 : rule__Prefix__Group_3__0__Impl rule__Prefix__Group_3__1 ;
    public final void rule__Prefix__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3385:1: ( rule__Prefix__Group_3__0__Impl rule__Prefix__Group_3__1 )
            // InternalMyDsl.g:3386:2: rule__Prefix__Group_3__0__Impl rule__Prefix__Group_3__1
            {
            pushFollow(FOLLOW_24);
            rule__Prefix__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__0"


    // $ANTLR start "rule__Prefix__Group_3__0__Impl"
    // InternalMyDsl.g:3393:1: rule__Prefix__Group_3__0__Impl : ( RULE_PRFX ) ;
    public final void rule__Prefix__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3397:1: ( ( RULE_PRFX ) )
            // InternalMyDsl.g:3398:1: ( RULE_PRFX )
            {
            // InternalMyDsl.g:3398:1: ( RULE_PRFX )
            // InternalMyDsl.g:3399:2: RULE_PRFX
            {
             before(grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_3_0()); 
            match(input,RULE_PRFX,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getPRFXTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__0__Impl"


    // $ANTLR start "rule__Prefix__Group_3__1"
    // InternalMyDsl.g:3408:1: rule__Prefix__Group_3__1 : rule__Prefix__Group_3__1__Impl rule__Prefix__Group_3__2 ;
    public final void rule__Prefix__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3412:1: ( rule__Prefix__Group_3__1__Impl rule__Prefix__Group_3__2 )
            // InternalMyDsl.g:3413:2: rule__Prefix__Group_3__1__Impl rule__Prefix__Group_3__2
            {
            pushFollow(FOLLOW_23);
            rule__Prefix__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__1"


    // $ANTLR start "rule__Prefix__Group_3__1__Impl"
    // InternalMyDsl.g:3420:1: rule__Prefix__Group_3__1__Impl : ( ( rule__Prefix__TAssignment_3_1 ) ) ;
    public final void rule__Prefix__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3424:1: ( ( ( rule__Prefix__TAssignment_3_1 ) ) )
            // InternalMyDsl.g:3425:1: ( ( rule__Prefix__TAssignment_3_1 ) )
            {
            // InternalMyDsl.g:3425:1: ( ( rule__Prefix__TAssignment_3_1 ) )
            // InternalMyDsl.g:3426:2: ( rule__Prefix__TAssignment_3_1 )
            {
             before(grammarAccess.getPrefixAccess().getTAssignment_3_1()); 
            // InternalMyDsl.g:3427:2: ( rule__Prefix__TAssignment_3_1 )
            // InternalMyDsl.g:3427:3: rule__Prefix__TAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__TAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getPrefixAccess().getTAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__1__Impl"


    // $ANTLR start "rule__Prefix__Group_3__2"
    // InternalMyDsl.g:3435:1: rule__Prefix__Group_3__2 : rule__Prefix__Group_3__2__Impl rule__Prefix__Group_3__3 ;
    public final void rule__Prefix__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3439:1: ( rule__Prefix__Group_3__2__Impl rule__Prefix__Group_3__3 )
            // InternalMyDsl.g:3440:2: rule__Prefix__Group_3__2__Impl rule__Prefix__Group_3__3
            {
            pushFollow(FOLLOW_17);
            rule__Prefix__Group_3__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_3__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__2"


    // $ANTLR start "rule__Prefix__Group_3__2__Impl"
    // InternalMyDsl.g:3447:1: rule__Prefix__Group_3__2__Impl : ( ( rule__Prefix__IriStringAssignment_3_2 ) ) ;
    public final void rule__Prefix__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3451:1: ( ( ( rule__Prefix__IriStringAssignment_3_2 ) ) )
            // InternalMyDsl.g:3452:1: ( ( rule__Prefix__IriStringAssignment_3_2 ) )
            {
            // InternalMyDsl.g:3452:1: ( ( rule__Prefix__IriStringAssignment_3_2 ) )
            // InternalMyDsl.g:3453:2: ( rule__Prefix__IriStringAssignment_3_2 )
            {
             before(grammarAccess.getPrefixAccess().getIriStringAssignment_3_2()); 
            // InternalMyDsl.g:3454:2: ( rule__Prefix__IriStringAssignment_3_2 )
            // InternalMyDsl.g:3454:3: rule__Prefix__IriStringAssignment_3_2
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__IriStringAssignment_3_2();

            state._fsp--;


            }

             after(grammarAccess.getPrefixAccess().getIriStringAssignment_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__2__Impl"


    // $ANTLR start "rule__Prefix__Group_3__3"
    // InternalMyDsl.g:3462:1: rule__Prefix__Group_3__3 : rule__Prefix__Group_3__3__Impl rule__Prefix__Group_3__4 ;
    public final void rule__Prefix__Group_3__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3466:1: ( rule__Prefix__Group_3__3__Impl rule__Prefix__Group_3__4 )
            // InternalMyDsl.g:3467:2: rule__Prefix__Group_3__3__Impl rule__Prefix__Group_3__4
            {
            pushFollow(FOLLOW_18);
            rule__Prefix__Group_3__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Prefix__Group_3__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__3"


    // $ANTLR start "rule__Prefix__Group_3__3__Impl"
    // InternalMyDsl.g:3474:1: rule__Prefix__Group_3__3__Impl : ( RULE_DOT ) ;
    public final void rule__Prefix__Group_3__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3478:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:3479:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:3479:1: ( RULE_DOT )
            // InternalMyDsl.g:3480:2: RULE_DOT
            {
             before(grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_3_3()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getDOTTerminalRuleCall_3_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__3__Impl"


    // $ANTLR start "rule__Prefix__Group_3__4"
    // InternalMyDsl.g:3489:1: rule__Prefix__Group_3__4 : rule__Prefix__Group_3__4__Impl ;
    public final void rule__Prefix__Group_3__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3493:1: ( rule__Prefix__Group_3__4__Impl )
            // InternalMyDsl.g:3494:2: rule__Prefix__Group_3__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Prefix__Group_3__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__4"


    // $ANTLR start "rule__Prefix__Group_3__4__Impl"
    // InternalMyDsl.g:3500:1: rule__Prefix__Group_3__4__Impl : ( RULE_E ) ;
    public final void rule__Prefix__Group_3__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3504:1: ( ( RULE_E ) )
            // InternalMyDsl.g:3505:1: ( RULE_E )
            {
            // InternalMyDsl.g:3505:1: ( RULE_E )
            // InternalMyDsl.g:3506:2: RULE_E
            {
             before(grammarAccess.getPrefixAccess().getETerminalRuleCall_3_4()); 
            match(input,RULE_E,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getETerminalRuleCall_3_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__Group_3__4__Impl"


    // $ANTLR start "rule__Base__Group_0__0"
    // InternalMyDsl.g:3516:1: rule__Base__Group_0__0 : rule__Base__Group_0__0__Impl rule__Base__Group_0__1 ;
    public final void rule__Base__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3520:1: ( rule__Base__Group_0__0__Impl rule__Base__Group_0__1 )
            // InternalMyDsl.g:3521:2: rule__Base__Group_0__0__Impl rule__Base__Group_0__1
            {
            pushFollow(FOLLOW_23);
            rule__Base__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Base__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_0__0"


    // $ANTLR start "rule__Base__Group_0__0__Impl"
    // InternalMyDsl.g:3528:1: rule__Base__Group_0__0__Impl : ( RULE_BS ) ;
    public final void rule__Base__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3532:1: ( ( RULE_BS ) )
            // InternalMyDsl.g:3533:1: ( RULE_BS )
            {
            // InternalMyDsl.g:3533:1: ( RULE_BS )
            // InternalMyDsl.g:3534:2: RULE_BS
            {
             before(grammarAccess.getBaseAccess().getBSTerminalRuleCall_0_0()); 
            match(input,RULE_BS,FOLLOW_2); 
             after(grammarAccess.getBaseAccess().getBSTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_0__0__Impl"


    // $ANTLR start "rule__Base__Group_0__1"
    // InternalMyDsl.g:3543:1: rule__Base__Group_0__1 : rule__Base__Group_0__1__Impl rule__Base__Group_0__2 ;
    public final void rule__Base__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3547:1: ( rule__Base__Group_0__1__Impl rule__Base__Group_0__2 )
            // InternalMyDsl.g:3548:2: rule__Base__Group_0__1__Impl rule__Base__Group_0__2
            {
            pushFollow(FOLLOW_17);
            rule__Base__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Base__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_0__1"


    // $ANTLR start "rule__Base__Group_0__1__Impl"
    // InternalMyDsl.g:3555:1: rule__Base__Group_0__1__Impl : ( ( rule__Base__IriStringAssignment_0_1 ) ) ;
    public final void rule__Base__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3559:1: ( ( ( rule__Base__IriStringAssignment_0_1 ) ) )
            // InternalMyDsl.g:3560:1: ( ( rule__Base__IriStringAssignment_0_1 ) )
            {
            // InternalMyDsl.g:3560:1: ( ( rule__Base__IriStringAssignment_0_1 ) )
            // InternalMyDsl.g:3561:2: ( rule__Base__IriStringAssignment_0_1 )
            {
             before(grammarAccess.getBaseAccess().getIriStringAssignment_0_1()); 
            // InternalMyDsl.g:3562:2: ( rule__Base__IriStringAssignment_0_1 )
            // InternalMyDsl.g:3562:3: rule__Base__IriStringAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Base__IriStringAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getBaseAccess().getIriStringAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_0__1__Impl"


    // $ANTLR start "rule__Base__Group_0__2"
    // InternalMyDsl.g:3570:1: rule__Base__Group_0__2 : rule__Base__Group_0__2__Impl ;
    public final void rule__Base__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3574:1: ( rule__Base__Group_0__2__Impl )
            // InternalMyDsl.g:3575:2: rule__Base__Group_0__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Base__Group_0__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_0__2"


    // $ANTLR start "rule__Base__Group_0__2__Impl"
    // InternalMyDsl.g:3581:1: rule__Base__Group_0__2__Impl : ( RULE_DOT ) ;
    public final void rule__Base__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3585:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:3586:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:3586:1: ( RULE_DOT )
            // InternalMyDsl.g:3587:2: RULE_DOT
            {
             before(grammarAccess.getBaseAccess().getDOTTerminalRuleCall_0_2()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getBaseAccess().getDOTTerminalRuleCall_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_0__2__Impl"


    // $ANTLR start "rule__Base__Group_1__0"
    // InternalMyDsl.g:3597:1: rule__Base__Group_1__0 : rule__Base__Group_1__0__Impl rule__Base__Group_1__1 ;
    public final void rule__Base__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3601:1: ( rule__Base__Group_1__0__Impl rule__Base__Group_1__1 )
            // InternalMyDsl.g:3602:2: rule__Base__Group_1__0__Impl rule__Base__Group_1__1
            {
            pushFollow(FOLLOW_23);
            rule__Base__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Base__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_1__0"


    // $ANTLR start "rule__Base__Group_1__0__Impl"
    // InternalMyDsl.g:3609:1: rule__Base__Group_1__0__Impl : ( RULE_BS ) ;
    public final void rule__Base__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3613:1: ( ( RULE_BS ) )
            // InternalMyDsl.g:3614:1: ( RULE_BS )
            {
            // InternalMyDsl.g:3614:1: ( RULE_BS )
            // InternalMyDsl.g:3615:2: RULE_BS
            {
             before(grammarAccess.getBaseAccess().getBSTerminalRuleCall_1_0()); 
            match(input,RULE_BS,FOLLOW_2); 
             after(grammarAccess.getBaseAccess().getBSTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_1__0__Impl"


    // $ANTLR start "rule__Base__Group_1__1"
    // InternalMyDsl.g:3624:1: rule__Base__Group_1__1 : rule__Base__Group_1__1__Impl rule__Base__Group_1__2 ;
    public final void rule__Base__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3628:1: ( rule__Base__Group_1__1__Impl rule__Base__Group_1__2 )
            // InternalMyDsl.g:3629:2: rule__Base__Group_1__1__Impl rule__Base__Group_1__2
            {
            pushFollow(FOLLOW_17);
            rule__Base__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Base__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_1__1"


    // $ANTLR start "rule__Base__Group_1__1__Impl"
    // InternalMyDsl.g:3636:1: rule__Base__Group_1__1__Impl : ( ( rule__Base__IriStringAssignment_1_1 ) ) ;
    public final void rule__Base__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3640:1: ( ( ( rule__Base__IriStringAssignment_1_1 ) ) )
            // InternalMyDsl.g:3641:1: ( ( rule__Base__IriStringAssignment_1_1 ) )
            {
            // InternalMyDsl.g:3641:1: ( ( rule__Base__IriStringAssignment_1_1 ) )
            // InternalMyDsl.g:3642:2: ( rule__Base__IriStringAssignment_1_1 )
            {
             before(grammarAccess.getBaseAccess().getIriStringAssignment_1_1()); 
            // InternalMyDsl.g:3643:2: ( rule__Base__IriStringAssignment_1_1 )
            // InternalMyDsl.g:3643:3: rule__Base__IriStringAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__Base__IriStringAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getBaseAccess().getIriStringAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_1__1__Impl"


    // $ANTLR start "rule__Base__Group_1__2"
    // InternalMyDsl.g:3651:1: rule__Base__Group_1__2 : rule__Base__Group_1__2__Impl rule__Base__Group_1__3 ;
    public final void rule__Base__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3655:1: ( rule__Base__Group_1__2__Impl rule__Base__Group_1__3 )
            // InternalMyDsl.g:3656:2: rule__Base__Group_1__2__Impl rule__Base__Group_1__3
            {
            pushFollow(FOLLOW_18);
            rule__Base__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Base__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_1__2"


    // $ANTLR start "rule__Base__Group_1__2__Impl"
    // InternalMyDsl.g:3663:1: rule__Base__Group_1__2__Impl : ( RULE_DOT ) ;
    public final void rule__Base__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3667:1: ( ( RULE_DOT ) )
            // InternalMyDsl.g:3668:1: ( RULE_DOT )
            {
            // InternalMyDsl.g:3668:1: ( RULE_DOT )
            // InternalMyDsl.g:3669:2: RULE_DOT
            {
             before(grammarAccess.getBaseAccess().getDOTTerminalRuleCall_1_2()); 
            match(input,RULE_DOT,FOLLOW_2); 
             after(grammarAccess.getBaseAccess().getDOTTerminalRuleCall_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_1__2__Impl"


    // $ANTLR start "rule__Base__Group_1__3"
    // InternalMyDsl.g:3678:1: rule__Base__Group_1__3 : rule__Base__Group_1__3__Impl ;
    public final void rule__Base__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3682:1: ( rule__Base__Group_1__3__Impl )
            // InternalMyDsl.g:3683:2: rule__Base__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Base__Group_1__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_1__3"


    // $ANTLR start "rule__Base__Group_1__3__Impl"
    // InternalMyDsl.g:3689:1: rule__Base__Group_1__3__Impl : ( RULE_E ) ;
    public final void rule__Base__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3693:1: ( ( RULE_E ) )
            // InternalMyDsl.g:3694:1: ( RULE_E )
            {
            // InternalMyDsl.g:3694:1: ( RULE_E )
            // InternalMyDsl.g:3695:2: RULE_E
            {
             before(grammarAccess.getBaseAccess().getETerminalRuleCall_1_3()); 
            match(input,RULE_E,FOLLOW_2); 
             after(grammarAccess.getBaseAccess().getETerminalRuleCall_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__Group_1__3__Impl"


    // $ANTLR start "rule__Model__BAssignment_0"
    // InternalMyDsl.g:3705:1: rule__Model__BAssignment_0 : ( ruleBase ) ;
    public final void rule__Model__BAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3709:1: ( ( ruleBase ) )
            // InternalMyDsl.g:3710:2: ( ruleBase )
            {
            // InternalMyDsl.g:3710:2: ( ruleBase )
            // InternalMyDsl.g:3711:3: ruleBase
            {
             before(grammarAccess.getModelAccess().getBBaseParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleBase();

            state._fsp--;

             after(grammarAccess.getModelAccess().getBBaseParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__BAssignment_0"


    // $ANTLR start "rule__Model__PAssignment_1"
    // InternalMyDsl.g:3720:1: rule__Model__PAssignment_1 : ( rulePrefix ) ;
    public final void rule__Model__PAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3724:1: ( ( rulePrefix ) )
            // InternalMyDsl.g:3725:2: ( rulePrefix )
            {
            // InternalMyDsl.g:3725:2: ( rulePrefix )
            // InternalMyDsl.g:3726:3: rulePrefix
            {
             before(grammarAccess.getModelAccess().getPPrefixParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            rulePrefix();

            state._fsp--;

             after(grammarAccess.getModelAccess().getPPrefixParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__PAssignment_1"


    // $ANTLR start "rule__Model__SAssignment_2"
    // InternalMyDsl.g:3735:1: rule__Model__SAssignment_2 : ( ruleSource ) ;
    public final void rule__Model__SAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3739:1: ( ( ruleSource ) )
            // InternalMyDsl.g:3740:2: ( ruleSource )
            {
            // InternalMyDsl.g:3740:2: ( ruleSource )
            // InternalMyDsl.g:3741:3: ruleSource
            {
             before(grammarAccess.getModelAccess().getSSourceParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSource();

            state._fsp--;

             after(grammarAccess.getModelAccess().getSSourceParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__SAssignment_2"


    // $ANTLR start "rule__Model__StAssignment_3"
    // InternalMyDsl.g:3750:1: rule__Model__StAssignment_3 : ( ruleStatement ) ;
    public final void rule__Model__StAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3754:1: ( ( ruleStatement ) )
            // InternalMyDsl.g:3755:2: ( ruleStatement )
            {
            // InternalMyDsl.g:3755:2: ( ruleStatement )
            // InternalMyDsl.g:3756:3: ruleStatement
            {
             before(grammarAccess.getModelAccess().getStStatementParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleStatement();

            state._fsp--;

             after(grammarAccess.getModelAccess().getStStatementParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__StAssignment_3"


    // $ANTLR start "rule__PrefixedName__TAssignment"
    // InternalMyDsl.g:3765:1: rule__PrefixedName__TAssignment : ( RULE_PNAME_LN ) ;
    public final void rule__PrefixedName__TAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3769:1: ( ( RULE_PNAME_LN ) )
            // InternalMyDsl.g:3770:2: ( RULE_PNAME_LN )
            {
            // InternalMyDsl.g:3770:2: ( RULE_PNAME_LN )
            // InternalMyDsl.g:3771:3: RULE_PNAME_LN
            {
             before(grammarAccess.getPrefixedNameAccess().getTPNAME_LNTerminalRuleCall_0()); 
            match(input,RULE_PNAME_LN,FOLLOW_2); 
             after(grammarAccess.getPrefixedNameAccess().getTPNAME_LNTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrefixedName__TAssignment"


    // $ANTLR start "rule__IRIREF__TAssignment"
    // InternalMyDsl.g:3780:1: rule__IRIREF__TAssignment : ( RULE_IRI ) ;
    public final void rule__IRIREF__TAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3784:1: ( ( RULE_IRI ) )
            // InternalMyDsl.g:3785:2: ( RULE_IRI )
            {
            // InternalMyDsl.g:3785:2: ( RULE_IRI )
            // InternalMyDsl.g:3786:3: RULE_IRI
            {
             before(grammarAccess.getIRIREFAccess().getTIRITerminalRuleCall_0()); 
            match(input,RULE_IRI,FOLLOW_2); 
             after(grammarAccess.getIRIREFAccess().getTIRITerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IRIREF__TAssignment"


    // $ANTLR start "rule__IRIBOL__TAssignment_0"
    // InternalMyDsl.g:3795:1: rule__IRIBOL__TAssignment_0 : ( ruleIRIREF ) ;
    public final void rule__IRIBOL__TAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3799:1: ( ( ruleIRIREF ) )
            // InternalMyDsl.g:3800:2: ( ruleIRIREF )
            {
            // InternalMyDsl.g:3800:2: ( ruleIRIREF )
            // InternalMyDsl.g:3801:3: ruleIRIREF
            {
             before(grammarAccess.getIRIBOLAccess().getTIRIREFParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIREF();

            state._fsp--;

             after(grammarAccess.getIRIBOLAccess().getTIRIREFParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IRIBOL__TAssignment_0"


    // $ANTLR start "rule__IRIBOL__TAssignment_1"
    // InternalMyDsl.g:3810:1: rule__IRIBOL__TAssignment_1 : ( rulePrefixedName ) ;
    public final void rule__IRIBOL__TAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3814:1: ( ( rulePrefixedName ) )
            // InternalMyDsl.g:3815:2: ( rulePrefixedName )
            {
            // InternalMyDsl.g:3815:2: ( rulePrefixedName )
            // InternalMyDsl.g:3816:3: rulePrefixedName
            {
             before(grammarAccess.getIRIBOLAccess().getTPrefixedNameParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            rulePrefixedName();

            state._fsp--;

             after(grammarAccess.getIRIBOLAccess().getTPrefixedNameParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__IRIBOL__TAssignment_1"


    // $ANTLR start "rule__Striing__TAssignment_0"
    // InternalMyDsl.g:3825:1: rule__Striing__TAssignment_0 : ( RULE_STRING_LITERAL1 ) ;
    public final void rule__Striing__TAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3829:1: ( ( RULE_STRING_LITERAL1 ) )
            // InternalMyDsl.g:3830:2: ( RULE_STRING_LITERAL1 )
            {
            // InternalMyDsl.g:3830:2: ( RULE_STRING_LITERAL1 )
            // InternalMyDsl.g:3831:3: RULE_STRING_LITERAL1
            {
             before(grammarAccess.getStriingAccess().getTSTRING_LITERAL1TerminalRuleCall_0_0()); 
            match(input,RULE_STRING_LITERAL1,FOLLOW_2); 
             after(grammarAccess.getStriingAccess().getTSTRING_LITERAL1TerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Striing__TAssignment_0"


    // $ANTLR start "rule__Striing__TAssignment_1"
    // InternalMyDsl.g:3840:1: rule__Striing__TAssignment_1 : ( RULE_STRING_LITERAL2 ) ;
    public final void rule__Striing__TAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3844:1: ( ( RULE_STRING_LITERAL2 ) )
            // InternalMyDsl.g:3845:2: ( RULE_STRING_LITERAL2 )
            {
            // InternalMyDsl.g:3845:2: ( RULE_STRING_LITERAL2 )
            // InternalMyDsl.g:3846:3: RULE_STRING_LITERAL2
            {
             before(grammarAccess.getStriingAccess().getTSTRING_LITERAL2TerminalRuleCall_1_0()); 
            match(input,RULE_STRING_LITERAL2,FOLLOW_2); 
             after(grammarAccess.getStriingAccess().getTSTRING_LITERAL2TerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Striing__TAssignment_1"


    // $ANTLR start "rule__Striing__TAssignment_2"
    // InternalMyDsl.g:3855:1: rule__Striing__TAssignment_2 : ( RULE_STRING_LITERAL_LONG1 ) ;
    public final void rule__Striing__TAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3859:1: ( ( RULE_STRING_LITERAL_LONG1 ) )
            // InternalMyDsl.g:3860:2: ( RULE_STRING_LITERAL_LONG1 )
            {
            // InternalMyDsl.g:3860:2: ( RULE_STRING_LITERAL_LONG1 )
            // InternalMyDsl.g:3861:3: RULE_STRING_LITERAL_LONG1
            {
             before(grammarAccess.getStriingAccess().getTSTRING_LITERAL_LONG1TerminalRuleCall_2_0()); 
            match(input,RULE_STRING_LITERAL_LONG1,FOLLOW_2); 
             after(grammarAccess.getStriingAccess().getTSTRING_LITERAL_LONG1TerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Striing__TAssignment_2"


    // $ANTLR start "rule__Striing__TAssignment_3"
    // InternalMyDsl.g:3870:1: rule__Striing__TAssignment_3 : ( RULE_STRING_LITERAL_LONG2 ) ;
    public final void rule__Striing__TAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3874:1: ( ( RULE_STRING_LITERAL_LONG2 ) )
            // InternalMyDsl.g:3875:2: ( RULE_STRING_LITERAL_LONG2 )
            {
            // InternalMyDsl.g:3875:2: ( RULE_STRING_LITERAL_LONG2 )
            // InternalMyDsl.g:3876:3: RULE_STRING_LITERAL_LONG2
            {
             before(grammarAccess.getStriingAccess().getTSTRING_LITERAL_LONG2TerminalRuleCall_3_0()); 
            match(input,RULE_STRING_LITERAL_LONG2,FOLLOW_2); 
             after(grammarAccess.getStriingAccess().getTSTRING_LITERAL_LONG2TerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Striing__TAssignment_3"


    // $ANTLR start "rule__Langtagg__TAssignment"
    // InternalMyDsl.g:3885:1: rule__Langtagg__TAssignment : ( RULE_LANGTAG ) ;
    public final void rule__Langtagg__TAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3889:1: ( ( RULE_LANGTAG ) )
            // InternalMyDsl.g:3890:2: ( RULE_LANGTAG )
            {
            // InternalMyDsl.g:3890:2: ( RULE_LANGTAG )
            // InternalMyDsl.g:3891:3: RULE_LANGTAG
            {
             before(grammarAccess.getLangtaggAccess().getTLANGTAGTerminalRuleCall_0()); 
            match(input,RULE_LANGTAG,FOLLOW_2); 
             after(grammarAccess.getLangtaggAccess().getTLANGTAGTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Langtagg__TAssignment"


    // $ANTLR start "rule__RDFLiteral__SAssignment_0"
    // InternalMyDsl.g:3900:1: rule__RDFLiteral__SAssignment_0 : ( ruleStriing ) ;
    public final void rule__RDFLiteral__SAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3904:1: ( ( ruleStriing ) )
            // InternalMyDsl.g:3905:2: ( ruleStriing )
            {
            // InternalMyDsl.g:3905:2: ( ruleStriing )
            // InternalMyDsl.g:3906:3: ruleStriing
            {
             before(grammarAccess.getRDFLiteralAccess().getSStriingParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleStriing();

            state._fsp--;

             after(grammarAccess.getRDFLiteralAccess().getSStriingParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__SAssignment_0"


    // $ANTLR start "rule__RDFLiteral__LAssignment_1_0"
    // InternalMyDsl.g:3915:1: rule__RDFLiteral__LAssignment_1_0 : ( ruleLangtagg ) ;
    public final void rule__RDFLiteral__LAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3919:1: ( ( ruleLangtagg ) )
            // InternalMyDsl.g:3920:2: ( ruleLangtagg )
            {
            // InternalMyDsl.g:3920:2: ( ruleLangtagg )
            // InternalMyDsl.g:3921:3: ruleLangtagg
            {
             before(grammarAccess.getRDFLiteralAccess().getLLangtaggParserRuleCall_1_0_0()); 
            pushFollow(FOLLOW_2);
            ruleLangtagg();

            state._fsp--;

             after(grammarAccess.getRDFLiteralAccess().getLLangtaggParserRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__LAssignment_1_0"


    // $ANTLR start "rule__RDFLiteral__DtAssignment_1_1_1"
    // InternalMyDsl.g:3930:1: rule__RDFLiteral__DtAssignment_1_1_1 : ( ruleIRIBOL ) ;
    public final void rule__RDFLiteral__DtAssignment_1_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3934:1: ( ( ruleIRIBOL ) )
            // InternalMyDsl.g:3935:2: ( ruleIRIBOL )
            {
            // InternalMyDsl.g:3935:2: ( ruleIRIBOL )
            // InternalMyDsl.g:3936:3: ruleIRIBOL
            {
             before(grammarAccess.getRDFLiteralAccess().getDtIRIBOLParserRuleCall_1_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIBOL();

            state._fsp--;

             after(grammarAccess.getRDFLiteralAccess().getDtIRIBOLParserRuleCall_1_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RDFLiteral__DtAssignment_1_1_1"


    // $ANTLR start "rule__NumericLiteral__TAssignment_0"
    // InternalMyDsl.g:3945:1: rule__NumericLiteral__TAssignment_0 : ( RULE_INTEGER ) ;
    public final void rule__NumericLiteral__TAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3949:1: ( ( RULE_INTEGER ) )
            // InternalMyDsl.g:3950:2: ( RULE_INTEGER )
            {
            // InternalMyDsl.g:3950:2: ( RULE_INTEGER )
            // InternalMyDsl.g:3951:3: RULE_INTEGER
            {
             before(grammarAccess.getNumericLiteralAccess().getTINTEGERTerminalRuleCall_0_0()); 
            match(input,RULE_INTEGER,FOLLOW_2); 
             after(grammarAccess.getNumericLiteralAccess().getTINTEGERTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NumericLiteral__TAssignment_0"


    // $ANTLR start "rule__NumericLiteral__TAssignment_1"
    // InternalMyDsl.g:3960:1: rule__NumericLiteral__TAssignment_1 : ( RULE_DECIMAL ) ;
    public final void rule__NumericLiteral__TAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3964:1: ( ( RULE_DECIMAL ) )
            // InternalMyDsl.g:3965:2: ( RULE_DECIMAL )
            {
            // InternalMyDsl.g:3965:2: ( RULE_DECIMAL )
            // InternalMyDsl.g:3966:3: RULE_DECIMAL
            {
             before(grammarAccess.getNumericLiteralAccess().getTDECIMALTerminalRuleCall_1_0()); 
            match(input,RULE_DECIMAL,FOLLOW_2); 
             after(grammarAccess.getNumericLiteralAccess().getTDECIMALTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NumericLiteral__TAssignment_1"


    // $ANTLR start "rule__NumericLiteral__TAssignment_2"
    // InternalMyDsl.g:3975:1: rule__NumericLiteral__TAssignment_2 : ( RULE_DOUBLE ) ;
    public final void rule__NumericLiteral__TAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3979:1: ( ( RULE_DOUBLE ) )
            // InternalMyDsl.g:3980:2: ( RULE_DOUBLE )
            {
            // InternalMyDsl.g:3980:2: ( RULE_DOUBLE )
            // InternalMyDsl.g:3981:3: RULE_DOUBLE
            {
             before(grammarAccess.getNumericLiteralAccess().getTDOUBLETerminalRuleCall_2_0()); 
            match(input,RULE_DOUBLE,FOLLOW_2); 
             after(grammarAccess.getNumericLiteralAccess().getTDOUBLETerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NumericLiteral__TAssignment_2"


    // $ANTLR start "rule__Term__SAssignment_0"
    // InternalMyDsl.g:3990:1: rule__Term__SAssignment_0 : ( ruleIRIBOL ) ;
    public final void rule__Term__SAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:3994:1: ( ( ruleIRIBOL ) )
            // InternalMyDsl.g:3995:2: ( ruleIRIBOL )
            {
            // InternalMyDsl.g:3995:2: ( ruleIRIBOL )
            // InternalMyDsl.g:3996:3: ruleIRIBOL
            {
             before(grammarAccess.getTermAccess().getSIRIBOLParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIBOL();

            state._fsp--;

             after(grammarAccess.getTermAccess().getSIRIBOLParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Term__SAssignment_0"


    // $ANTLR start "rule__Term__CAssignment_1"
    // InternalMyDsl.g:4005:1: rule__Term__CAssignment_1 : ( ruleNumericLiteral ) ;
    public final void rule__Term__CAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4009:1: ( ( ruleNumericLiteral ) )
            // InternalMyDsl.g:4010:2: ( ruleNumericLiteral )
            {
            // InternalMyDsl.g:4010:2: ( ruleNumericLiteral )
            // InternalMyDsl.g:4011:3: ruleNumericLiteral
            {
             before(grammarAccess.getTermAccess().getCNumericLiteralParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleNumericLiteral();

            state._fsp--;

             after(grammarAccess.getTermAccess().getCNumericLiteralParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Term__CAssignment_1"


    // $ANTLR start "rule__Term__SAssignment_2"
    // InternalMyDsl.g:4020:1: rule__Term__SAssignment_2 : ( ruleRDFLiteral ) ;
    public final void rule__Term__SAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4024:1: ( ( ruleRDFLiteral ) )
            // InternalMyDsl.g:4025:2: ( ruleRDFLiteral )
            {
            // InternalMyDsl.g:4025:2: ( ruleRDFLiteral )
            // InternalMyDsl.g:4026:3: ruleRDFLiteral
            {
             before(grammarAccess.getTermAccess().getSRDFLiteralParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleRDFLiteral();

            state._fsp--;

             after(grammarAccess.getTermAccess().getSRDFLiteralParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Term__SAssignment_2"


    // $ANTLR start "rule__Term__TAssignment_3"
    // InternalMyDsl.g:4035:1: rule__Term__TAssignment_3 : ( RULE_UNIVAR ) ;
    public final void rule__Term__TAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4039:1: ( ( RULE_UNIVAR ) )
            // InternalMyDsl.g:4040:2: ( RULE_UNIVAR )
            {
            // InternalMyDsl.g:4040:2: ( RULE_UNIVAR )
            // InternalMyDsl.g:4041:3: RULE_UNIVAR
            {
             before(grammarAccess.getTermAccess().getTUNIVARTerminalRuleCall_3_0()); 
            match(input,RULE_UNIVAR,FOLLOW_2); 
             after(grammarAccess.getTermAccess().getTUNIVARTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Term__TAssignment_3"


    // $ANTLR start "rule__Term__TAssignment_4"
    // InternalMyDsl.g:4050:1: rule__Term__TAssignment_4 : ( RULE_EXIVAR ) ;
    public final void rule__Term__TAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4054:1: ( ( RULE_EXIVAR ) )
            // InternalMyDsl.g:4055:2: ( RULE_EXIVAR )
            {
            // InternalMyDsl.g:4055:2: ( RULE_EXIVAR )
            // InternalMyDsl.g:4056:3: RULE_EXIVAR
            {
             before(grammarAccess.getTermAccess().getTEXIVARTerminalRuleCall_4_0()); 
            match(input,RULE_EXIVAR,FOLLOW_2); 
             after(grammarAccess.getTermAccess().getTEXIVARTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Term__TAssignment_4"


    // $ANTLR start "rule__Term__TAssignment_5"
    // InternalMyDsl.g:4065:1: rule__Term__TAssignment_5 : ( RULE_VARORPREDNAME ) ;
    public final void rule__Term__TAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4069:1: ( ( RULE_VARORPREDNAME ) )
            // InternalMyDsl.g:4070:2: ( RULE_VARORPREDNAME )
            {
            // InternalMyDsl.g:4070:2: ( RULE_VARORPREDNAME )
            // InternalMyDsl.g:4071:3: RULE_VARORPREDNAME
            {
             before(grammarAccess.getTermAccess().getTVARORPREDNAMETerminalRuleCall_5_0()); 
            match(input,RULE_VARORPREDNAME,FOLLOW_2); 
             after(grammarAccess.getTermAccess().getTVARORPREDNAMETerminalRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Term__TAssignment_5"


    // $ANTLR start "rule__PredicateName__SAssignment_0"
    // InternalMyDsl.g:4080:1: rule__PredicateName__SAssignment_0 : ( ruleIRIBOL ) ;
    public final void rule__PredicateName__SAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4084:1: ( ( ruleIRIBOL ) )
            // InternalMyDsl.g:4085:2: ( ruleIRIBOL )
            {
            // InternalMyDsl.g:4085:2: ( ruleIRIBOL )
            // InternalMyDsl.g:4086:3: ruleIRIBOL
            {
             before(grammarAccess.getPredicateNameAccess().getSIRIBOLParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIBOL();

            state._fsp--;

             after(grammarAccess.getPredicateNameAccess().getSIRIBOLParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PredicateName__SAssignment_0"


    // $ANTLR start "rule__PredicateName__TAssignment_1"
    // InternalMyDsl.g:4095:1: rule__PredicateName__TAssignment_1 : ( RULE_VARORPREDNAME ) ;
    public final void rule__PredicateName__TAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4099:1: ( ( RULE_VARORPREDNAME ) )
            // InternalMyDsl.g:4100:2: ( RULE_VARORPREDNAME )
            {
            // InternalMyDsl.g:4100:2: ( RULE_VARORPREDNAME )
            // InternalMyDsl.g:4101:3: RULE_VARORPREDNAME
            {
             before(grammarAccess.getPredicateNameAccess().getTVARORPREDNAMETerminalRuleCall_1_0()); 
            match(input,RULE_VARORPREDNAME,FOLLOW_2); 
             after(grammarAccess.getPredicateNameAccess().getTVARORPREDNAMETerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PredicateName__TAssignment_1"


    // $ANTLR start "rule__ListOfTerms__TAssignment_0"
    // InternalMyDsl.g:4110:1: rule__ListOfTerms__TAssignment_0 : ( ruleTerm ) ;
    public final void rule__ListOfTerms__TAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4114:1: ( ( ruleTerm ) )
            // InternalMyDsl.g:4115:2: ( ruleTerm )
            {
            // InternalMyDsl.g:4115:2: ( ruleTerm )
            // InternalMyDsl.g:4116:3: ruleTerm
            {
             before(grammarAccess.getListOfTermsAccess().getTTermParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleTerm();

            state._fsp--;

             after(grammarAccess.getListOfTermsAccess().getTTermParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__TAssignment_0"


    // $ANTLR start "rule__ListOfTerms__TAssignment_1_1"
    // InternalMyDsl.g:4125:1: rule__ListOfTerms__TAssignment_1_1 : ( ruleTerm ) ;
    public final void rule__ListOfTerms__TAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4129:1: ( ( ruleTerm ) )
            // InternalMyDsl.g:4130:2: ( ruleTerm )
            {
            // InternalMyDsl.g:4130:2: ( ruleTerm )
            // InternalMyDsl.g:4131:3: ruleTerm
            {
             before(grammarAccess.getListOfTermsAccess().getTTermParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleTerm();

            state._fsp--;

             after(grammarAccess.getListOfTermsAccess().getTTermParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfTerms__TAssignment_1_1"


    // $ANTLR start "rule__NegativeLiteral__PredicatenameAssignment_1"
    // InternalMyDsl.g:4140:1: rule__NegativeLiteral__PredicatenameAssignment_1 : ( rulepredicateName ) ;
    public final void rule__NegativeLiteral__PredicatenameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4144:1: ( ( rulepredicateName ) )
            // InternalMyDsl.g:4145:2: ( rulepredicateName )
            {
            // InternalMyDsl.g:4145:2: ( rulepredicateName )
            // InternalMyDsl.g:4146:3: rulepredicateName
            {
             before(grammarAccess.getNegativeLiteralAccess().getPredicatenamePredicateNameParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            rulepredicateName();

            state._fsp--;

             after(grammarAccess.getNegativeLiteralAccess().getPredicatenamePredicateNameParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__PredicatenameAssignment_1"


    // $ANTLR start "rule__NegativeLiteral__TermsAssignment_3"
    // InternalMyDsl.g:4155:1: rule__NegativeLiteral__TermsAssignment_3 : ( rulelistOfTerms ) ;
    public final void rule__NegativeLiteral__TermsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4159:1: ( ( rulelistOfTerms ) )
            // InternalMyDsl.g:4160:2: ( rulelistOfTerms )
            {
            // InternalMyDsl.g:4160:2: ( rulelistOfTerms )
            // InternalMyDsl.g:4161:3: rulelistOfTerms
            {
             before(grammarAccess.getNegativeLiteralAccess().getTermsListOfTermsParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            rulelistOfTerms();

            state._fsp--;

             after(grammarAccess.getNegativeLiteralAccess().getTermsListOfTermsParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__NegativeLiteral__TermsAssignment_3"


    // $ANTLR start "rule__Fact__PredicatenameAssignment_0"
    // InternalMyDsl.g:4170:1: rule__Fact__PredicatenameAssignment_0 : ( rulepredicateName ) ;
    public final void rule__Fact__PredicatenameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4174:1: ( ( rulepredicateName ) )
            // InternalMyDsl.g:4175:2: ( rulepredicateName )
            {
            // InternalMyDsl.g:4175:2: ( rulepredicateName )
            // InternalMyDsl.g:4176:3: rulepredicateName
            {
             before(grammarAccess.getFactAccess().getPredicatenamePredicateNameParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            rulepredicateName();

            state._fsp--;

             after(grammarAccess.getFactAccess().getPredicatenamePredicateNameParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__PredicatenameAssignment_0"


    // $ANTLR start "rule__Fact__TermsAssignment_2"
    // InternalMyDsl.g:4185:1: rule__Fact__TermsAssignment_2 : ( rulelistOfTerms ) ;
    public final void rule__Fact__TermsAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4189:1: ( ( rulelistOfTerms ) )
            // InternalMyDsl.g:4190:2: ( rulelistOfTerms )
            {
            // InternalMyDsl.g:4190:2: ( rulelistOfTerms )
            // InternalMyDsl.g:4191:3: rulelistOfTerms
            {
             before(grammarAccess.getFactAccess().getTermsListOfTermsParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            rulelistOfTerms();

            state._fsp--;

             after(grammarAccess.getFactAccess().getTermsListOfTermsParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Fact__TermsAssignment_2"


    // $ANTLR start "rule__PositiveLiteral__PredicatenameAssignment_0"
    // InternalMyDsl.g:4200:1: rule__PositiveLiteral__PredicatenameAssignment_0 : ( rulepredicateName ) ;
    public final void rule__PositiveLiteral__PredicatenameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4204:1: ( ( rulepredicateName ) )
            // InternalMyDsl.g:4205:2: ( rulepredicateName )
            {
            // InternalMyDsl.g:4205:2: ( rulepredicateName )
            // InternalMyDsl.g:4206:3: rulepredicateName
            {
             before(grammarAccess.getPositiveLiteralAccess().getPredicatenamePredicateNameParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            rulepredicateName();

            state._fsp--;

             after(grammarAccess.getPositiveLiteralAccess().getPredicatenamePredicateNameParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__PredicatenameAssignment_0"


    // $ANTLR start "rule__PositiveLiteral__TermsAssignment_2"
    // InternalMyDsl.g:4215:1: rule__PositiveLiteral__TermsAssignment_2 : ( rulelistOfTerms ) ;
    public final void rule__PositiveLiteral__TermsAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4219:1: ( ( rulelistOfTerms ) )
            // InternalMyDsl.g:4220:2: ( rulelistOfTerms )
            {
            // InternalMyDsl.g:4220:2: ( rulelistOfTerms )
            // InternalMyDsl.g:4221:3: rulelistOfTerms
            {
             before(grammarAccess.getPositiveLiteralAccess().getTermsListOfTermsParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            rulelistOfTerms();

            state._fsp--;

             after(grammarAccess.getPositiveLiteralAccess().getTermsListOfTermsParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PositiveLiteral__TermsAssignment_2"


    // $ANTLR start "rule__Literal__LAssignment_0"
    // InternalMyDsl.g:4230:1: rule__Literal__LAssignment_0 : ( rulePositiveLiteral ) ;
    public final void rule__Literal__LAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4234:1: ( ( rulePositiveLiteral ) )
            // InternalMyDsl.g:4235:2: ( rulePositiveLiteral )
            {
            // InternalMyDsl.g:4235:2: ( rulePositiveLiteral )
            // InternalMyDsl.g:4236:3: rulePositiveLiteral
            {
             before(grammarAccess.getLiteralAccess().getLPositiveLiteralParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            rulePositiveLiteral();

            state._fsp--;

             after(grammarAccess.getLiteralAccess().getLPositiveLiteralParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Literal__LAssignment_0"


    // $ANTLR start "rule__Literal__LAssignment_1"
    // InternalMyDsl.g:4245:1: rule__Literal__LAssignment_1 : ( ruleNegativeLiteral ) ;
    public final void rule__Literal__LAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4249:1: ( ( ruleNegativeLiteral ) )
            // InternalMyDsl.g:4250:2: ( ruleNegativeLiteral )
            {
            // InternalMyDsl.g:4250:2: ( ruleNegativeLiteral )
            // InternalMyDsl.g:4251:3: ruleNegativeLiteral
            {
             before(grammarAccess.getLiteralAccess().getLNegativeLiteralParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleNegativeLiteral();

            state._fsp--;

             after(grammarAccess.getLiteralAccess().getLNegativeLiteralParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Literal__LAssignment_1"


    // $ANTLR start "rule__ListOfLiterals__LAssignment_0"
    // InternalMyDsl.g:4260:1: rule__ListOfLiterals__LAssignment_0 : ( ruleLiteral ) ;
    public final void rule__ListOfLiterals__LAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4264:1: ( ( ruleLiteral ) )
            // InternalMyDsl.g:4265:2: ( ruleLiteral )
            {
            // InternalMyDsl.g:4265:2: ( ruleLiteral )
            // InternalMyDsl.g:4266:3: ruleLiteral
            {
             before(grammarAccess.getListOfLiteralsAccess().getLLiteralParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleLiteral();

            state._fsp--;

             after(grammarAccess.getListOfLiteralsAccess().getLLiteralParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__LAssignment_0"


    // $ANTLR start "rule__ListOfLiterals__LAssignment_1_1"
    // InternalMyDsl.g:4275:1: rule__ListOfLiterals__LAssignment_1_1 : ( ruleLiteral ) ;
    public final void rule__ListOfLiterals__LAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4279:1: ( ( ruleLiteral ) )
            // InternalMyDsl.g:4280:2: ( ruleLiteral )
            {
            // InternalMyDsl.g:4280:2: ( ruleLiteral )
            // InternalMyDsl.g:4281:3: ruleLiteral
            {
             before(grammarAccess.getListOfLiteralsAccess().getLLiteralParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleLiteral();

            state._fsp--;

             after(grammarAccess.getListOfLiteralsAccess().getLLiteralParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfLiterals__LAssignment_1_1"


    // $ANTLR start "rule__ListOfPositiveLiterals__LAssignment_0"
    // InternalMyDsl.g:4290:1: rule__ListOfPositiveLiterals__LAssignment_0 : ( rulePositiveLiteral ) ;
    public final void rule__ListOfPositiveLiterals__LAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4294:1: ( ( rulePositiveLiteral ) )
            // InternalMyDsl.g:4295:2: ( rulePositiveLiteral )
            {
            // InternalMyDsl.g:4295:2: ( rulePositiveLiteral )
            // InternalMyDsl.g:4296:3: rulePositiveLiteral
            {
             before(grammarAccess.getListOfPositiveLiteralsAccess().getLPositiveLiteralParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            rulePositiveLiteral();

            state._fsp--;

             after(grammarAccess.getListOfPositiveLiteralsAccess().getLPositiveLiteralParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__LAssignment_0"


    // $ANTLR start "rule__ListOfPositiveLiterals__LAssignment_1_1"
    // InternalMyDsl.g:4305:1: rule__ListOfPositiveLiterals__LAssignment_1_1 : ( rulePositiveLiteral ) ;
    public final void rule__ListOfPositiveLiterals__LAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4309:1: ( ( rulePositiveLiteral ) )
            // InternalMyDsl.g:4310:2: ( rulePositiveLiteral )
            {
            // InternalMyDsl.g:4310:2: ( rulePositiveLiteral )
            // InternalMyDsl.g:4311:3: rulePositiveLiteral
            {
             before(grammarAccess.getListOfPositiveLiteralsAccess().getLPositiveLiteralParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            rulePositiveLiteral();

            state._fsp--;

             after(grammarAccess.getListOfPositiveLiteralsAccess().getLPositiveLiteralParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListOfPositiveLiterals__LAssignment_1_1"


    // $ANTLR start "rule__Rule__HeadAssignment_0"
    // InternalMyDsl.g:4320:1: rule__Rule__HeadAssignment_0 : ( rulelistOfPositiveLiterals ) ;
    public final void rule__Rule__HeadAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4324:1: ( ( rulelistOfPositiveLiterals ) )
            // InternalMyDsl.g:4325:2: ( rulelistOfPositiveLiterals )
            {
            // InternalMyDsl.g:4325:2: ( rulelistOfPositiveLiterals )
            // InternalMyDsl.g:4326:3: rulelistOfPositiveLiterals
            {
             before(grammarAccess.getRuleAccess().getHeadListOfPositiveLiteralsParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            rulelistOfPositiveLiterals();

            state._fsp--;

             after(grammarAccess.getRuleAccess().getHeadListOfPositiveLiteralsParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__HeadAssignment_0"


    // $ANTLR start "rule__Rule__BodyAssignment_2"
    // InternalMyDsl.g:4335:1: rule__Rule__BodyAssignment_2 : ( rulelistOfLiterals ) ;
    public final void rule__Rule__BodyAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4339:1: ( ( rulelistOfLiterals ) )
            // InternalMyDsl.g:4340:2: ( rulelistOfLiterals )
            {
            // InternalMyDsl.g:4340:2: ( rulelistOfLiterals )
            // InternalMyDsl.g:4341:3: rulelistOfLiterals
            {
             before(grammarAccess.getRuleAccess().getBodyListOfLiteralsParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            rulelistOfLiterals();

            state._fsp--;

             after(grammarAccess.getRuleAccess().getBodyListOfLiteralsParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Rule__BodyAssignment_2"


    // $ANTLR start "rule__Statement__StatementAssignment_0"
    // InternalMyDsl.g:4350:1: rule__Statement__StatementAssignment_0 : ( ruleRule ) ;
    public final void rule__Statement__StatementAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4354:1: ( ( ruleRule ) )
            // InternalMyDsl.g:4355:2: ( ruleRule )
            {
            // InternalMyDsl.g:4355:2: ( ruleRule )
            // InternalMyDsl.g:4356:3: ruleRule
            {
             before(grammarAccess.getStatementAccess().getStatementRuleParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleRule();

            state._fsp--;

             after(grammarAccess.getStatementAccess().getStatementRuleParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__StatementAssignment_0"


    // $ANTLR start "rule__Statement__StatementAssignment_1_0"
    // InternalMyDsl.g:4365:1: rule__Statement__StatementAssignment_1_0 : ( ruleFact ) ;
    public final void rule__Statement__StatementAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4369:1: ( ( ruleFact ) )
            // InternalMyDsl.g:4370:2: ( ruleFact )
            {
            // InternalMyDsl.g:4370:2: ( ruleFact )
            // InternalMyDsl.g:4371:3: ruleFact
            {
             before(grammarAccess.getStatementAccess().getStatementFactParserRuleCall_1_0_0()); 
            pushFollow(FOLLOW_2);
            ruleFact();

            state._fsp--;

             after(grammarAccess.getStatementAccess().getStatementFactParserRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__StatementAssignment_1_0"


    // $ANTLR start "rule__Statement__StatementAssignment_2_0"
    // InternalMyDsl.g:4380:1: rule__Statement__StatementAssignment_2_0 : ( ruleRule ) ;
    public final void rule__Statement__StatementAssignment_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4384:1: ( ( ruleRule ) )
            // InternalMyDsl.g:4385:2: ( ruleRule )
            {
            // InternalMyDsl.g:4385:2: ( ruleRule )
            // InternalMyDsl.g:4386:3: ruleRule
            {
             before(grammarAccess.getStatementAccess().getStatementRuleParserRuleCall_2_0_0()); 
            pushFollow(FOLLOW_2);
            ruleRule();

            state._fsp--;

             after(grammarAccess.getStatementAccess().getStatementRuleParserRuleCall_2_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__StatementAssignment_2_0"


    // $ANTLR start "rule__Statement__StatementAssignment_3_0"
    // InternalMyDsl.g:4395:1: rule__Statement__StatementAssignment_3_0 : ( ruleFact ) ;
    public final void rule__Statement__StatementAssignment_3_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4399:1: ( ( ruleFact ) )
            // InternalMyDsl.g:4400:2: ( ruleFact )
            {
            // InternalMyDsl.g:4400:2: ( ruleFact )
            // InternalMyDsl.g:4401:3: ruleFact
            {
             before(grammarAccess.getStatementAccess().getStatementFactParserRuleCall_3_0_0()); 
            pushFollow(FOLLOW_2);
            ruleFact();

            state._fsp--;

             after(grammarAccess.getStatementAccess().getStatementFactParserRuleCall_3_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Statement__StatementAssignment_3_0"


    // $ANTLR start "rule__DataSource__FileNameAssignment_0_2"
    // InternalMyDsl.g:4410:1: rule__DataSource__FileNameAssignment_0_2 : ( ruleStriing ) ;
    public final void rule__DataSource__FileNameAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4414:1: ( ( ruleStriing ) )
            // InternalMyDsl.g:4415:2: ( ruleStriing )
            {
            // InternalMyDsl.g:4415:2: ( ruleStriing )
            // InternalMyDsl.g:4416:3: ruleStriing
            {
             before(grammarAccess.getDataSourceAccess().getFileNameStriingParserRuleCall_0_2_0()); 
            pushFollow(FOLLOW_2);
            ruleStriing();

            state._fsp--;

             after(grammarAccess.getDataSourceAccess().getFileNameStriingParserRuleCall_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__FileNameAssignment_0_2"


    // $ANTLR start "rule__DataSource__FileNameAssignment_1_2"
    // InternalMyDsl.g:4425:1: rule__DataSource__FileNameAssignment_1_2 : ( ruleStriing ) ;
    public final void rule__DataSource__FileNameAssignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4429:1: ( ( ruleStriing ) )
            // InternalMyDsl.g:4430:2: ( ruleStriing )
            {
            // InternalMyDsl.g:4430:2: ( ruleStriing )
            // InternalMyDsl.g:4431:3: ruleStriing
            {
             before(grammarAccess.getDataSourceAccess().getFileNameStriingParserRuleCall_1_2_0()); 
            pushFollow(FOLLOW_2);
            ruleStriing();

            state._fsp--;

             after(grammarAccess.getDataSourceAccess().getFileNameStriingParserRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__FileNameAssignment_1_2"


    // $ANTLR start "rule__DataSource__EndpointAssignment_2_2"
    // InternalMyDsl.g:4440:1: rule__DataSource__EndpointAssignment_2_2 : ( ruleIRIBOL ) ;
    public final void rule__DataSource__EndpointAssignment_2_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4444:1: ( ( ruleIRIBOL ) )
            // InternalMyDsl.g:4445:2: ( ruleIRIBOL )
            {
            // InternalMyDsl.g:4445:2: ( ruleIRIBOL )
            // InternalMyDsl.g:4446:3: ruleIRIBOL
            {
             before(grammarAccess.getDataSourceAccess().getEndpointIRIBOLParserRuleCall_2_2_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIBOL();

            state._fsp--;

             after(grammarAccess.getDataSourceAccess().getEndpointIRIBOLParserRuleCall_2_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__EndpointAssignment_2_2"


    // $ANTLR start "rule__DataSource__VariablesAssignment_2_4"
    // InternalMyDsl.g:4455:1: rule__DataSource__VariablesAssignment_2_4 : ( ruleStriing ) ;
    public final void rule__DataSource__VariablesAssignment_2_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4459:1: ( ( ruleStriing ) )
            // InternalMyDsl.g:4460:2: ( ruleStriing )
            {
            // InternalMyDsl.g:4460:2: ( ruleStriing )
            // InternalMyDsl.g:4461:3: ruleStriing
            {
             before(grammarAccess.getDataSourceAccess().getVariablesStriingParserRuleCall_2_4_0()); 
            pushFollow(FOLLOW_2);
            ruleStriing();

            state._fsp--;

             after(grammarAccess.getDataSourceAccess().getVariablesStriingParserRuleCall_2_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__VariablesAssignment_2_4"


    // $ANTLR start "rule__DataSource__QueryAssignment_2_6"
    // InternalMyDsl.g:4470:1: rule__DataSource__QueryAssignment_2_6 : ( ruleStriing ) ;
    public final void rule__DataSource__QueryAssignment_2_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4474:1: ( ( ruleStriing ) )
            // InternalMyDsl.g:4475:2: ( ruleStriing )
            {
            // InternalMyDsl.g:4475:2: ( ruleStriing )
            // InternalMyDsl.g:4476:3: ruleStriing
            {
             before(grammarAccess.getDataSourceAccess().getQueryStriingParserRuleCall_2_6_0()); 
            pushFollow(FOLLOW_2);
            ruleStriing();

            state._fsp--;

             after(grammarAccess.getDataSourceAccess().getQueryStriingParserRuleCall_2_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataSource__QueryAssignment_2_6"


    // $ANTLR start "rule__Source__PredicatenameAssignment_0_1"
    // InternalMyDsl.g:4485:1: rule__Source__PredicatenameAssignment_0_1 : ( rulepredicateName ) ;
    public final void rule__Source__PredicatenameAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4489:1: ( ( rulepredicateName ) )
            // InternalMyDsl.g:4490:2: ( rulepredicateName )
            {
            // InternalMyDsl.g:4490:2: ( rulepredicateName )
            // InternalMyDsl.g:4491:3: rulepredicateName
            {
             before(grammarAccess.getSourceAccess().getPredicatenamePredicateNameParserRuleCall_0_1_0()); 
            pushFollow(FOLLOW_2);
            rulepredicateName();

            state._fsp--;

             after(grammarAccess.getSourceAccess().getPredicatenamePredicateNameParserRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__PredicatenameAssignment_0_1"


    // $ANTLR start "rule__Source__ArityAssignment_0_3"
    // InternalMyDsl.g:4500:1: rule__Source__ArityAssignment_0_3 : ( RULE_INTEGER ) ;
    public final void rule__Source__ArityAssignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4504:1: ( ( RULE_INTEGER ) )
            // InternalMyDsl.g:4505:2: ( RULE_INTEGER )
            {
            // InternalMyDsl.g:4505:2: ( RULE_INTEGER )
            // InternalMyDsl.g:4506:3: RULE_INTEGER
            {
             before(grammarAccess.getSourceAccess().getArityINTEGERTerminalRuleCall_0_3_0()); 
            match(input,RULE_INTEGER,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getArityINTEGERTerminalRuleCall_0_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__ArityAssignment_0_3"


    // $ANTLR start "rule__Source__DataSourceAssignment_0_6"
    // InternalMyDsl.g:4515:1: rule__Source__DataSourceAssignment_0_6 : ( ruleDataSource ) ;
    public final void rule__Source__DataSourceAssignment_0_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4519:1: ( ( ruleDataSource ) )
            // InternalMyDsl.g:4520:2: ( ruleDataSource )
            {
            // InternalMyDsl.g:4520:2: ( ruleDataSource )
            // InternalMyDsl.g:4521:3: ruleDataSource
            {
             before(grammarAccess.getSourceAccess().getDataSourceDataSourceParserRuleCall_0_6_0()); 
            pushFollow(FOLLOW_2);
            ruleDataSource();

            state._fsp--;

             after(grammarAccess.getSourceAccess().getDataSourceDataSourceParserRuleCall_0_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__DataSourceAssignment_0_6"


    // $ANTLR start "rule__Source__PredicatenameAssignment_1_1"
    // InternalMyDsl.g:4530:1: rule__Source__PredicatenameAssignment_1_1 : ( rulepredicateName ) ;
    public final void rule__Source__PredicatenameAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4534:1: ( ( rulepredicateName ) )
            // InternalMyDsl.g:4535:2: ( rulepredicateName )
            {
            // InternalMyDsl.g:4535:2: ( rulepredicateName )
            // InternalMyDsl.g:4536:3: rulepredicateName
            {
             before(grammarAccess.getSourceAccess().getPredicatenamePredicateNameParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            rulepredicateName();

            state._fsp--;

             after(grammarAccess.getSourceAccess().getPredicatenamePredicateNameParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__PredicatenameAssignment_1_1"


    // $ANTLR start "rule__Source__ArityAssignment_1_3"
    // InternalMyDsl.g:4545:1: rule__Source__ArityAssignment_1_3 : ( RULE_INTEGER ) ;
    public final void rule__Source__ArityAssignment_1_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4549:1: ( ( RULE_INTEGER ) )
            // InternalMyDsl.g:4550:2: ( RULE_INTEGER )
            {
            // InternalMyDsl.g:4550:2: ( RULE_INTEGER )
            // InternalMyDsl.g:4551:3: RULE_INTEGER
            {
             before(grammarAccess.getSourceAccess().getArityINTEGERTerminalRuleCall_1_3_0()); 
            match(input,RULE_INTEGER,FOLLOW_2); 
             after(grammarAccess.getSourceAccess().getArityINTEGERTerminalRuleCall_1_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__ArityAssignment_1_3"


    // $ANTLR start "rule__Source__DataSourceAssignment_1_6"
    // InternalMyDsl.g:4560:1: rule__Source__DataSourceAssignment_1_6 : ( ruleDataSource ) ;
    public final void rule__Source__DataSourceAssignment_1_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4564:1: ( ( ruleDataSource ) )
            // InternalMyDsl.g:4565:2: ( ruleDataSource )
            {
            // InternalMyDsl.g:4565:2: ( ruleDataSource )
            // InternalMyDsl.g:4566:3: ruleDataSource
            {
             before(grammarAccess.getSourceAccess().getDataSourceDataSourceParserRuleCall_1_6_0()); 
            pushFollow(FOLLOW_2);
            ruleDataSource();

            state._fsp--;

             after(grammarAccess.getSourceAccess().getDataSourceDataSourceParserRuleCall_1_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Source__DataSourceAssignment_1_6"


    // $ANTLR start "rule__Prefix__TAssignment_0_1"
    // InternalMyDsl.g:4575:1: rule__Prefix__TAssignment_0_1 : ( RULE_COLON ) ;
    public final void rule__Prefix__TAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4579:1: ( ( RULE_COLON ) )
            // InternalMyDsl.g:4580:2: ( RULE_COLON )
            {
            // InternalMyDsl.g:4580:2: ( RULE_COLON )
            // InternalMyDsl.g:4581:3: RULE_COLON
            {
             before(grammarAccess.getPrefixAccess().getTCOLONTerminalRuleCall_0_1_0()); 
            match(input,RULE_COLON,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getTCOLONTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__TAssignment_0_1"


    // $ANTLR start "rule__Prefix__IriStringAssignment_0_2"
    // InternalMyDsl.g:4590:1: rule__Prefix__IriStringAssignment_0_2 : ( ruleIRIREF ) ;
    public final void rule__Prefix__IriStringAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4594:1: ( ( ruleIRIREF ) )
            // InternalMyDsl.g:4595:2: ( ruleIRIREF )
            {
            // InternalMyDsl.g:4595:2: ( ruleIRIREF )
            // InternalMyDsl.g:4596:3: ruleIRIREF
            {
             before(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_0_2_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIREF();

            state._fsp--;

             after(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__IriStringAssignment_0_2"


    // $ANTLR start "rule__Prefix__TAssignment_1_1"
    // InternalMyDsl.g:4605:1: rule__Prefix__TAssignment_1_1 : ( RULE_PNAME_NS ) ;
    public final void rule__Prefix__TAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4609:1: ( ( RULE_PNAME_NS ) )
            // InternalMyDsl.g:4610:2: ( RULE_PNAME_NS )
            {
            // InternalMyDsl.g:4610:2: ( RULE_PNAME_NS )
            // InternalMyDsl.g:4611:3: RULE_PNAME_NS
            {
             before(grammarAccess.getPrefixAccess().getTPNAME_NSTerminalRuleCall_1_1_0()); 
            match(input,RULE_PNAME_NS,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getTPNAME_NSTerminalRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__TAssignment_1_1"


    // $ANTLR start "rule__Prefix__IriStringAssignment_1_2"
    // InternalMyDsl.g:4620:1: rule__Prefix__IriStringAssignment_1_2 : ( ruleIRIREF ) ;
    public final void rule__Prefix__IriStringAssignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4624:1: ( ( ruleIRIREF ) )
            // InternalMyDsl.g:4625:2: ( ruleIRIREF )
            {
            // InternalMyDsl.g:4625:2: ( ruleIRIREF )
            // InternalMyDsl.g:4626:3: ruleIRIREF
            {
             before(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_1_2_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIREF();

            state._fsp--;

             after(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__IriStringAssignment_1_2"


    // $ANTLR start "rule__Prefix__TAssignment_2_1"
    // InternalMyDsl.g:4635:1: rule__Prefix__TAssignment_2_1 : ( RULE_COLON ) ;
    public final void rule__Prefix__TAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4639:1: ( ( RULE_COLON ) )
            // InternalMyDsl.g:4640:2: ( RULE_COLON )
            {
            // InternalMyDsl.g:4640:2: ( RULE_COLON )
            // InternalMyDsl.g:4641:3: RULE_COLON
            {
             before(grammarAccess.getPrefixAccess().getTCOLONTerminalRuleCall_2_1_0()); 
            match(input,RULE_COLON,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getTCOLONTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__TAssignment_2_1"


    // $ANTLR start "rule__Prefix__IriStringAssignment_2_2"
    // InternalMyDsl.g:4650:1: rule__Prefix__IriStringAssignment_2_2 : ( ruleIRIREF ) ;
    public final void rule__Prefix__IriStringAssignment_2_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4654:1: ( ( ruleIRIREF ) )
            // InternalMyDsl.g:4655:2: ( ruleIRIREF )
            {
            // InternalMyDsl.g:4655:2: ( ruleIRIREF )
            // InternalMyDsl.g:4656:3: ruleIRIREF
            {
             before(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_2_2_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIREF();

            state._fsp--;

             after(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_2_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__IriStringAssignment_2_2"


    // $ANTLR start "rule__Prefix__TAssignment_3_1"
    // InternalMyDsl.g:4665:1: rule__Prefix__TAssignment_3_1 : ( RULE_PNAME_NS ) ;
    public final void rule__Prefix__TAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4669:1: ( ( RULE_PNAME_NS ) )
            // InternalMyDsl.g:4670:2: ( RULE_PNAME_NS )
            {
            // InternalMyDsl.g:4670:2: ( RULE_PNAME_NS )
            // InternalMyDsl.g:4671:3: RULE_PNAME_NS
            {
             before(grammarAccess.getPrefixAccess().getTPNAME_NSTerminalRuleCall_3_1_0()); 
            match(input,RULE_PNAME_NS,FOLLOW_2); 
             after(grammarAccess.getPrefixAccess().getTPNAME_NSTerminalRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__TAssignment_3_1"


    // $ANTLR start "rule__Prefix__IriStringAssignment_3_2"
    // InternalMyDsl.g:4680:1: rule__Prefix__IriStringAssignment_3_2 : ( ruleIRIREF ) ;
    public final void rule__Prefix__IriStringAssignment_3_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4684:1: ( ( ruleIRIREF ) )
            // InternalMyDsl.g:4685:2: ( ruleIRIREF )
            {
            // InternalMyDsl.g:4685:2: ( ruleIRIREF )
            // InternalMyDsl.g:4686:3: ruleIRIREF
            {
             before(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_3_2_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIREF();

            state._fsp--;

             after(grammarAccess.getPrefixAccess().getIriStringIRIREFParserRuleCall_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Prefix__IriStringAssignment_3_2"


    // $ANTLR start "rule__Base__IriStringAssignment_0_1"
    // InternalMyDsl.g:4695:1: rule__Base__IriStringAssignment_0_1 : ( ruleIRIREF ) ;
    public final void rule__Base__IriStringAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4699:1: ( ( ruleIRIREF ) )
            // InternalMyDsl.g:4700:2: ( ruleIRIREF )
            {
            // InternalMyDsl.g:4700:2: ( ruleIRIREF )
            // InternalMyDsl.g:4701:3: ruleIRIREF
            {
             before(grammarAccess.getBaseAccess().getIriStringIRIREFParserRuleCall_0_1_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIREF();

            state._fsp--;

             after(grammarAccess.getBaseAccess().getIriStringIRIREFParserRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__IriStringAssignment_0_1"


    // $ANTLR start "rule__Base__IriStringAssignment_1_1"
    // InternalMyDsl.g:4710:1: rule__Base__IriStringAssignment_1_1 : ( ruleIRIREF ) ;
    public final void rule__Base__IriStringAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalMyDsl.g:4714:1: ( ( ruleIRIREF ) )
            // InternalMyDsl.g:4715:2: ( ruleIRIREF )
            {
            // InternalMyDsl.g:4715:2: ( ruleIRIREF )
            // InternalMyDsl.g:4716:3: ruleIRIREF
            {
             before(grammarAccess.getBaseAccess().getIriStringIRIREFParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleIRIREF();

            state._fsp--;

             after(grammarAccess.getBaseAccess().getIriStringIRIREFParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Base__IriStringAssignment_1_1"

    // Delegated rules


    protected DFA8 dfa8 = new DFA8(this);
    protected DFA10 dfa10 = new DFA10(this);
    protected DFA11 dfa11 = new DFA11(this);
    static final String dfa_1s = "\u00f0\uffff";
    static final String dfa_2s = "\41\uffff\1\51\136\uffff\1\u008f\157\uffff";
    static final String dfa_3s = "\1\23\3\7\1\23\5\5\4\4\3\5\1\23\2\5\1\23\5\5\4\4\3\5\1\13\1\23\1\6\3\5\1\23\2\uffff\6\7\1\23\2\5\2\23\3\7\5\5\4\4\10\5\4\4\3\5\2\23\2\5\2\23\2\5\1\23\5\5\4\4\10\5\4\4\12\5\4\4\3\5\1\6\1\13\2\5\1\23\2\5\1\23\1\5\1\23\1\5\1\23\3\7\1\23\2\uffff\5\5\4\4\11\5\1\23\3\7\1\5\1\23\5\5\4\4\3\5\1\23\2\5\1\23\2\5\1\23\5\5\4\4\10\5\4\4\5\5\1\23\2\5\1\23\1\5\1\23\5\5\4\4\10\5\1\23\2\5";
    static final String dfa_4s = "\1\37\3\7\1\37\5\10\4\31\3\10\1\37\1\12\1\10\1\24\5\10\4\31\3\10\3\37\3\10\1\24\2\uffff\6\7\1\37\2\10\2\37\3\7\5\10\4\31\10\10\4\31\3\10\2\37\1\11\1\10\1\24\1\37\1\12\1\10\1\24\5\10\4\31\10\10\4\31\12\10\4\31\3\10\2\37\2\10\1\37\1\12\1\10\1\24\1\10\1\24\1\10\1\24\3\7\1\37\2\uffff\5\10\4\31\11\10\1\37\3\7\1\10\1\24\5\10\4\31\3\10\1\37\2\10\1\37\1\12\1\10\1\24\5\10\4\31\10\10\4\31\5\10\1\37\1\12\1\10\1\24\1\10\1\24\5\10\4\31\10\10\1\24\2\10";
    static final String dfa_5s = "\50\uffff\1\4\1\2\145\uffff\1\1\1\3\137\uffff";
    static final String dfa_6s = "\u00f0\uffff}>";
    static final String[] dfa_7s = {
            "\1\2\1\1\12\uffff\1\3",
            "\1\4",
            "\1\4",
            "\1\4",
            "\1\6\1\5\1\12\1\13\1\14\1\15\1\uffff\1\7\1\10\1\11\1\16\1\17\1\20",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\24\1\21\2\uffff\1\22\20\uffff\1\23",
            "\1\24\1\21\2\uffff\1\22\20\uffff\1\23",
            "\1\24\1\21\2\uffff\1\22\20\uffff\1\23",
            "\1\24\1\21\2\uffff\1\22\20\uffff\1\23",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\26\1\25\1\32\1\33\1\34\1\35\1\uffff\1\27\1\30\1\31\1\36\1\37\1\40",
            "\1\42\3\uffff\1\43\1\41",
            "\1\21\2\uffff\1\22",
            "\1\45\1\44",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\47\1\21\2\uffff\1\22\20\uffff\1\46",
            "\1\47\1\21\2\uffff\1\22\20\uffff\1\46",
            "\1\47\1\21\2\uffff\1\22\20\uffff\1\46",
            "\1\47\1\21\2\uffff\1\22\20\uffff\1\46",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\50\7\uffff\2\51\12\uffff\1\51",
            "\1\53\1\52\12\uffff\1\54",
            "\1\60\14\uffff\1\56\1\55\12\uffff\1\57",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\62\1\61",
            "",
            "",
            "\1\63",
            "\1\63",
            "\1\63",
            "\1\64",
            "\1\64",
            "\1\64",
            "\1\66\1\65\12\uffff\1\67",
            "\1\21\2\uffff\1\22",
            "\1\21\2\uffff\1\22",
            "\1\71\1\70\1\75\1\76\1\77\1\100\1\uffff\1\72\1\73\1\74\1\101\1\102\1\103",
            "\1\105\1\104\1\111\1\112\1\113\1\114\1\uffff\1\106\1\107\1\110\1\115\1\116\1\117",
            "\1\120",
            "\1\120",
            "\1\120",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\124\1\121\2\uffff\1\122\20\uffff\1\123",
            "\1\124\1\121\2\uffff\1\122\20\uffff\1\123",
            "\1\124\1\121\2\uffff\1\122\20\uffff\1\123",
            "\1\124\1\121\2\uffff\1\122\20\uffff\1\123",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\130\1\125\2\uffff\1\126\20\uffff\1\127",
            "\1\130\1\125\2\uffff\1\126\20\uffff\1\127",
            "\1\130\1\125\2\uffff\1\126\20\uffff\1\127",
            "\1\130\1\125\2\uffff\1\126\20\uffff\1\127",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\132\1\131\1\136\1\137\1\140\1\141\1\uffff\1\133\1\134\1\135\1\142\1\143\1\144",
            "\1\146\1\145\1\152\1\153\1\154\1\155\1\uffff\1\147\1\150\1\151\1\156\1\157\1\160",
            "\1\42\3\uffff\1\43",
            "\1\121\2\uffff\1\122",
            "\1\162\1\161",
            "\1\164\1\163\1\170\1\171\1\172\1\173\1\uffff\1\165\1\166\1\167\1\174\1\175\1\176",
            "\1\177\4\uffff\1\u0080",
            "\1\125\2\uffff\1\126",
            "\1\u0082\1\u0081",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0086\1\u0083\2\uffff\1\u0084\20\uffff\1\u0085",
            "\1\u0086\1\u0083\2\uffff\1\u0084\20\uffff\1\u0085",
            "\1\u0086\1\u0083\2\uffff\1\u0084\20\uffff\1\u0085",
            "\1\u0086\1\u0083\2\uffff\1\u0084\20\uffff\1\u0085",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\u0088\1\121\2\uffff\1\122\20\uffff\1\u0087",
            "\1\u0088\1\121\2\uffff\1\122\20\uffff\1\u0087",
            "\1\u0088\1\121\2\uffff\1\122\20\uffff\1\u0087",
            "\1\u0088\1\121\2\uffff\1\122\20\uffff\1\u0087",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\u008a\1\125\2\uffff\1\126\20\uffff\1\u0089",
            "\1\u008a\1\125\2\uffff\1\126\20\uffff\1\u0089",
            "\1\u008a\1\125\2\uffff\1\126\20\uffff\1\u0089",
            "\1\u008a\1\125\2\uffff\1\126\20\uffff\1\u0089",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\u008e\14\uffff\1\u008c\1\u008b\12\uffff\1\u008d",
            "\1\u0090\7\uffff\2\u008f\12\uffff\1\u008f",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\u0092\1\u0091\1\u0096\1\u0097\1\u0098\1\u0099\1\uffff\1\u0093\1\u0094\1\u0095\1\u009a\1\u009b\1\u009c",
            "\1\177\4\uffff\1\u0080",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u009e\1\u009d",
            "\1\121\2\uffff\1\122",
            "\1\u00a0\1\u009f",
            "\1\125\2\uffff\1\126",
            "\1\u00a2\1\u00a1",
            "\1\u00a3",
            "\1\u00a3",
            "\1\u00a3",
            "\1\u00a5\1\u00a4\12\uffff\1\u00a6",
            "",
            "",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u00a8\1\u0083\2\uffff\1\u0084\20\uffff\1\u00a7",
            "\1\u00a8\1\u0083\2\uffff\1\u0084\20\uffff\1\u00a7",
            "\1\u00a8\1\u0083\2\uffff\1\u0084\20\uffff\1\u00a7",
            "\1\u00a8\1\u0083\2\uffff\1\u0084\20\uffff\1\u00a7",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\121\2\uffff\1\122",
            "\1\121\2\uffff\1\122",
            "\1\125\2\uffff\1\126",
            "\1\125\2\uffff\1\126",
            "\1\u00aa\1\u00a9\1\u00ae\1\u00af\1\u00b0\1\u00b1\1\uffff\1\u00ab\1\u00ac\1\u00ad\1\u00b2\1\u00b3\1\u00b4",
            "\1\u00b5",
            "\1\u00b5",
            "\1\u00b5",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u00b7\1\u00b6",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00bb\1\u00b8\2\uffff\1\u00b9\20\uffff\1\u00ba",
            "\1\u00bb\1\u00b8\2\uffff\1\u00b9\20\uffff\1\u00ba",
            "\1\u00bb\1\u00b8\2\uffff\1\u00b9\20\uffff\1\u00ba",
            "\1\u00bb\1\u00b8\2\uffff\1\u00b9\20\uffff\1\u00ba",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00bd\1\u00bc\1\u00c1\1\u00c2\1\u00c3\1\u00c4\1\uffff\1\u00be\1\u00bf\1\u00c0\1\u00c5\1\u00c6\1\u00c7",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u0083\2\uffff\1\u0084",
            "\1\u00c9\1\u00c8\1\u00cd\1\u00ce\1\u00cf\1\u00d0\1\uffff\1\u00ca\1\u00cb\1\u00cc\1\u00d1\1\u00d2\1\u00d3",
            "\1\177\4\uffff\1\u0080",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00d5\1\u00d4",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d9\1\u00d6\2\uffff\1\u00d7\20\uffff\1\u00d8",
            "\1\u00d9\1\u00d6\2\uffff\1\u00d7\20\uffff\1\u00d8",
            "\1\u00d9\1\u00d6\2\uffff\1\u00d7\20\uffff\1\u00d8",
            "\1\u00d9\1\u00d6\2\uffff\1\u00d7\20\uffff\1\u00d8",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00db\1\u00b8\2\uffff\1\u00b9\20\uffff\1\u00da",
            "\1\u00db\1\u00b8\2\uffff\1\u00b9\20\uffff\1\u00da",
            "\1\u00db\1\u00b8\2\uffff\1\u00b9\20\uffff\1\u00da",
            "\1\u00db\1\u00b8\2\uffff\1\u00b9\20\uffff\1\u00da",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00dd\1\u00dc\1\u00e1\1\u00e2\1\u00e3\1\u00e4\1\uffff\1\u00de\1\u00df\1\u00e0\1\u00e5\1\u00e6\1\u00e7",
            "\1\177\4\uffff\1\u0080",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00e9\1\u00e8",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00eb\1\u00ea",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00ed\1\u00d6\2\uffff\1\u00d7\20\uffff\1\u00ec",
            "\1\u00ed\1\u00d6\2\uffff\1\u00d7\20\uffff\1\u00ec",
            "\1\u00ed\1\u00d6\2\uffff\1\u00d7\20\uffff\1\u00ec",
            "\1\u00ed\1\u00d6\2\uffff\1\u00d7\20\uffff\1\u00ec",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00b8\2\uffff\1\u00b9",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00ef\1\u00ee",
            "\1\u00d6\2\uffff\1\u00d7",
            "\1\u00d6\2\uffff\1\u00d7"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA8 extends DFA {

        public DFA8(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "816:1: rule__Statement__Alternatives : ( ( ( rule__Statement__StatementAssignment_0 ) ) | ( ( rule__Statement__Group_1__0 ) ) | ( ( rule__Statement__Group_2__0 ) ) | ( ( rule__Statement__Group_3__0 ) ) );";
        }
    }
    static final String dfa_8s = "\51\uffff";
    static final String dfa_9s = "\34\uffff\1\42\14\uffff";
    static final String dfa_10s = "\1\17\1\23\3\7\1\32\1\10\1\20\1\14\3\7\2\25\1\23\10\10\2\5\2\12\1\25\1\13\4\5\2\uffff\1\25\4\10\1\12";
    static final String dfa_11s = "\1\17\1\37\3\7\1\32\1\10\1\20\1\16\3\7\2\30\1\24\10\10\2\5\2\12\1\30\1\37\4\5\2\uffff\1\30\4\10\1\12";
    static final String dfa_12s = "\41\uffff\1\2\1\1\6\uffff";
    static final String dfa_13s = "\51\uffff}>";
    static final String[] dfa_14s = {
            "\1\1",
            "\1\3\1\2\12\uffff\1\4",
            "\1\5",
            "\1\5",
            "\1\5",
            "\1\6",
            "\1\7",
            "\1\10",
            "\1\11\1\12\1\13",
            "\1\14",
            "\1\15",
            "\1\16",
            "\1\17\1\20\1\21\1\22",
            "\1\23\1\24\1\25\1\26",
            "\1\30\1\27",
            "\1\31",
            "\1\31",
            "\1\31",
            "\1\31",
            "\1\32",
            "\1\32",
            "\1\32",
            "\1\32",
            "\1\33",
            "\1\33",
            "\1\34",
            "\1\34",
            "\1\35\1\36\1\37\1\40",
            "\1\41\3\uffff\1\42\3\uffff\2\42\12\uffff\1\42",
            "\1\43",
            "\1\43",
            "\1\43",
            "\1\43",
            "",
            "",
            "\1\44\1\45\1\46\1\47",
            "\1\50",
            "\1\50",
            "\1\50",
            "\1\50",
            "\1\34"
    };

    static final short[] dfa_8 = DFA.unpackEncodedString(dfa_8s);
    static final short[] dfa_9 = DFA.unpackEncodedString(dfa_9s);
    static final char[] dfa_10 = DFA.unpackEncodedStringToUnsignedChars(dfa_10s);
    static final char[] dfa_11 = DFA.unpackEncodedStringToUnsignedChars(dfa_11s);
    static final short[] dfa_12 = DFA.unpackEncodedString(dfa_12s);
    static final short[] dfa_13 = DFA.unpackEncodedString(dfa_13s);
    static final short[][] dfa_14 = unpackEncodedStringArray(dfa_14s);

    class DFA10 extends DFA {

        public DFA10(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 10;
            this.eot = dfa_8;
            this.eof = dfa_9;
            this.min = dfa_10;
            this.max = dfa_11;
            this.accept = dfa_12;
            this.special = dfa_13;
            this.transition = dfa_14;
        }
        public String getDescription() {
            return "876:1: rule__Source__Alternatives : ( ( ( rule__Source__Group_0__0 ) ) | ( ( rule__Source__Group_1__0 ) ) );";
        }
    }
    static final String dfa_15s = "\14\uffff";
    static final String dfa_16s = "\6\uffff\1\10\1\13\4\uffff";
    static final String dfa_17s = "\1\21\1\20\2\24\2\12\2\13\4\uffff";
    static final String dfa_18s = "\1\21\1\40\2\24\2\12\2\37\4\uffff";
    static final String dfa_19s = "\10\uffff\1\1\1\3\1\4\1\2";
    static final String dfa_20s = "\14\uffff}>";
    static final String[] dfa_21s = {
            "\1\1",
            "\1\2\17\uffff\1\3",
            "\1\4",
            "\1\5",
            "\1\6",
            "\1\7",
            "\1\11\3\uffff\1\10\1\uffff\1\10\1\uffff\2\10\12\uffff\1\10",
            "\1\12\3\uffff\1\13\1\uffff\1\13\1\uffff\2\13\12\uffff\1\13",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_15 = DFA.unpackEncodedString(dfa_15s);
    static final short[] dfa_16 = DFA.unpackEncodedString(dfa_16s);
    static final char[] dfa_17 = DFA.unpackEncodedStringToUnsignedChars(dfa_17s);
    static final char[] dfa_18 = DFA.unpackEncodedStringToUnsignedChars(dfa_18s);
    static final short[] dfa_19 = DFA.unpackEncodedString(dfa_19s);
    static final short[] dfa_20 = DFA.unpackEncodedString(dfa_20s);
    static final short[][] dfa_21 = unpackEncodedStringArray(dfa_21s);

    class DFA11 extends DFA {

        public DFA11(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 11;
            this.eot = dfa_15;
            this.eof = dfa_16;
            this.min = dfa_17;
            this.max = dfa_18;
            this.accept = dfa_19;
            this.special = dfa_20;
            this.transition = dfa_21;
        }
        public String getDescription() {
            return "897:1: rule__Prefix__Alternatives : ( ( ( rule__Prefix__Group_0__0 ) ) | ( ( rule__Prefix__Group_1__0 ) ) | ( ( rule__Prefix__Group_2__0 ) ) | ( ( rule__Prefix__Group_3__0 ) ) );";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x00000000801A8000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000008002L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000080180002L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000002000010L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000180000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000022L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x00000000FDF80000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000080180000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000080180040L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000001E00000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000007000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000100000000L});

}